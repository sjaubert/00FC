import json
c = json.load(open('py/coeffs.json')); P = json.load(open('py/patterns.json'))
f = lambda v, d: f"{v:.{d}f}".replace('.', '{,}')
def row(label, key, d, note=''):
    return label + ' & ' + ' & '.join('$' + f(c[n][key], d) + '$' for n in '2345') + r' \\' + '\n'
T = {}
T['tab_base'] = (row(r'$d_2$', 'd2', 3) + row(r'$d_3$', 'd3', 3) + row(r'$c_4$', 'c4', 4))
T['tab_shew_inc'] = (row(r'$A_2$', 'A2', 3) + row(r'$D_3$', 'D3', 3) + row(r'$D_4$', 'D4', 3) + r'\midrule' + '\n'
    + row(r'$A_3$', 'A3', 3) + row(r'$B_3$', 'B3', 3) + row(r'$B_4$', 'B4', 3))
T['tab_shew_con'] = (row(r'$A$', 'A', 3) + row(r'$D_1$', 'D1', 3) + row(r'$D_2$', 'D2_', 3) + r'\midrule' + '\n'
    + row(r'$B_5$', 'B5', 3) + row(r'$B_6$', 'B6', 3))
T['tab_afn_inc'] = (row(r"$A'_c$", 'Apc', 3) + row(r"$A'_s$", 'Aps', 3) + r'\midrule' + '\n'
    + row(r"$D'_{c1}$", 'Dpc1', 2) + row(r"$D'_{c2}$", 'Dpc2', 2) + row(r"$D'_{s1}$", 'Dps1', 2) + row(r"$D'_{s2}$", 'Dps2', 2) + r'\midrule' + '\n'
    + row(r'$3{,}09/(c_4\sqrt n)$', 'Apc_s', 3) + row(r'$1{,}96/(c_4\sqrt n)$', 'Aps_s', 3)
    + row(r"$B'_{c1}$", 'Bpc1', 3) + row(r"$B'_{c2}$", 'Bpc2', 3) + row(r"$B'_{s1}$", 'Bps1', 3) + row(r"$B'_{s2}$", 'Bps2', 3))
T['tab_afn_con'] = (row(r'$A_c$', 'Ac', 3) + row(r'$A_s$', 'As', 3) + r'\midrule' + '\n'
    + row(r'$D_{c1}$', 'Dc1', 2) + row(r'$D_{c2}$', 'Dc2', 2) + row(r'$D_{s1}$', 'Ds1', 2) + row(r'$D_{s2}$', 'Ds2', 2) + r'\midrule' + '\n'
    + row(r'$B_{c1}$', 'Bc1', 3) + row(r'$B_{c2}$', 'Bc2', 3) + row(r'$B_{s1}$', 'Bs1', 3) + row(r'$B_{s2}$', 'Bs2', 3))
for k, v in T.items(): open(f'tex/{k}.tex', 'w').write(v)
# motifs : coordonnées pgfplots
for k, v in P.items():
    open(f'tex/pat_{k}.tex', 'w').write(' '.join(f'({i+1},{z})' for i, z in enumerate(v['z'])))
print(open('tex/tab_afn_inc.tex').read())
