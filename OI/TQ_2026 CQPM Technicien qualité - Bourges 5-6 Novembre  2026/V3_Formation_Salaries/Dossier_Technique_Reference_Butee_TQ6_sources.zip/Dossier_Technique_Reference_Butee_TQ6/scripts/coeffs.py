# Coefficients des cartes de contrôle, n = 2..5, calcul exact (intégration numérique)
import numpy as np
from scipy import integrate, stats, optimize
from scipy.special import gamma
N = stats.norm
def range_cdf(w, n):
    f = lambda x: n * N.pdf(x) * (N.cdf(x + w) - N.cdf(x))**(n - 1)
    return integrate.quad(f, -9, 9, epsabs=1e-12, epsrel=1e-11, limit=200)[0]
def range_q(p, n):
    return optimize.brentq(lambda w: range_cdf(w, n) - p, 1e-9, 20, xtol=1e-10)
def d2(n):
    return integrate.quad(lambda w: 1 - range_cdf(w, n), 0, 15, epsabs=1e-10, limit=200)[0]
def d3(n):
    m2 = integrate.quad(lambda w: 2 * w * (1 - range_cdf(w, n)), 0, 15, epsabs=1e-10, limit=200)[0]
    return np.sqrt(m2 - d2(n)**2)
def c4(n): return np.sqrt(2/(n-1)) * gamma(n/2) / gamma((n-1)/2)
z999, z975 = N.ppf(0.999), N.ppf(0.975)
rows = {}
for n in range(2, 6):
    D2 = d2(n); D3s = d3(n); C4 = c4(n)
    r = dict(n=n, d2=D2, d3=D3s, c4=C4,
        A2=3/(D2*np.sqrt(n)), D3=max(0, 1-3*D3s/D2), D4=1+3*D3s/D2,
        D1=max(0, D2-3*D3s), D2_=D2+3*D3s,
        A3=3/(C4*np.sqrt(n)), B3=max(0, 1-3*np.sqrt(1-C4**2)/C4), B4=1+3*np.sqrt(1-C4**2)/C4,
        A=3/np.sqrt(n),
        Ac=z999/np.sqrt(n), As=z975/np.sqrt(n),
        Apc=z999/(D2*np.sqrt(n)), Aps=z975/(D2*np.sqrt(n)),
        Dc1=range_q(0.001, n), Dc2=range_q(0.999, n), Ds1=range_q(0.025, n), Ds2=range_q(0.975, n))
    for k in ['Dc1','Dc2','Ds1','Ds2']: r['Dp'+k[1:]] = r[k]/D2
    # carte s (s calculé avec n-1) : quantiles de s/sigma = sqrt(chi2/(n-1))
    for p, k in [(0.001,'Bc1'),(0.999,'Bc2'),(0.025,'Bs1'),(0.975,'Bs2')]:
        r[k] = np.sqrt(stats.chi2.ppf(p, n-1)/(n-1)); r['Bp'+k[1:]] = r[k]/C4
        r[k+'_ancien'] = np.sqrt(stats.chi2.ppf(p, n-1)/n)   # convention s avec diviseur n (ancien dossier)
    r['Apc_s'] = z999/(C4*np.sqrt(n)); r['Aps_s'] = z975/(C4*np.sqrt(n))
    r['B5'] = max(0, C4 - 3*np.sqrt(1-C4**2)); r['B6'] = C4 + 3*np.sqrt(1-C4**2)
    rows[n] = r
import json
print(f"z0,999 = {z999:.4f}  z0,975 = {z975:.4f}")
keys = ['d2','d3','c4','A2','D3','D4','D1','D2_','A3','B3','B4','A','Ac','As','Apc','Aps','Dc1','Dc2','Ds1','Ds2','Dpc1','Dpc2','Dps1','Dps2','Bc1','Bc2','Bs1','Bs2','Bpc1','Bpc2','Bps1','Bps2','Apc_s','Aps_s','Bc1_ancien','Bc2_ancien','Bs1_ancien','Bs2_ancien']
for k in keys: print(f"{k:11s}", '  '.join(f"{rows[n][k]:8.4f}" for n in range(2,6)))
json.dump({str(n):{k:float(v) for k,v in r.items()} for n,r in rows.items()}, open(__import__('os').path.join(__import__('os').path.dirname(__file__),'coeffs.json'),'w'), indent=1)
# comparaison avec l'ancien dossier
old = {'Ac':[2.185,1.784,1.545,1.382],'As':[1.386,1.132,0.98,0.876],'Apc':[1.937,1.054,0.75,0.594],'Aps':[1.229,0.668,0.476,0.377],
 'Bc1_ancien':[0.001,0.026,0.078,0.135],'Bc2_ancien':[2.327,2.146,2.017,1.922],'Bs1_ancien':[0.022,0.13,0.232,0.311],'Bs2_ancien':[1.585,1.568,1.529,1.493],
 'Dc1':[0,0.06,0.2,0.37],'Dc2':[4.65,5.06,5.31,5.58],'Ds1':[0.04,0.3,0.59,0.85],'Ds2':[3.17,3.68,3.98,4.2],
 'Dpc1':[0,0.04,0.1,0.16],'Dpc2':[4.12,2.99,2.58,2.36],'Dps1':[0.04,0.18,0.29,0.37],'Dps2':[2.81,2.17,1.93,1.81],'d2':[1.128,1.693,2.059,2.326]}
print('\nÉcarts ancien dossier / calcul :')
for k,v in old.items():
    for i,n in enumerate(range(2,6)):
        c = rows[n][k]; dec = len(str(v[i]).split('.')[-1]) if '.' in str(v[i]) else 0
        dec = max(dec, 2)
        if abs(round(c, dec) - v[i]) > 0.5*10**(-dec) + 1e-9:
            print(f"  {k} n={n}: ancien {v[i]}  calcul {c:.4f}")
