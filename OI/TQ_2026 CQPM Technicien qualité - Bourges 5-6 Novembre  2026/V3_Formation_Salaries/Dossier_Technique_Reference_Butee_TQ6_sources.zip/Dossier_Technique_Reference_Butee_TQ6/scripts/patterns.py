# Cartes illustratives simulées (échelle réduite : écarts-types de la moyenne), graine fixée
import numpy as np, json
LC, LS = 3.09, 1.96
def rules(z):
    a = []
    if np.any(np.abs(z) > LC): a.append('hors')
    s = np.sign(z)
    for i in range(len(z)-6):
        if abs(s[i:i+7].sum()) == 7: a.append('7cote'); break
    d = np.diff(z)
    for i in range(len(d)-4):
        if np.all(d[i:i+5] > 0) or np.all(d[i:i+5] < 0): a.append('6mont'); break
    if np.any((np.abs(z) > LS) & (np.abs(z) <= LC)): a.append('surv')
    return a
out = {}
def find(name, gen, want):
    for seed in range(1, 100000):
        z = gen(np.random.default_rng(seed))
        if sorted(rules(z)) == sorted(want):
            out[name] = dict(seed=seed, z=[round(float(v), 3) for v in z], rules=rules(z)); return
    raise SystemExit('pas trouvé ' + name)
K = 20
find('normal', lambda r: r.normal(0, 1, K), [])
def hors(r):
    z = r.normal(0, 1, K); z[13] = 3.6; return z
find('hors', hors, ['hors'])
def cote(r):
    z = r.normal(0, 1, K); z[9:17] = np.abs(r.normal(0.9, 0.5, 8)) + 0.05; return z
find('cote', cote, ['7cote'])
def mont(r):
    z = r.normal(0, 0.8, K); z[11:17] = np.linspace(-1.3, 1.6, 6) + r.normal(0, 0.12, 6); return z
find('mont', mont, ['6mont'])
def surv(r):
    z = r.normal(0, 0.8, K); z[12] = 2.4; return z
find('surv', surv, ['surv'])
json.dump(out, open(__import__('os').path.join(__import__('os').path.dirname(__file__),'patterns.json'), 'w'))
for k, v in out.items(): print(k, v['seed'], v['rules'], max(v['z']), min(v['z']))
