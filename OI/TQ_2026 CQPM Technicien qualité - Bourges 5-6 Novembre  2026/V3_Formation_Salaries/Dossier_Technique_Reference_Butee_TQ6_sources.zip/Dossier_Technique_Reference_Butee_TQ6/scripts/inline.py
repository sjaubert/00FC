import re,sys
p='tex/Dossier_Technique_Reference_Butee_TQ6.tex'; s=open(p,encoding='utf-8').read()
for name in ['tab_base','tab_shew_inc','tab_shew_con','tab_afn_inc','tab_afn_con']:
    body=open(f'tex/{name}.tex').read().rstrip('\n')
    s=re.sub(r'(%%BEGIN '+name+r'%%\n).*?(\n%%END '+name+r'%%)', lambda m: m.group(1)+body+m.group(2), s, flags=re.S)
    s=s.replace('\\input{'+name+'.tex}', '%%BEGIN '+name+'%%\n'+body+'\n%%END '+name+'%%')
open(p,'w',encoding='utf-8').write(s)
