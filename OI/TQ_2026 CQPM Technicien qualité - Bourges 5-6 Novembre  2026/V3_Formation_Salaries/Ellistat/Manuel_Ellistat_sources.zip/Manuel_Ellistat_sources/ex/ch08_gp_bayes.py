"""Chapitre 08 : processus gaussien 1D (noyau Matérn 5/2), gain espéré (EI),
boucle d'optimisation bayésienne et diagnostic leave-one-out.

Procédé simulé (graine 6) : facteur Température T de 150 à 250 °C, réponse Rendement (%) à maximiser.
  u = (T - 150)/100 ; f(u) = 60 + 12 exp(-((u-0,35)/0,2)^2) + 20 exp(-((u-0,82)/0,1)^2)
  mesure = f(u) + bruit N(0 ; 0,5). Optimum local vers 190 °C, optimum global vers 232 °C.
Plan initial : 5 essais régulièrement espacés, u = 0,1 ; 0,3 ; 0,5 ; 0,7 ; 0,9 (T = 160 à 240 °C).
Modèle (hypothèse de reconstitution, pas l'algorithme d'Ellistat) :
  k = sigma_f^2 Matérn_5/2(l) + bruit blanc, réponse centrée réduite,
  hyperparamètres par maximum de vraisemblance marginale (scikit-learn, 10 redémarrages, random_state 0),
  longueur de corrélation bornée à [0,1 ; 3] en unités réduites (10 à 300 % du domaine),
  part de bruit plafonnée (0,25 de la variance réduite : analogue supposé du réglage « Moyen »).
EI(x) = (mu - y* - xi) Phi(z) + s phi(z), z = (mu - y* - xi)/s, s = écart-type de la moyenne (sans bruit),
y* = meilleure mesure. Boucle : 6 itérations d'un essai, xi = 0,01 x écart-type des mesures.
Diagnostic LOO à hyperparamètres fixés (formules de Rasmussen et Williams, 2006, § 5.4.2).
Usage : python3 ch08_gp_bayes.py [dossier_coordonnees]
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import sys, json, warnings
import numpy as np
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel, WhiteKernel
warnings.filterwarnings("ignore")

f = lambda u: 60 + 12 * np.exp(-((u - 0.35) / 0.2) ** 2) + 20 * np.exp(-((u - 0.82) / 0.1) ** 2)
T = lambda u: 150 + 100 * u
rng = np.random.default_rng(6)
grid = np.linspace(0, 1, 401)

class GP:
    def __init__(self, u, y, cap=0.25, lb=0.1):
        self.u, self.y = np.asarray(u, float), np.asarray(y, float)
        self.m, self.sd = self.y.mean(), self.y.std(ddof=0)
        yn = (self.y - self.m) / self.sd
        k = ConstantKernel(1.0, (1e-2, 1e2)) * Matern(0.2, (lb, 3.0), nu=2.5) + WhiteKernel(1e-2, (1e-6, cap))
        g = GaussianProcessRegressor(k, normalize_y=False, n_restarts_optimizer=10, random_state=0).fit(self.u[:, None], yn)
        self.k1, self.noise = g.kernel_.k1, g.kernel_.k2.noise_level
        self.sf2, self.ell = g.kernel_.k1.k1.constant_value, g.kernel_.k1.k2.length_scale
        self.lml = g.log_marginal_likelihood_value_
        K = self.k1(self.u[:, None]) + self.noise * np.eye(len(self.u))
        self.Ki = np.linalg.inv(K)
        self.alpha = self.Ki @ yn
        self.yn = yn

    def predict(self, x):
        ks = self.k1(np.asarray(x, float)[:, None], self.u[:, None])
        mu = ks @ self.alpha
        var = self.sf2 - np.einsum("ij,jk,ik->i", ks, self.Ki, ks)
        return self.m + self.sd * mu, self.sd * np.sqrt(np.maximum(var, 1e-12))

    def loo(self):
        d = np.diag(self.Ki)
        mu = self.yn - self.alpha / d
        s = np.sqrt(1 / d)          # écart-type prédictif d'une nouvelle mesure (bruit inclus)
        return self.m + self.sd * mu, self.sd * s

def ei(mu, s, best, xi):
    z = (mu - best - xi) / s
    return (mu - best - xi) * norm.cdf(z) + s * norm.pdf(z)

# ---------------------------------------------------------------- plan initial
u = [0.1, 0.3, 0.5, 0.7, 0.9]
y = [f(v) + rng.normal(0, 0.5) for v in u]
print("Plan initial :")
for v, w in zip(u, y):
    print(f"  T = {T(v):.0f} °C  rendement = {w:.2f}")
gp = GP(u, y)
print(f"GP initial : sigma_f^2 = {gp.sf2:.3f}, longueur de corrélation l = {gp.ell:.3f} (en u) = {100*gp.ell:.1f} °C, "
      f"part de bruit = {gp.noise:.4f}, écart-type du bruit estimé = {gp.sd*np.sqrt(gp.noise):.3f}, log-vraisemblance = {gp.lml:.3f}")
g3 = GP(u, y, lb=0.03)
print(f"  (même ajustement avec une borne basse de 0,03 : l = {g3.ell:.3f}, soit {100*g3.ell:.0f} °C, part de bruit = {g3.noise:.3f} : estimation dégénérée)")
mu0, s0 = gp.predict(grid)
best0 = max(y)
eis = {}
for lib, xi in (("xi = 0", 0.0), ("xi = 0,01 sd", 0.01 * np.std(y)), ("xi = 0,25 sd", 0.25 * np.std(y)), ("xi = 0,5 sd", 0.5 * np.std(y))):
    e = ei(mu0, s0, best0, xi)
    eis[lib] = e
    j = int(np.argmax(e))
    print(f"  EI ({lib} = {xi:.3f}) : max EI = {e[j]:.3f} en T = {T(grid[j]):.1f} °C (mu = {mu0[j]:.2f}, s = {s0[j]:.2f})")
jm = int(np.argmax(mu0)); js = int(np.argmax(s0))
print(f"  maximum de la moyenne prédite : T = {T(grid[jm]):.1f} °C, mu = {mu0[jm]:.2f} ; incertitude maximale : T = {T(grid[js]):.1f} °C, s = {s0[js]:.2f}")
ei0 = ei(mu0, s0, best0, 0.01 * np.std(y))

# ---------------------------------------------------------------- boucle
orig = ["Plan initial"] * 5
for it in range(1, 7):
    gp = GP(u, y)
    mu, s = gp.predict(grid)
    e = ei(mu, s, max(y), 0.01 * np.std(y))
    j = int(np.argmax(e))
    unew = grid[j]
    ynew = f(unew) + rng.normal(0, 0.5)
    print(f"  itération {it} : T = {T(unew):.1f} °C, EI = {e[j]:.3f}, mesure = {ynew:.2f}")
    u.append(unew); y.append(ynew); orig.append(f"BO it. {it}")
best = np.maximum.accumulate(y)
print("Meilleur résultat cumulé :", np.round(best, 2))
print(f"Optimum vrai : T = {T(grid[np.argmax(f(grid))]):.1f} °C, f = {f(grid).max():.2f}")

# ---------------------------------------------------------------- diagnostic LOO
for cap, lib in ((0.25, "plafond 0,25"), (0.05, "plafond 0,05")):
    g = GP(u, y, cap)
    m, sl = g.loo()
    yy = np.array(y)
    q2 = 1 - np.sum((yy - m) ** 2) / np.sum((yy - yy.mean()) ** 2)
    rmse = np.sqrt(np.mean((yy - m) ** 2)); mae = np.mean(np.abs(yy - m))
    cov = np.mean(np.abs(yy - m) <= 1.96 * sl)
    print(f"LOO ({lib}) n = {len(yy)} : l = {g.ell:.3f}, part de bruit = {g.noise:.4f}, ET bruit = {g.sd*np.sqrt(g.noise):.3f}, "
          f"Q2 = {q2:.3f}, RMSE = {rmse:.3f}, MAE = {mae:.3f}, couverture 95 % = {cov:.3f} ({int(round(cov*len(yy)))}/{len(yy)})")
    if cap == 0.25:
        gl, ml, sll = g, m, sl
        for i in range(len(yy)):
            print(f"   essai {i+1:2d} T = {T(u[i]):6.1f} y = {yy[i]:6.2f} pred LOO = {m[i]:6.2f} +- {1.96*sl[i]:5.2f} {'hors' if abs(yy[i]-m[i]) > 1.96*sl[i] else ''}")
# granularité de la couverture sur n essais (modèle parfaitement calibré, essais supposés indépendants)
from scipy.stats import binom
nn = len(y)
print(f"Couverture : avec n = {nn}, un seul essai hors intervalle donne {(nn-1)/nn:.3f} < 0,95 ; "
      f"P(au moins un essai hors intervalle | modèle exact) = {1 - 0.95**nn:.3f} ; "
      f"P(au moins deux) = {binom.sf(1, nn, 0.05):.3f}")
# R2 en apprentissage, pour comparaison
mu_a, _ = gl.predict(np.array(u))
print(f"R2 d'apprentissage du même modèle : {1 - np.sum((np.array(y)-mu_a)**2)/np.sum((np.array(y)-np.mean(y))**2):.3f}")

if len(sys.argv) > 1:
    fmt = lambda pts: " ".join(f"({a:.2f},{b:.3f})" for a, b in pts)
    sub = slice(None, None, 4)
    gf = GP(u, y)
    muf, sf = gf.predict(grid)
    out = {"f": fmt(zip(T(grid[sub]), f(grid[sub]))),
           "mu0": fmt(zip(T(grid[sub]), mu0[sub])), "lo0": fmt(zip(T(grid[sub]), mu0[sub] - 1.96 * s0[sub])),
           "hi0": fmt(zip(T(grid[sub]), mu0[sub] + 1.96 * s0[sub])), "ei0": fmt(zip(T(grid[sub]), eis["xi = 0"][sub] / eis["xi = 0"].max())),
           "ei5": fmt(zip(T(grid[sub]), eis["xi = 0,5 sd"][sub] / eis["xi = 0,5 sd"].max())),
           "pts0": fmt(zip(T(np.array(u[:5])), y[:5])), "ptsbo": fmt(zip(T(np.array(u[5:])), y[5:])),
           "muf": fmt(zip(T(grid[sub]), muf[sub])), "lof": fmt(zip(T(grid[sub]), muf[sub] - 1.96 * sf[sub])),
           "hif": fmt(zip(T(grid[sub]), muf[sub] + 1.96 * sf[sub])),
           "conv": fmt(zip(range(1, len(y) + 1), best)), "mes": fmt(zip(range(1, len(y) + 1), y)),
           "loo": " ".join(f"({a:.3f},{b:.3f}) +- (0,{1.96*c:.3f})" for a, b, c in zip(ml, y, sll))}
    json.dump(out, open(sys.argv[1] + "/gp.json", "w"), indent=0)
