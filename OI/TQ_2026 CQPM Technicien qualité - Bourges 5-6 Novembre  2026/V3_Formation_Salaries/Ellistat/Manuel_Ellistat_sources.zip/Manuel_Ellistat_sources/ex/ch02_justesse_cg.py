# -*- coding: utf-8 -*-
"""Chapitre 02 - Étude de justesse (Cg, Cgk) sur données SIMULÉES.

Butée de référence X0 = 11,92 mm, tolérance 11,85 / 12,00 (T = 0,15 mm).
Deux séries de 25 mesures simulées, graine 2026 :
  - micromètre (résolution 0,001 mm) : biais vrai 0,008 mm, sigma vrai 0,003 mm ;
  - pied à coulisse (résolution 0,01 mm) : biais vrai 0,006 mm, sigma vrai 0,007 mm.
Formules Bosch (Heft 10, procédure 1) : Cg = 0,2T/(6s), Cgk = (0,1T - |biais|)/(3s).
Calcul refait en Python : ce n'est pas une sortie d'Ellistat.
"""
import numpy as np
from scipy import stats

rng = np.random.default_rng(2026)
X0, LI, LS = 11.92, 11.85, 12.00
T = LS - LI
n = 25

def serie(biais, sigma, res):
    x = X0 + biais + sigma * rng.standard_normal(n)
    return np.round(np.round(x / res) * res, 4)

series = {"Micromètre": (serie(0.008, 0.003, 0.001), 0.001),
          "Pied à coulisse": (serie(0.006, 0.007, 0.01), 0.01)}

def feu(v, vert, orange, sens="<="):
    if sens == "<=":
        return "vert" if v <= vert else ("orange" if v <= orange else "rouge")
    return "vert" if v > vert else ("orange" if v > orange else "rouge")

for nom, (x, res) in series.items():
    m = x.mean(); s = x.std(ddof=1); b = m - X0
    Cg = 0.2 * T / (6 * s)
    Cgk = (0.1 * T - abs(b)) / (3 * s)
    Cg4 = 0.2 * T / (4 * s)                      # variante 4s
    Cgk4 = (0.1 * T - abs(b)) / (2 * s)
    t = b / (s / np.sqrt(n)); pval = 2 * stats.t.sf(abs(t), n - 1)
    Tmin_Cgk = 10 * (1.33 * 3 * s + abs(b))      # T telle que Cgk = 1,33
    Tmin_Cg = 1.33 * 6 * s / 0.2                 # T telle que Cg = 1,33
    print(f"\n=== {nom} (résolution {res} mm) ===")
    print("Mesures :", " ".join(f"{v:.3f}" for v in x))
    print(f"n = {n} ; moyenne = {m:.5f} ; s = {s:.5f} ; biais = {b:+.5f} mm")
    print(f"Fenêtre X0 +/- 0,1T = [{X0 - 0.1*T:.3f} ; {X0 + 0.1*T:.3f}]")
    print(f"Cg (6s) = {Cg:.2f} [{feu(Cg, 1.33, 1.00, '>')}] ; Cgk (6s) = {Cgk:.2f} [{feu(Cgk, 1.33, 1.00, '>')}]")
    print(f"Variante 4s : Cg = {Cg4:.2f} ; Cgk = {Cgk4:.2f}")
    print(f"Test t du biais : t = {t:.2f} ; p = {pval:.2g}")
    print(f"Résolution / T = {res/T*100:.1f} % ; T/20 = {T/20:.4f} ; T/10 = {T/10:.4f} -> {feu(res, T/20, T/10)}")
    print(f"|biais| = {abs(b):.4f} -> écart de justesse {feu(abs(b), T/20, T/10)}")
    for k in (2, 3):
        rep = 2 * k * s
        print(f"Répétabilité 2k.s avec k = {k} : {rep:.4f} mm = {100*rep/T:.1f} % de T -> "
              f"{'vert' if rep/T < .05 else ('orange' if rep/T < .10 else 'rouge')}")
    inert_s = np.hypot(b, s)
    print(f"Inertie sqrt(b^2+s^2) = {inert_s:.5f} ; T/30 = {T/30:.4f} -> {'vert' if inert_s <= T/30 else 'rouge'}")
    print(f"Tolérance mini pour Cgk = 1,33 : {Tmin_Cgk:.4f} mm ; pour Cg = 1,33 : {Tmin_Cg:.4f} mm")
    print(f"Min {x.min():.3f} ; max {x.max():.3f}")
    if nom == "Micromètre":
        print("Coordonnées pgfplots :", " ".join(f"({i+1},{v:.3f})" for i, v in enumerate(x)))
    else:
        print("Coordonnées pgfplots :", " ".join(f"({i+1},{v:.2f})" for i, v in enumerate(x)))

# Lien avec la capabilité des butées (TQ6, fiche C) : s global observé 0,0264 mm.
# Variance observée = variance procédé + variance de mesure (hypothèse d'indépendance).
s_obs = 0.0264
print("\n=== Part de la variance observée des butées due à la répétabilité du moyen ===")
for nom, (x, res) in series.items():
    s = x.std(ddof=1)
    part = (s / s_obs) ** 2
    s_proc = np.sqrt(s_obs ** 2 - s ** 2)
    print(f"{nom} : s = {s:.5f} ; part = {100*part:.1f} % ; sigma procédé corrigé = {s_proc:.4f} ; "
          f"Pp brut = {T/(6*s_obs):.2f} ; Pp corrigé = {T/(6*s_proc):.2f}")
