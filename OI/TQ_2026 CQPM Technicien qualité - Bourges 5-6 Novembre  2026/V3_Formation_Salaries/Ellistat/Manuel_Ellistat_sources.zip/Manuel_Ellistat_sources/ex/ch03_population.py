# -*- coding: utf-8 -*-
"""Chapitre 03 : représentations de population et bascule « preuve statistique ».

Données réelles :
  - donnees/Butees_diametre.csv (6 échantillons x 5 pièces, tolérance 11,85 / 12,00 mm)
  - donnees/ANOVA_TP_R.csv (5 opérateurs x 20 mesures d'une même cote)
Calculs refaits en Python : ce ne sont pas des sorties d'Ellistat.
Quartiles : méthode « linéaire » de numpy (type 7 de Hyndman et Fan).
Moustaches : convention de Tukey (1,5 x écart interquartile).
"""
import numpy as np
from scipy import stats
from ch03_commun import lire, fr, c, coords, ecrire, titre

LSL, USL = 11.85, 12.00
D2_N5, A2_N5 = 2.326, 0.577

# ----------------------------------------------------------------- Butées
d = lire("Butees_diametre.csv", decimal=",").dropna()
M = d[["P1", "P2", "P3", "P4", "P5"]].to_numpy(dtype=float)
x = M.ravel()  # ordre de prélèvement : échantillon 1 P1..P5, puis 2, ...
n = x.size
moy, s = x.mean(), x.std(ddof=1)
R = M.max(axis=1) - M.min(axis=1)
Rbar = R.mean()
sig_intra = Rbar / D2_N5

titre("Butées : description")
print(f"n = {n} ; moyenne = {fr(moy, 4)} ; s global = {fr(s, 4)}")
print(f"R moyen = {fr(Rbar, 4)} ; sigma intra R/d2 = {fr(sig_intra, 4)}")
print(f"min = {fr(x.min(), 2)} ; max = {fr(x.max(), 2)}")
T = USL - LSL
print(f"Cp = {fr(T / (6 * sig_intra), 2)} ; Cpk = {fr(min(USL - moy, moy - LSL) / (3 * sig_intra), 2)} (sigma intra R/d2)")
print(f"Pp = {fr(T / (6 * s), 2)} ; Ppk = {fr(min(USL - moy, moy - LSL) / (3 * s), 2)} (s global)")
sw = stats.shapiro(x)
print(f"Shapiro-Wilk : W = {fr(sw.statistic, 3)} ; p = {fr(sw.pvalue, 2)}")

# Histogramme : classes de largeur 0,01 centrées sur la résolution de mesure
bords = np.round(np.arange(11.825, 11.946, 0.01), 3)
eff, _ = np.histogram(x, bins=bords)
print("Classes (bords) :", [fr(b, 3) for b in bords])
print("Effectifs :", [int(e) for e in eff], "total", int(eff.sum()))
hist = " ".join(f"({c(b, 3)},{e})" for b, e in zip(bords[:-1], eff))
hist += f" ({c(bords[-1], 3)},0)"
ecrire("hist_butees", r"\addplot[ybar interval,fill=uimmblue!35,draw=uimmblue] coordinates {" + hist + "};")
xs = np.linspace(11.80, 12.02, 111)
dens = n * 0.01 * stats.norm.pdf(xs, moy, s)
ecrire("hist_butees_normale", r"\addplot[thick,uimmred,smooth] coordinates {" + coords(xs, dens, 4, 3) + "};")

# Boîtes par échantillon
def boite(v):
    q1, me, q3 = np.percentile(v, [25, 50, 75])
    iqr = q3 - q1
    bas = v[v >= q1 - 1.5 * iqr].min()
    haut = v[v <= q3 + 1.5 * iqr].max()
    atyp = v[(v < q1 - 1.5 * iqr) | (v > q3 + 1.5 * iqr)]
    return q1, me, q3, bas, haut, atyp

titre("Butées : boîtes par échantillon (quartiles type 7, moustaches de Tukey)")
lignes = []
for i, v in enumerate(M, start=1):
    q1, me, q3, bas, haut, at = boite(v)
    print(f"Éch. {i} : Q1 = {fr(q1, 3)} ; médiane = {fr(me, 3)} ; Q3 = {fr(q3, 3)} ; "
          f"moustaches {fr(bas, 2)} à {fr(haut, 2)} ; atypiques {[fr(t, 2) for t in at]} ; moyenne {fr(v.mean(), 3)}")
    lignes.append(rf"\chtroisboite{{{i}}}{{{c(q1, 4)}}}{{{c(me, 4)}}}{{{c(q3, 4)}}}{{{c(bas, 2)}}}{{{c(haut, 2)}}}")
    for a in at:
        lignes.append(rf"\addplot[only marks,mark=o,mark size=1.8pt,uimmred] coordinates {{({i},{c(a, 2)})}};")
pts = " ".join(f"({i + 1},{c(v, 2)})" for i in range(6) for v in M[i])
lignes.append(r"\addplot[only marks,mark=*,mark size=1pt,grisTQ] coordinates {" + pts + "};")
ecrire("boites_echantillons", "\n".join(lignes))

# Bascule : échantillons 1 et 3 (décalage visible, non significatif) ; 1 et 5
titre("Bascule : comparaison d'échantillons (tests hors guide)")
for (i, j) in [(1, 3), (1, 5)]:
    a, b = M[i - 1], M[j - 1]
    w = stats.ttest_ind(a, b, equal_var=False)
    mw = stats.mannwhitneyu(a, b, alternative="two-sided")
    print(f"Éch. {i} (moy {fr(a.mean(), 3)}) contre éch. {j} (moy {fr(b.mean(), 3)}) : "
          f"Welch t = {fr(w.statistic, 2)}, p = {fr(w.pvalue, 3)} ; Mann-Whitney p = {fr(mw.pvalue, 3)}")
lb = []
for k, i in enumerate([1, 3], start=1):
    q1, me, q3, bas, haut, at = boite(M[i - 1])
    lb.append(rf"\chtroisboite{{{k}}}{{{c(q1, 4)}}}{{{c(me, 4)}}}{{{c(q3, 4)}}}{{{c(bas, 2)}}}{{{c(haut, 2)}}}")
pts = " ".join(f"({k},{c(v, 2)})" for k, i in [(1, 1), (2, 3)] for v in M[i - 1])
lb.append(r"\addplot[only marks,mark=*,mark size=1pt,grisTQ] coordinates {" + pts + "};")
ecrire("bascule_boites", "\n".join(lb))

# Ligne (ordre de prélèvement)
titre("Butées : ligne chronologique")
ecrire("ligne_butees", r"\addplot[uimmblue,mark=*,mark size=1.2pt] coordinates {"
       + " ".join(f"({k + 1},{c(v, 2)})" for k, v in enumerate(x)) + "};")
mo = M.mean(axis=1)
print("Moyennes d'échantillon :", [fr(m, 3) for m in mo])

# Carte X-barre / R (limites 3 sigmas via A2)
titre("Butées : carte X-barre (A2 = 0,577 pour n = 5)")
lcs, lci = moy + A2_N5 * Rbar, moy - A2_N5 * Rbar
print(f"Ligne centrale = {fr(moy, 4)} ; LCS = {fr(lcs, 4)} ; LCI = {fr(lci, 4)}")
print("Étendues :", [fr(r, 2) for r in R])
print("Points hors limites :", [i + 1 for i, m in enumerate(mo) if m > lcs or m < lci])
ecrire("carte_xbar", r"\addplot[uimmblue,mark=square*,mark size=1.6pt] coordinates {"
       + " ".join(f"({i + 1},{c(m, 4)})" for i, m in enumerate(mo)) + "};\n"
       + rf"\def\chtroisLCS{{{c(lcs, 4)}}}\def\chtroisLCI{{{c(lci, 4)}}}\def\chtroisLC{{{c(moy, 4)}}}")

# Ogive (fonction de répartition empirique)
titre("Butées : ogive")
vs = np.sort(x)
uniq = np.unique(vs)
F = np.array([(vs <= u).mean() for u in uniq])
for u, f in zip(uniq, F):
    print(f"  P(X <= {fr(u, 2)}) = {fr(f, 3)}")
p_le = (x <= LSL + 1e-9).sum()
p_lt = (x < LSL - 1e-9).sum()
pn = stats.norm.cdf(LSL, moy, s)
print(f"Valeurs <= 11,85 : {p_le}/{n} = {fr(p_le / n * 100, 1)} % ; valeurs < 11,85 : {p_lt}/{n} = {fr(p_lt / n * 100, 1)} %")
print(f"Modèle normal (moyenne, s global) : P(X < 11,85) = {fr(pn * 100, 1)} %")
pas = [(11.82, 0.0)]
prev = 0.0
for u, f in zip(uniq, F):
    pas += [(u, prev), (u, f)]
    prev = f
pas.append((12.02, 1.0))
ecrire("ogive_butees", r"\addplot[thick,uimmblue] coordinates {" + coords(*zip(*pas), 3, 4) + "};\n"
       + r"\addplot[thick,dashed,uimmred,smooth] coordinates {"
       + coords(xs, stats.norm.cdf(xs, moy, s), 4, 4) + "};")

# ----------------------------------------------------------------- Opérateurs
titre("ANOVA_TP_R : boîtes par opérateur")
a = lire("ANOVA_TP_R.csv", decimal=",")
ops = list(dict.fromkeys(a["Operateurs"]))
lo = []
grp = []
for k, op in enumerate(ops, start=1):
    v = a.loc[a["Operateurs"] == op, "Mesure"].to_numpy(float)
    grp.append(v)
    q1, me, q3, bas, haut, at = boite(v)
    print(f"{op} : n = {v.size} ; moyenne = {fr(v.mean(), 4)} ; s = {fr(v.std(ddof=1), 4)} ; "
          f"Q1 = {fr(q1, 4)} ; méd. = {fr(me, 3)} ; Q3 = {fr(q3, 4)} ; moustaches {fr(bas, 2)} à {fr(haut, 2)} ; "
          f"atypiques {[fr(t, 2) for t in at]}")
    lo.append(rf"\chtroisboite{{{k}}}{{{c(q1, 4)}}}{{{c(me, 4)}}}{{{c(q3, 4)}}}{{{c(bas, 2)}}}{{{c(haut, 2)}}}")
    for t in at:
        lo.append(rf"\addplot[only marks,mark=o,mark size=1.8pt,uimmred] coordinates {{({k},{c(t, 2)})}};")
    lo.append(rf"\addplot[only marks,mark=x,mark size=2.2pt,orangeTQ,thick] coordinates {{({k},{c(v.mean(), 4)})}};")
    if at.size:
        rang = [int(j) + 1 for j in np.where(np.isin(v, at))[0]]
        print(f"   rangs des valeurs atypiques dans l'ordre du fichier : {rang}")
ecrire("boites_operateurs", "\n".join(lo))
f1 = stats.f_oneway(*grp)
kw = stats.kruskal(*grp)
lv = stats.levene(*grp)
print(f"ANOVA à un facteur : F = {fr(f1.statistic, 2)} ; p = {fr(f1.pvalue, 3)}")
print(f"Kruskal-Wallis : H = {fr(kw.statistic, 2)} ; p = {fr(kw.pvalue, 3)}")
print(f"Levene (médianes) : p = {fr(lv.pvalue, 3)}")
print(f"Moyenne générale = {fr(a['Mesure'].mean(), 4)}")
