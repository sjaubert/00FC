"""Outils communs aux scripts du chapitre 01 (lecture des butées, estimateurs de sigma).

Les estimateurs sont les formules classiques de MSP (hors guide Ellistat) :
  - R barre / d2, S barre / c4, écart-type groupé (pooled), étendues mobiles / 1,128,
  - écart-type global s (diviseur n - 1).
"""
from pathlib import Path
import math

import numpy as np
import pandas as pd

DONNEES = Path(__file__).resolve().parent.parent / "donnees"
LSL, USL = 11.85, 12.00          # tolérance des butées (TQ6)
D2 = {2: 1.128, 3: 1.693, 4: 2.059, 5: 2.326}


def c4(n):
    return math.sqrt(2.0 / (n - 1)) * math.gamma(n / 2) / math.gamma((n - 1) / 2)


def lire_large():
    """Lit Butees_diametre.csv (format large) et retire les lignes vides."""
    df = pd.read_csv(DONNEES / "Butees_diametre.csv", sep=";", decimal=",",
                     encoding="utf-8-sig")
    return df.dropna(subset=[c for c in df.columns if c != "Echantillon"], how="all")


def large_vers_long(df):
    """Empile P1..P5 : une ligne par mesure (Echantillon, Piece, Diametre)."""
    long = df.melt(id_vars="Echantillon", var_name="Piece", value_name="Diametre")
    long["Piece"] = long["Piece"].str.lstrip("P").astype(int)
    return long.sort_values(["Echantillon", "Piece"]).reset_index(drop=True)


def sigmas(long, col_groupe="Echantillon", col_val="Diametre"):
    """Renvoie un dict des estimateurs de sigma pour un format long."""
    g = long.groupby(col_groupe, sort=True)[col_val]
    n = int(g.size().iloc[0])
    rbar = (g.max() - g.min()).mean()
    sbar = g.std(ddof=1).mean()
    pooled = math.sqrt(g.var(ddof=1).mean())
    x = long[col_val].to_numpy()
    mrbar = np.abs(np.diff(x)).mean()
    return {
        "n": n,
        "k": int(g.ngroups),
        "moyenne": x.mean(),
        "Rbar": rbar,
        "R/d2": rbar / D2[n],
        "Sbar": sbar,
        "S/c4": sbar / c4(n),
        "groupe": pooled,
        "MRbar": mrbar,
        "MR/1,128": mrbar / D2[2],
        "s global": x.std(ddof=1),
    }


def cp_cpk(sigma, moyenne):
    cp = (USL - LSL) / (6 * sigma)
    cpk = min(USL - moyenne, moyenne - LSL) / (3 * sigma)
    return cp, cpk


def fr(x, nd=4):
    """Format français (virgule décimale)."""
    return f"{x:.{nd}f}".replace(".", ",")
