"""Chapitre 05 : comparaison des opérateurs sur donnees/ANOVA_TP_R.csv.

Calcul refait en Python (scipy, statsmodels), ce n'est pas une sortie d'Ellistat.
  - statistiques par opérateur, éléments des boîtes à moustaches (quartiles, moustaches à 1,5 IQR) ;
  - ANOVA à un facteur, part de variabilité (eta²) ;
  - normalité des résidus (Shapiro-Wilk), égalité des variances (Levene moyenne et médiane, Bartlett) ;
  - Welch (variances inégales), Kruskal-Wallis, comparaisons par paires de Tukey HSD.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.oneway import anova_oneway

DONNEES = Path(__file__).resolve().parent.parent / "donnees"
df = pd.read_csv(DONNEES / "ANOVA_TP_R.csv", sep=";", decimal=",", encoding="utf-8-sig")
df = df.dropna()
ops = list(dict.fromkeys(df["Operateurs"]))
groupes = [df.loc[df["Operateurs"] == o, "Mesure"].to_numpy() for o in ops]

print("=== Statistiques par opérateur ===")
print(f"N total = {len(df)}, moyenne générale = {df['Mesure'].mean():.4f}")
for o, g in zip(ops, groupes):
    q1, med, q3 = np.percentile(g, [25, 50, 75])   # méthode linéaire (type 7)
    iqr = q3 - q1
    bas = g[g >= q1 - 1.5 * iqr].min()
    haut = g[g <= q3 + 1.5 * iqr].max()
    hors = sorted(g[(g < q1 - 1.5 * iqr) | (g > q3 + 1.5 * iqr)])
    print(f"{o:10s} n={len(g)} moy={g.mean():.4f} s={g.std(ddof=1):.4f} "
          f"min={g.min():.2f} Q1={q1:.4f} med={med:.4f} Q3={q3:.4f} max={g.max():.2f} "
          f"moustaches=[{bas:.2f};{haut:.2f}] hors={hors}")

print("\n=== ANOVA à un facteur ===")
F, p = stats.f_oneway(*groupes)
k, N = len(groupes), len(df)
moy = df["Mesure"].mean()
sce = sum(len(g) * (g.mean() - moy) ** 2 for g in groupes)
scr = sum(((g - g.mean()) ** 2).sum() for g in groupes)
print(f"SC facteur = {sce:.6f} (ddl {k-1}), CM = {sce/(k-1):.6f}")
print(f"SC résiduelle = {scr:.6f} (ddl {N-k}), CM = {scr/(N-k):.6f}")
print(f"F = {F:.3f}, p = {p:.4g}, eta² = {sce/(sce+scr):.3f}, sigma résiduel = {np.sqrt(scr/(N-k)):.4f}")

residus = np.concatenate([g - g.mean() for g in groupes])
W, pW = stats.shapiro(residus)
print(f"\nShapiro-Wilk sur les résidus : W = {W:.4f}, p = {pW:.4f}")
for centre in ("mean", "median"):
    L, pL = stats.levene(*groupes, center=centre)
    print(f"Levene (centre = {centre}) : W = {L:.3f}, p = {pL:.4f}")
B, pB = stats.bartlett(*groupes)
print(f"Bartlett : K² = {B:.3f}, p = {pB:.4f}")

wel = anova_oneway(groupes, use_var="unequal")
print(f"ANOVA de Welch : F = {wel.statistic:.3f}, p = {wel.pvalue:.4g}")
H, pH = stats.kruskal(*groupes)
print(f"Kruskal-Wallis : H = {H:.3f}, p = {pH:.4g}")

print("\n=== Tukey HSD (alpha = 0,05) ===")
tk = pairwise_tukeyhsd(df["Mesure"], df["Operateurs"], alpha=0.05)
print(tk.summary())
print(f"Nombre de paires = {k*(k-1)//2}")
