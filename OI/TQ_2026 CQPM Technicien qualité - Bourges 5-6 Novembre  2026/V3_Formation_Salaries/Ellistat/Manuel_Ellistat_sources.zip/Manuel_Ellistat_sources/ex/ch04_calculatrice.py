"""Chapitre 04 : calculs de la page Calculatrice refaits sur les butées.

1. Intervalle de dispersion (tolérance statistique, ISO 16269-6), loi normale,
   bilatéral, méthode S : k exact (intégration numérique) et approximation de Howe.
2. Intervalle de prédiction (ISO 16269-8), m = 1 : k = t(1-a/2 ; n-1) sqrt(1 + 1/n).
3. Intervalle de confiance de la moyenne (comparaison).
4. Courbes d'efficacité de plans aux attributs (binomiale) et plan sur mesure (p1, alpha, p2, beta).
5. Limites de carte X-barre : +/- 3 sigma et « Cpk mini avec risque beta ».
Calcul refait en Python : ce ne sont pas des sorties d'Ellistat.
"""
from pathlib import Path
import math
import numpy as np
from scipy import stats, integrate, optimize

DATA = Path(__file__).resolve().parent.parent / "donnees" / "Butees_diametre.csv"
LSL, USL = 11.85, 12.00


def lire():
    vals = []
    for ligne in DATA.read_text(encoding="utf-8-sig").splitlines()[1:]:
        vals += [float(c.replace(",", ".")) for c in ligne.split(";")[1:] if c.strip()]
    return np.array(vals)


def k_tolerance_bilateral(n, p, conf):
    """k exact de l'intervalle bilatéral X̄ ± k s couvrant p avec confiance conf."""
    nu = n - 1

    def r_of(xx):
        return optimize.brentq(lambda r: stats.norm.cdf(xx + r) - stats.norm.cdf(xx - r) - p, 0, 20)

    def confiance(k):
        f = lambda xx: math.sqrt(n / (2 * math.pi)) * math.exp(-n * xx * xx / 2) * \
            stats.chi2.sf(nu * r_of(xx) ** 2 / k ** 2, nu)
        val, _ = integrate.quad(f, -8 / math.sqrt(n), 8 / math.sqrt(n), limit=200)
        return val

    return optimize.brentq(lambda k: confiance(k) - conf, 1.0, 20.0)


def k_howe(n, p, conf):
    nu = n - 1
    z = stats.norm.ppf((1 + p) / 2)
    return z * math.sqrt(nu * (1 + 1 / n) / stats.chi2.ppf(1 - conf, nu))


def k_unilateral(n, p, conf):
    zp = stats.norm.ppf(p)
    return stats.nct.ppf(conf, n - 1, zp * math.sqrt(n)) / math.sqrt(n)


def intervalles():
    x = lire()
    n, m, s = x.size, x.mean(), x.std(ddof=1)
    print(f"n = {n}, moyenne = {m:.4f}, s = {s:.4f}")
    print("\nIntervalle de dispersion bilatéral (méthode S), confiance 95 %")
    for p in (0.95, 0.99, 0.9973):
        k = k_tolerance_bilateral(n, p, 0.95)
        kh = k_howe(n, p, 0.95)
        print(f"  p = {p}: k exact = {k:.4f} (Howe {kh:.4f}) -> [{m - k * s:.4f} ; {m + k * s:.4f}]  largeur {2 * k * s:.4f}")
    k20 = k_tolerance_bilateral(20, 0.9973, 0.95)
    print(f"  contrôle n = 20, p = 0,9973, conf 95 % : k = {k20:.3f}")
    k30_9095 = k_tolerance_bilateral(30, 0.90, 0.95)
    print(f"  contrôle table n = 30, p = 0,90, conf 95 % : k = {k30_9095:.4f}")
    print(f"  méthode Sigma (sigma connu = s) p = 0,9973, conf 95 % : approx k = z_p seulement si n infini ; z = {stats.norm.ppf(0.99865):.4f}")
    ku = k_unilateral(n, 0.99, 0.95)
    print(f"  unilatéral p = 0,99, conf 95 % : k = {ku:.4f} -> borne inf {m - ku * s:.4f}")

    t = stats.t.ppf(0.975, n - 1)
    kp = t * math.sqrt(1 + 1 / n)
    print(f"\nPrédiction m = 1, 95 % : t = {t:.4f}, k = {kp:.4f} -> [{m - kp * s:.4f} ; {m + kp * s:.4f}]")
    print(f"Intervalle naïf X̄ ± 3 s : [{m - 3 * s:.4f} ; {m + 3 * s:.4f}]")
    kc = t / math.sqrt(n)
    print(f"IC 95 % de la moyenne : k = {kc:.4f} -> [{m - kc * s:.4f} ; {m + kc * s:.4f}]")
    # prédiction pour m = 5 futures (Bonferroni, approximation)
    tb = stats.t.ppf(1 - 0.05 / (2 * 5), n - 1)
    print(f"Prédiction m = 5 (Bonferroni, approx.) : k = {tb * math.sqrt(1 + 1 / n):.4f}")


def oc():
    print("\nCourbes d'efficacité (binomiale)")
    plans = [(80, 2), (13, 0), (50, 1)]
    ps = [0, 0.005, 0.01, 0.015, 0.02, 0.03, 0.04, 0.05, 0.06, 0.08, 0.10, 0.12, 0.15]
    for n, ac in plans:
        pa = [stats.binom.cdf(ac, n, p) for p in ps]
        print(f"  n={n} Ac={ac}: " + " ".join(f"({p * 100:g},{v:.4f})" for p, v in zip(ps, pa)))
    for n, ac in plans:
        print(f"  n={n} Ac={ac}: Pa(1 %) = {stats.binom.cdf(ac, n, 0.01):.3f}, Pa(5 %) = {stats.binom.cdf(ac, n, 0.05):.3f}")
    # croisement des deux courbes
    g = lambda p: stats.binom.cdf(2, 80, p) - stats.binom.cdf(0, 13, p)
    pc = optimize.brentq(g, 0.005, 0.1)
    print(f"  croisement n=80/Ac=2 et n=13/Ac=0 : p = {pc * 100:.2f} %")
    # plan sur mesure p1 = 1 %, alpha = 5 %, p2 = 5 %, beta = 10 %
    p1, a, p2, b = 0.01, 0.05, 0.05, 0.10
    for n in range(1, 1000):
        ok = None
        for ac in range(0, n):
            if stats.binom.cdf(ac, n, p1) >= 1 - a and stats.binom.cdf(ac, n, p2) <= b:
                ok = ac
                break
        if ok is not None:
            print(f"  plan sur mesure p1 1 %, alpha 5 %, p2 5 %, beta 10 % : n = {n}, Ac = {ok}, "
                  f"Pa(p1) = {stats.binom.cdf(ok, n, p1):.3f}, Pa(p2) = {stats.binom.cdf(ok, n, p2):.3f}")
            break


def limites():
    print("\nLimites de carte X-barre, n = 5")
    n = 5
    cible = (LSL + USL) / 2
    ub = stats.norm.ppf(0.90)
    print(f"u_beta (beta = 10 %) = {ub:.4f}")
    for nom, sig, cpkmin in (("butées R̄/d2", 0.0215, 1.33), ("procédé capable hypothétique", 0.010, 1.33)):
        l3 = (cible - 3 * sig / math.sqrt(n), cible + 3 * sig / math.sqrt(n))
        lci = LSL + 3 * cpkmin * sig + ub * sig / math.sqrt(n)
        lcs = USL - 3 * cpkmin * sig - ub * sig / math.sqrt(n)
        cp = (USL - LSL) / (6 * sig)
        print(f"  {nom}: sigma = {sig}, Cp = {cp:.2f}, ±3 sigma autour cible = [{l3[0]:.4f} ; {l3[1]:.4f}], "
              f"Cpk mini {cpkmin} = [{lci:.4f} ; {lcs:.4f}]  {'CROISÉES' if lci > lcs else ''}")
    for cp in (1.33, 1.67):
        print(f"  sigma_ct = IT/(6 Cp) avec IT = 0,15 et Cp = {cp} : {0.15 / (6 * cp):.4f}")
    # efficacité de la carte ±3 sigma : probabilité de détecter un décalage de delta sigma
    for n_ in (5, 10):
        for d in (1.0, 1.5):
            pdet = stats.norm.sf(3 - d * math.sqrt(n_)) + stats.norm.cdf(-3 - d * math.sqrt(n_))
            print(f"  carte ±3 sigma, n = {n_}, décalage {d} sigma : P(détection au point suivant) = {pdet:.3f}")
    print(f"  fausse alarme ±3 sigma = {2 * stats.norm.sf(3) * 100:.3f} %")


if __name__ == "__main__":
    intervalles()
    oc()
    limites()
