"""Chapitre 08 : lecture d'un modèle de régression sur un plan d'expériences.

Plan factoriel complet 2^3 (facteurs A, B, C codés -1/+1) + 3 points au centre = 11 essais.
Réponse simulée (graine 808) : y = 50 + 4 A + 2,5 B + 0,3 C + 1,8 AB + bruit N(0 ; 0,8).
Modèle ajusté : constante + A + B + C + AB + AC + BC (moindres carrés ordinaires).
Puis élimination « en arrière » au seuil 5 % (critère supposé, non documenté par le guide).
Contraste : VIF sur des données d'observation où X1 et X2 sont corrélés (graine 809).
Usage : python3 ch08_plan.py [dossier_coordonnees]
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import sys, json, itertools
import numpy as np
from scipy import stats

rng = np.random.default_rng(808)
fact = np.array(list(itertools.product([-1, 1], repeat=3)), float)[:, ::-1]  # ordre standard (A varie le plus vite)
X3 = np.vstack([fact, np.zeros((3, 3))])
A, B, C = X3.T
y = 50 + 4 * A + 2.5 * B + 0.3 * C + 1.8 * A * B + rng.normal(0, 0.8, len(A))

def design(terms):
    cols = {"Constante": np.ones_like(A), "A": A, "B": B, "C": C,
            "AB": A * B, "AC": A * C, "BC": B * C, "A2": A ** 2, "B2": B ** 2, "C2": C ** 2}
    return np.column_stack([cols[t] for t in terms])

def vif(M, j):
    """VIF du terme j (hors constante) : 1/(1-R_j^2), R_j^2 de la régression de X_j sur les autres termes."""
    others = np.delete(M, j, axis=1)
    beta, *_ = np.linalg.lstsq(others, M[:, j], rcond=None)
    r = M[:, j] - others @ beta
    ss = np.sum((M[:, j] - M[:, j].mean()) ** 2)
    return np.inf if ss == 0 else 1 / (np.sum(r ** 2) / ss)

def fit(terms, yy=y, show=True):
    M = design(terms)
    n, p = M.shape
    beta, *_ = np.linalg.lstsq(M, yy, rcond=None)
    pred = M @ beta
    res = yy - pred
    ddl = n - p
    s2 = res @ res / ddl
    cov = s2 * np.linalg.inv(M.T @ M)
    se = np.sqrt(np.diag(cov))
    t = beta / se
    pv = 2 * stats.t.sf(np.abs(t), ddl)
    sst = np.sum((yy - yy.mean()) ** 2)
    r2 = 1 - res @ res / sst
    r2a = 1 - (1 - r2) * (n - 1) / ddl
    H = M @ np.linalg.inv(M.T @ M) @ M.T
    if show:
        print(f"Termes {terms} ; n = {n}, ddl = {ddl}, s = {np.sqrt(s2):.4f}, R2 = {r2:.4f}, R2aj = {r2a:.4f}")
        print("terme      coef     ET      t       p       VIF")
        for j, tname in enumerate(terms):
            v = vif(M, j) if tname != "Constante" else float("nan")
            print(f"{tname:9s} {beta[j]:7.3f} {se[j]:6.3f} {t[j]:7.2f} {pv[j]:9.2e} {v:6.2f}")
    return dict(beta=beta, se=se, t=t, p=pv, pred=pred, res=res, s=np.sqrt(s2), r2=r2, r2a=r2a, lev=np.diag(H), ddl=ddl)

print("Essais (A, B, C, y) :")
for a, b, c, v in zip(A, B, C, y):
    print(f"  {a:+.0f} {b:+.0f} {c:+.0f}  {v:.2f}")

full = ["Constante", "A", "B", "C", "AB", "AC", "BC"]
F = fit(full)

# élimination en arrière au seuil 5 % (hiérarchie non imposée)
terms = full[:]
while True:
    r = fit(terms, show=False)
    cand = [(r["p"][j], tn) for j, tn in enumerate(terms) if tn != "Constante"]
    pmax, tmax = max(cand)
    if pmax <= 0.05:
        break
    print(f"  retrait de {tmax} (p = {pmax:.4f})")
    terms.remove(tmax)
R = fit(terms)
print("Effets (2 x coefficient) du modèle réduit :", {t: round(2 * b, 3) for t, b in zip(terms, R["beta"]) if t != "Constante"})

print("Résidus du modèle réduit (observé, prédit, résidu, levier) :")
for v, pr, rr, h in zip(y, R["pred"], R["res"], R["lev"]):
    print(f"  {v:7.2f} {pr:7.2f} {rr:+6.2f} {h:.3f}")
sw = stats.shapiro(R["res"])
print(f"Shapiro-Wilk sur les résidus du modèle réduit : W = {sw.statistic:.4f}, p = {sw.pvalue:.3f}")

# courbure : moyenne des centres contre moyenne des points factoriels
yc, yf = y[8:].mean(), y[:8].mean()
print(f"Moyenne points factoriels = {yf:.3f}, moyenne centres = {yc:.3f}, écart = {yc - yf:+.3f}")

# piège : les trois carrés sont confondus sur ce plan
Mq = design(["Constante", "A", "B", "C", "A2", "B2", "C2"])
print("Rang de la matrice avec A2, B2, C2 :", np.linalg.matrix_rank(Mq), "sur", Mq.shape[1], "colonnes")
print("A2 == B2 == C2 :", np.allclose(A ** 2, B ** 2) and np.allclose(B ** 2, C ** 2))
Q = fit(["Constante", "A", "B", "AB", "A2"])

# contraste : données d'observation avec X1 et X2 corrélés
rng2 = np.random.default_rng(809)
x1 = rng2.normal(0, 1, 30)
x2 = 0.95 * x1 + np.sqrt(1 - 0.95 ** 2) * rng2.normal(0, 1, 30)
Mo = np.column_stack([np.ones(30), x1, x2])
print(f"Observation : r(X1, X2) = {np.corrcoef(x1, x2)[0, 1]:.3f}, VIF(X1) = {vif(Mo, 1):.2f}, VIF(X2) = {vif(Mo, 2):.2f}")

# meilleur sous-ensemble : nombre de régressions pour m termes candidats et au plus k termes
from math import comb
m = 6
for k in (2, 3, 6):
    print(f"Meilleur sous-ensemble, {m} termes candidats, au plus {k} termes : {sum(comb(m, j) for j in range(1, k + 1))} régressions")

if len(sys.argv) > 1:
    fmt = lambda pts: " ".join(f"({a:.3f},{b:.3f})" for a, b in pts)
    json.dump({"op": fmt(zip(R["pred"], y)), "rp": fmt(zip(R["pred"], R["res"]))},
              open(sys.argv[1] + "/plan.json", "w"), indent=0)
