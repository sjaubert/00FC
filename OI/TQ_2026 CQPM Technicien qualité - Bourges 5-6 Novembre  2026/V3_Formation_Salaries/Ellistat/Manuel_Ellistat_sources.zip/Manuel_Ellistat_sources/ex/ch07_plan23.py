"""Chapitre 07 : exemple simulé d'un plan complet 2^3 répliqué deux fois.
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.

Facteurs codés -1/+1 : A, B, C. Réponse simulée (graine 2026) :
    y = 40 + 3 A + 2 B + 0,4 C + 2,5 AB + bruit N(0 ; 1)
Seize essais (8 combinaisons x 2 répliques), ordre de réalisation tiré au hasard.
"""
import itertools
import numpy as np
from scipy import stats

rng = np.random.default_rng(2026)
VRAI = {"I": 40.0, "A": 3.0, "B": 2.0, "C": 0.4, "AB": 2.5}
SIGMA = 1.0

# plan de base en ordre standard (A varie le plus vite, convention de Yates)
base = np.array([[a, b, c] for c, b, a in itertools.product([-1, 1], repeat=3)])
plan = np.vstack([base, base])          # 2 répliques
N = len(plan)
A, B, C = plan.T
y_vrai = VRAI["I"] + VRAI["A"] * A + VRAI["B"] * B + VRAI["C"] * C + VRAI["AB"] * A * B
y = np.round(y_vrai + rng.normal(0, SIGMA, N), 1)
ordre = rng.permutation(N) + 1           # ordre de passage aléatoire

print("Essai | A  B  C | rep | ordre | y")
for i in range(N):
    print(f"{i+1:5d} | {A[i]:+d} {B[i]:+d} {C[i]:+d} | {1 + i // 8} | {ordre[i]:5d} | {y[i]:.1f}")

# ---------------------------------------------------------------- effets
termes = {"A": A, "B": B, "C": C, "AB": A * B, "AC": A * C, "BC": B * C, "ABC": A * B * C}
effets = {t: y[x == 1].mean() - y[x == -1].mean() for t, x in termes.items()}

# variance résiduelle à partir des répliques : modèle saturé sur les 8 cellules
moy_cell = {}
for i in range(N):
    moy_cell.setdefault(tuple(plan[i]), []).append(y[i])
ss_res = sum(((np.array(v) - np.mean(v)) ** 2).sum() for v in moy_cell.values())
ddl_res = N - 8
s2 = ss_res / ddl_res
s = np.sqrt(s2)
se_effet = 2 * s / np.sqrt(N)
tcrit = stats.t.ppf(0.975, ddl_res)
print(f"\nMoyenne générale = {y.mean():.3f}")
print(f"s résiduel = {s:.3f} (ddl = {ddl_res}) ; erreur-type d'un effet = {se_effet:.3f}")
print(f"t critique (5 %, bilatéral, {ddl_res} ddl) = {tcrit:.3f} ; seuil sur |effet| = {tcrit*se_effet:.3f}")
print("\nTerme | effet | coefficient | t | p")
tri = sorted(effets, key=lambda t: -abs(effets[t]))
for t in tri:
    tv = effets[t] / se_effet
    p = 2 * stats.t.sf(abs(tv), ddl_res)
    print(f"{t:4s} | {effets[t]:+.3f} | {effets[t]/2:+.3f} | {tv:+.2f} | {p:.4f}")

# ---------------------------------------------------------------- graphes des effets
print("\nMoyennes aux niveaux (effets principaux)")
for t in ["A", "B", "C"]:
    x = termes[t]
    print(f"{t} : bas {y[x == -1].mean():.3f} ; haut {y[x == 1].mean():.3f}")
print("\nMoyennes croisées A x B")
for b in [-1, 1]:
    print(f"B={b:+d} : A- {y[(A == -1) & (B == b)].mean():.3f} ; A+ {y[(A == 1) & (B == b)].mean():.3f}")
for a_ in [-1, 1]:
    print(f"A={a_:+d} : effet de B = {y[(A == a_) & (B == 1)].mean() - y[(A == a_) & (B == -1)].mean():.3f}")
print("\nMoyennes croisées A x C")
for c in [-1, 1]:
    print(f"C={c:+d} : A- {y[(A == -1) & (C == c)].mean():.3f} ; A+ {y[(A == 1) & (C == c)].mean():.3f}")

# ---------------------------------------------------------------- modèle réduit
X = np.column_stack([np.ones(N), A, B, A * B])
beta, *_ = np.linalg.lstsq(X, y, rcond=None)
res = y - X @ beta
ddl_m = N - X.shape[1]
s_m = np.sqrt((res ** 2).sum() / ddl_m)
r2 = 1 - (res ** 2).sum() / ((y - y.mean()) ** 2).sum()
r2aj = 1 - (1 - r2) * (N - 1) / ddl_m
print("\nModèle réduit y = b0 + bA A + bB B + bAB AB")
print("coefficients :", np.round(beta, 3))
print(f"s résiduel = {s_m:.3f} (ddl {ddl_m}) ; R2 = {r2:.4f} ; R2 ajusté = {r2aj:.4f}")
xo = np.array([1, 1, 1, 1])
print(f"Prédiction en A=+1, B=+1 : {xo @ beta:.3f}")
print(f"Prédiction en A=-1, B=+1 : {np.array([1,-1,1,-1]) @ beta:.3f}")
print(f"Prédiction en A=+1, B=-1 : {np.array([1,1,-1,-1]) @ beta:.3f}")
print(f"Prédiction en A=-1, B=-1 : {np.array([1,-1,-1,1]) @ beta:.3f}")
