"""Chapitre 05 : effet de l'appariement (données simulées, graine 2026).

Calcul refait en Python (scipy), ce n'est pas une sortie d'Ellistat.
Scénario : 10 pièces mesurées chacune par deux instruments A et B.
  - diamètre vrai des pièces : moyenne 11,92 mm, écart-type entre pièces 0,020 mm ;
  - biais de B par rapport à A : +0,004 mm ;
  - bruit de mesure de chaque instrument : écart-type 0,002 mm.
On compare le test t apparié (correct) au test t pour échantillons indépendants (erroné ici).
"""
import numpy as np
from scipy import stats

rng = np.random.default_rng(2026)
n = 10
vrai = rng.normal(11.92, 0.020, n)
a = np.round(vrai + rng.normal(0, 0.002, n), 3)
b = np.round(vrai + 0.004 + rng.normal(0, 0.002, n), 3)

print("pièce ; A ; B ; B - A")
for i, (u, v) in enumerate(zip(a, b), 1):
    print(f"{i:2d} ; {u:.3f} ; {v:.3f} ; {v-u:+.3f}")
d = b - a
print(f"moyenne A = {a.mean():.4f}, s A = {a.std(ddof=1):.4f}")
print(f"moyenne B = {b.mean():.4f}, s B = {b.std(ddof=1):.4f}")
print(f"écart moyen B - A = {d.mean():.4f}, s des différences = {d.std(ddof=1):.4f}")
tp = stats.ttest_rel(b, a)
ti = stats.ttest_ind(b, a)
print(f"t apparié : t = {tp.statistic:.3f}, ddl = {n-1}, p = {tp.pvalue:.3g}")
print(f"t indépendant : t = {ti.statistic:.3f}, ddl = {2*n-2}, p = {ti.pvalue:.3g}")
W, pW = stats.shapiro(d)
print(f"Shapiro-Wilk sur les différences : W = {W:.3f}, p = {pW:.3f}")
print("coordonnées pour la figure (pièce, A, B) :")
print(" ".join(f"({i},{u:.3f})" for i, u in enumerate(a, 1)))
print(" ".join(f"({i},{v:.3f})" for i, v in enumerate(b, 1)))
