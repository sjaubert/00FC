"""Outils communs aux scripts du chapitre 09 (Tolérancement).

Toutes les données de ce chapitre sont INVENTÉES (simulées, graine fixée),
sauf l'exemple des butées TQ6 relu via ch01_commun.
Les formules de composition sont des formules classiques (hors guide Ellistat)
ou des reconstitutions présentées comme hypothèses dans le texte.
"""
import math

import numpy as np
from scipy import stats

GRAINE = 2026          # graine commune, citée dans le texte


def fr(x, nd=3):
    """Format français (virgule décimale)."""
    return f"{x:.{nd}f}".replace(".", ",")


def frint(x):
    """Entier avec espace fine comme séparateur de milliers (LaTeX)."""
    s = f"{int(round(x)):,}".replace(",", "\\,")
    return s


def ppm_normal(mu, sigma, lsl, usl):
    """Taux hors tolérance (ppm) d'une loi normale."""
    p = stats.norm.cdf((lsl - mu) / sigma) + stats.norm.sf((usl - mu) / sigma)
    return 1e6 * p


def cpk(mu, sigma, lsl, usl):
    return min(usl - mu, mu - lsl) / (3 * sigma)


def coords(xs, ys, nd=4):
    """Chaîne de coordonnées pgfplots."""
    return " ".join(f"({x:.{nd}f},{y:.{nd}f})" for x, y in zip(xs, ys))


def histo_coords(x, bornes):
    """Histogramme en densité (pour ybar interval de pgfplots)."""
    h, e = np.histogram(x, bins=bornes, density=True)
    pts = [(e[i], h[i]) for i in range(len(h))] + [(e[-1], 0.0)]
    return " ".join(f"({a:.4f},{b:.3f})" for a, b in pts)


def titre(t):
    print("\n" + "=" * 70 + "\n" + t + "\n" + "=" * 70)
