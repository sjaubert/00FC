"""Outils communs aux scripts du chapitre 10 (fiabilité).

Tout est calculé à la main avec numpy et scipy (lifelines n'est pas installé).
Formules classiques de fiabilité, hors guide Ellistat :
  - Weibull 2 paramètres : R(t) = exp[-(t/eta)^beta]
  - maximum de vraisemblance avec censures à droite,
  - régression de rang médian (approximation de Benard, Y en fonction de X),
  - intervalles de confiance par la matrice de Fisher (échelle log),
  - estimateur de Kaplan-Meier.
"""
from pathlib import Path
import math

import numpy as np
from scipy import optimize, stats

DONNEES = Path(__file__).resolve().parent.parent / "donnees"


def lire_colonne(nom):
    """Lit un fichier à une colonne (en-tête = nom de la colonne)."""
    lignes = (DONNEES / nom).read_text(encoding="utf-8-sig").split()
    return np.array([float(x.replace(",", ".")) for x in lignes[1:]])


# ------------------------------------------------------------------ Weibull
def R(t, eta, beta):
    return np.exp(-(np.asarray(t, float) / eta) ** beta)


def mttf(eta, beta):
    return eta * math.gamma(1 + 1 / beta)


def bq(q, eta, beta):
    """Durée B_q : instant où q (fraction) de la population a défailli."""
    return eta * (-math.log(1 - q)) ** (1 / beta)


def loglik(params, t, d):
    """Log-vraisemblance Weibull 2P ; d = 1 défaillance, 0 censure à droite.
    params = (ln eta, ln beta)."""
    leta, lbeta = params
    eta, beta = math.exp(leta), math.exp(lbeta)
    z = t / eta
    return np.sum(d * (lbeta - leta + (beta - 1) * np.log(z))) - np.sum(z ** beta)


def mle(t, d=None):
    """Maximum de vraisemblance. Renvoie eta, beta, matrice de covariance
    de (ln eta, ln beta) obtenue par le hessien numérique."""
    t = np.asarray(t, float)
    d = np.ones_like(t) if d is None else np.asarray(d, float)
    x0 = (math.log(t.mean()), 0.0)
    res = optimize.minimize(lambda p: -loglik(p, t, d), x0, method="Nelder-Mead",
                            options={"xatol": 1e-10, "fatol": 1e-12, "maxiter": 20000})
    p = res.x
    H = hessien(lambda q: -loglik(q, t, d), p)
    cov = np.linalg.inv(H)
    return math.exp(p[0]), math.exp(p[1]), cov, -res.fun


def hessien(f, p, h=1e-4):
    p = np.asarray(p, float)
    n = len(p)
    H = np.zeros((n, n))
    for i in range(n):
        for j in range(n):
            ei = np.eye(n)[i] * h
            ej = np.eye(n)[j] * h
            H[i, j] = (f(p + ei + ej) - f(p + ei - ej) - f(p - ei + ej) + f(p - ei - ej)) / (4 * h * h)
    return H


def ic_fisher(eta, beta, cov, conf=0.95):
    """IC bilatéraux sur eta et beta (normalité de ln eta et ln beta)."""
    z = stats.norm.ppf(0.5 + conf / 2)
    se_le, se_lb = math.sqrt(cov[0, 0]), math.sqrt(cov[1, 1])
    return ((eta * math.exp(-z * se_le), eta * math.exp(z * se_le)),
            (beta * math.exp(-z * se_lb), beta * math.exp(z * se_lb)))


def rangs_benard(n):
    i = np.arange(1, n + 1)
    return (i - 0.3) / (n + 0.4)


def regression_rang_median(t):
    """Régression Y = ln(-ln(1-F)) sur X = ln t (données complètes)."""
    t = np.sort(np.asarray(t, float))
    F = rangs_benard(len(t))
    X, Y = np.log(t), np.log(-np.log(1 - F))
    pente, ordonnee, r, _, _ = stats.linregress(X, Y)
    beta = pente
    eta = math.exp(-ordonnee / beta)
    return eta, beta, r ** 2, X, Y


# ------------------------------------------------------------------ Kaplan-Meier
def kaplan_meier(t, d):
    """Renvoie la liste des (temps, S(t) juste après) aux instants de défaillance,
    avec le nombre à risque et le nombre de défaillances."""
    t = np.asarray(t, float)
    d = np.asarray(d, int)
    ordre = np.lexsort((-d, t))   # à égalité, la défaillance avant la censure
    t, d = t[ordre], d[ordre]
    S = 1.0
    sorties = []
    for ti in np.unique(t[d == 1]):
        a_risque = np.sum(t >= ti)
        nd = np.sum((t == ti) & (d == 1))
        S *= 1 - nd / a_risque
        sorties.append((ti, a_risque, nd, S))
    return sorties


def fmt(x, nd=2):
    """Format français (virgule décimale)."""
    return f"{x:.{nd}f}".replace(".", ",")
