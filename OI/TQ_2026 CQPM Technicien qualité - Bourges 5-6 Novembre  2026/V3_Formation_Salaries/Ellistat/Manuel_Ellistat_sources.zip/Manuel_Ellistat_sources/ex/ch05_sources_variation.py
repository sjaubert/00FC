"""Chapitre 05 : décomposition de variance pour des facteurs emboîtés (données simulées, graine 2026).

Calcul refait en Python (numpy, scipy, statsmodels), ce n'est pas une sortie d'Ellistat.
Structure reprise de l'exemple du guide : Machine > Broche > Pièce > répétitions,
3 machines, 4 broches par machine (12), 5 pièces par broche (60), 2 mesures par pièce (120).
Écarts-types vrais choisis pour l'exemple (mm) : Machine 0,012 ; Broche 0,008 ; Pièce 0,002 ;
répétabilité 0,0015. Moyenne vraie 11,955. Tolérance des butées 11,85 / 12,00 (cible 11,925).

Méthodes (hors guide) :
  - carrés moyens et composantes par l'espérance des carrés moyens (plan équilibré) ;
  - contrôle par REML (statsmodels MixedLM) : mêmes valeurs quand aucune composante n'est négative ;
  - F = CM du niveau / CM du niveau inférieur ;
  - IC 95 % des parts de variance par bootstrap paramétrique (2000 tirages, graine 2027) :
    c'est notre choix, la méthode d'Ellistat n'est pas documentée ;
  - % de l'IT = 6 sigma / IT ; simulation de Ppk en retirant chaque composante ;
  - verdicts : significatif si p <= 0,05 ; important si 6 sigma >= delta = 10 % de l'IT (notre lecture).
"""
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
import warnings

warnings.filterwarnings("ignore")

M, B, P, R = 3, 4, 5, 2
SIG = {"Machine": 0.012, "Broche": 0.008, "Pièce": 0.002, "Répétabilité": 0.0015}
MU, LSL, USL = 11.955, 11.85, 12.00
IT, CIBLE = USL - LSL, (USL + LSL) / 2
DELTA = 0.10 * IT


def simule(rng, sig):
    m = rng.normal(0, sig["Machine"], M)[:, None, None, None]
    b = rng.normal(0, sig["Broche"], (M, B))[:, :, None, None]
    p = rng.normal(0, sig["Pièce"], (M, B, P))[:, :, :, None]
    e = rng.normal(0, sig["Répétabilité"], (M, B, P, R))
    return MU + m + b + p + e


def ems(y):
    """Carrés moyens et composantes de variance d'un tableau y[M,B,P,R]."""
    ybar = y.mean()
    ym = y.mean(axis=(1, 2, 3))
    yb = y.mean(axis=(2, 3))
    yp = y.mean(axis=3)
    ss = {
        "Machine": B * P * R * ((ym - ybar) ** 2).sum(),
        "Broche": P * R * ((yb - ym[:, None]) ** 2).sum(),
        "Pièce": R * ((yp - yb[:, :, None]) ** 2).sum(),
        "Répétabilité": ((y - yp[..., None]) ** 2).sum(),
    }
    ddl = {"Machine": M - 1, "Broche": M * (B - 1), "Pièce": M * B * (P - 1), "Répétabilité": M * B * P * (R - 1)}
    cm = {k: ss[k] / ddl[k] for k in ss}
    v = {
        "Répétabilité": cm["Répétabilité"],
        "Pièce": max(0.0, (cm["Pièce"] - cm["Répétabilité"]) / R),
        "Broche": max(0.0, (cm["Broche"] - cm["Pièce"]) / (P * R)),
        "Machine": max(0.0, (cm["Machine"] - cm["Broche"]) / (B * P * R)),
    }
    return ss, ddl, cm, v


rng = np.random.default_rng(2026)
y = simule(rng, SIG)
ss, ddl, cm, v = ems(y)
niveaux = ["Machine", "Broche", "Pièce", "Répétabilité"]
tot = sum(v.values())
inf = {"Machine": "Broche", "Broche": "Pièce", "Pièce": "Répétabilité"}

# Bootstrap paramétrique des parts de variance
rngb = np.random.default_rng(2027)
sig_hat = {k: np.sqrt(v[k]) for k in v}
parts = {k: [] for k in niveaux}
for _ in range(2000):
    _, _, _, vb = ems(simule(rngb, sig_hat))
    tb = sum(vb.values())
    for k in niveaux:
        parts[k].append(100 * vb[k] / tb)

print(f"N = {y.size}, moyenne = {y.mean():.4f}, s global = {y.std(ddof=1):.4f}")
print("niveau ; ddl ; CM ; F ; p ; sigma ; % variance ; IC95 % (bootstrap) ; % IT")
for k in niveaux:
    if k in inf:
        F = cm[k] / cm[inf[k]]
        p = stats.f.sf(F, ddl[k], ddl[inf[k]])
        fp = f"{F:7.2f} ; {p:.3g}"
    else:
        fp = "   -    ; -"
    lo, hi = np.percentile(parts[k], [2.5, 97.5])
    s = np.sqrt(v[k])
    print(f"{k:13s}; {ddl[k]:3d} ; {cm[k]:.3e} ; {fp} ; {s:.4f} ; {100*v[k]/tot:5.1f} ; "
          f"[{lo:5.1f} ; {hi:5.1f}] ; {100*6*s/IT:5.1f}")
print(f"sigma total (somme des composantes) = {np.sqrt(tot):.4f}")
print(f"part au-dessus de Pièce (Machine + Broche) = {100*(v['Machine']+v['Broche'])/tot:.1f} %")
print(f"part portée par la hiérarchie (hors répétabilité) = {100*(1-v['Répétabilité']/tot):.1f} %")
print(f"% IT combinés en quadrature : sqrt(somme des carrés) = "
      f"{100*6*np.sqrt(tot)/IT:.1f} % ; somme simple = {sum(100*6*np.sqrt(v[k])/IT for k in niveaux):.1f} %")

print("\n--- Contrôle REML (statsmodels MixedLM) ---")
idx = np.indices(y.shape).reshape(4, -1).T
df = pd.DataFrame({"y": y.ravel(), "mach": idx[:, 0],
                   "broche": idx[:, 0] * 10 + idx[:, 1],
                   "piece": idx[:, 0] * 100 + idx[:, 1] * 10 + idx[:, 2]})
mod = smf.mixedlm("y ~ 1", df, groups="mach", re_formula="1",
                  vc_formula={"broche": "0 + C(broche)", "piece": "0 + C(piece)"})
res = mod.fit(reml=True, method="lbfgs")
vc = dict(zip(mod.exog_vc.names, res.vcomp))
print(f"REML sigma : Machine {np.sqrt(res.cov_re.iloc[0,0]):.4f} ; Broche {np.sqrt(vc['broche']):.4f} ; "
      f"Pièce {np.sqrt(vc['piece']):.4f} ; Répétabilité {np.sqrt(res.scale):.4f}")

print("\n--- Simulation de Ppk (moyenne observée conservée) ---")
m = y.mean()


def pp_ppk(var, moy=m):
    s = np.sqrt(var)
    return IT / (6 * s), min(USL - moy, moy - LSL) / (3 * s)


lignes = [("Situation actuelle", *pp_ppk(tot))]
for k in niveaux:
    lignes.append((f"Annuler {k}", *pp_ppk(tot - v[k])))
lignes.append(("Recentrer sur la cible", *pp_ppk(tot, CIBLE)))
best = max(niveaux, key=lambda k: pp_ppk(tot - v[k], CIBLE)[1])
lignes.append((f"Annuler {best} + recentrer", *pp_ppk(tot - v[best], CIBLE)))
for nom, a, b in [lignes[0]] + sorted(lignes[1:], key=lambda t: t[2]):
    print(f"{nom:30s} Pp = {a:.2f}  Ppk = {b:.2f}")

print(f"\n--- Matrice de décision (delta = 10 % IT = {DELTA:.3f} mm, notre lecture) ---")
for k in ["Machine", "Broche", "Pièce"]:
    F = cm[k] / cm[inf[k]]
    p = stats.f.sf(F, ddl[k], ddl[inf[k]])
    six = 6 * np.sqrt(v[k])
    print(f"{k:8s} : p = {p:.3g}, 6 sigma = {six:.4f} -> significatif {p <= 0.05}, 6 sigma >= delta {six >= DELTA}")

print("\n--- Comparaison : Pp/Ppk avec l'écart-type global s des 120 valeurs ---")
s_glob = y.std(ddof=1)
print(f"s global = {s_glob:.4f} -> Pp = {IT/(6*s_glob):.2f}, Ppk = {min(USL-m, m-LSL)/(3*s_glob):.2f}")

print("\n--- Multi-vari emboîté : moyennes par broche (x = rang de la broche 1..12) et par machine ---")
yb = y.mean(axis=(2, 3))
print("broches :", " ".join(f"({4*i+j+1},{yb[i, j]:.4f})" for i in range(M) for j in range(B)))
print("machines :", " ".join(f"{y[i].mean():.4f}" for i in range(M)))
yp = y.mean(axis=3)
print("pièces min/max par broche :", " ".join(f"[{yp[i,j].min():.4f};{yp[i,j].max():.4f}]" for i in range(M) for j in range(B)))
