# -*- coding: utf-8 -*-
"""Chapitre 02 - Comparaison de 2 moyens sur données SIMULÉES (graine 2036).

20 butées (vrai diamètre ~ N(11,92 ; 0,025)), mesurées 2 fois (avec reprise)
par A = micromètre (référence, sigma 0,002) et B = projecteur de profil
(sigma 0,006, biais 0,002 mm). Limite d'équivalence delta = T/20 = 0,0075 mm (fixée avant).
TOST (IC 90 %), limites d'agrément de Bland-Altman, pente de Deming,
rapport des variances de répétabilité, tendance dans l'ordre de saisie.
Calcul refait en Python : ce n'est pas une sortie d'Ellistat.
"""
import numpy as np
from scipy import stats

rng = np.random.default_rng(2036)
n, r, delta = 20, 2, 0.0075
vrai = 11.92 + 0.025 * rng.standard_normal(n)
A = np.round(vrai[:, None] + 0.002 * rng.standard_normal((n, r)), 3)
B = np.round(vrai[:, None] + 0.002 + 0.006 * rng.standard_normal((n, r)), 3)
mA, mB = A.mean(1), B.mean(1)
d = mB - mA
db, sd = d.mean(), d.std(ddof=1)
se = sd / np.sqrt(n)

# Q1 : TOST, IC 90 %
t90 = stats.t.ppf(0.95, n - 1)
ic = (db - t90 * se, db + t90 * se)
p_low = stats.t.sf((db + delta) / se, n - 1); p_high = stats.t.cdf((db - delta) / se, n - 1)
print(f"Écart moyen B - A = {db:.5f} mm ({100*db/delta:.0f} % de delta) ; s_d = {sd:.5f}")
print(f"IC 90 % = [{ic[0]:.5f} ; {ic[1]:.5f}] ; TOST p = max({p_low:.2g}, {p_high:.2g}) = {max(p_low, p_high):.2g}")

# Q3 : limites d'agrément
loa = (db - 1.96 * sd, db + 1.96 * sd)
hors = int(np.sum(np.abs(d) > delta))
print(f"Limites d'agrément (biais +/- 1,96 s_d) = [{loa[0]:.5f} ; {loa[1]:.5f}] ; pièces hors +/-delta : {hors}/{n}")

# Q4 : répétabilités
srA = np.sqrt(np.mean(A.var(axis=1, ddof=1))); srB = np.sqrt(np.mean(B.var(axis=1, ddof=1)))
F = srB ** 2 / srA ** 2; df = n * (r - 1)
icF = (F / stats.f.ppf(0.975, df, df), F / stats.f.ppf(0.025, df, df))
print(f"s_r(A) = {srA:.5f} ; s_r(B) = {srB:.5f} ; rapport des variances B/A = {F:.2f} ; IC 95 % [{icF[0]:.2f} ; {icF[1]:.2f}]")

# Q2 : Deming (lambda = rapport des variances d'erreur des moyennes, B sur A)
lam = (srB ** 2 / r) / (srA ** 2 / r)
sxx = np.var(mA, ddof=1); syy = np.var(mB, ddof=1); sxy = np.cov(mA, mB)[0, 1]
pente = (syy - lam * sxx + np.sqrt((syy - lam * sxx) ** 2 + 4 * lam * sxy ** 2)) / (2 * sxy)
ordo = mB.mean() - pente * mA.mean()
# IC par jackknife
jk = []
for i in range(n):
    a_, b_ = np.delete(mA, i), np.delete(mB, i)
    sx, sy, sxy_ = np.var(a_, ddof=1), np.var(b_, ddof=1), np.cov(a_, b_)[0, 1]
    jk.append((sy - lam * sx + np.sqrt((sy - lam * sx) ** 2 + 4 * lam * sxy_ ** 2)) / (2 * sxy_))
jk = np.array(jk); pseudo = n * pente - (n - 1) * jk
sej = pseudo.std(ddof=1) / np.sqrt(n); t95 = stats.t.ppf(0.975, n - 1)
print(f"lambda = {lam:.2f} ; pente de Deming = {pente:.4f} ; IC 95 % (jackknife) [{pente - t95*sej:.4f} ; {pente + t95*sej:.4f}] ; ordonnée = {ordo:.4f}")

# Q5 : tendance dans l'ordre de saisie
tr = stats.linregress(np.arange(1, n + 1), d)
print(f"Tendance de l'écart / rang : {tr.slope*1000:.4f} µm par pièce ; p = {tr.pvalue:.2g}")

# Nombre de pièces pour un TOST à 80 % de puissance (approximation, vrai écart = écart observé)
def puissance(nn, ecart, s):
    se_ = s / np.sqrt(nn); tc = stats.t.ppf(0.95, nn - 1)
    return max(0.0, stats.t.cdf((delta - ecart) / se_ - tc, nn - 1) - stats.t.cdf((-delta - ecart) / se_ + tc, nn - 1))
nn = 3
while puissance(nn, db, sd) < 0.80 and nn < 5000:
    nn += 1
print(f"Puissance TOST actuelle (n = {n}) ~ {puissance(n, db, sd):.2f} ; n pour 80 % ~ {nn}")

print("Bland-Altman (moyenne A, écart en µm) :", " ".join(f"({x:.3f},{1000*y:.1f})" for x, y in zip(mA, d)))
print(f"Pour la figure : biais {1000*db:.2f} µm ; LoA {1000*loa[0]:.2f} / {1000*loa[1]:.2f} µm ; x de {mA.min():.3f} à {mA.max():.3f}")
