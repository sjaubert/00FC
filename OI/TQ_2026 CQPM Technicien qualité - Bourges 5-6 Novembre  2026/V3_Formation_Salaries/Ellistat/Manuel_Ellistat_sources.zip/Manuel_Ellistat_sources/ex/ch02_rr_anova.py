# -*- coding: utf-8 -*-
"""Chapitre 02 - R&R par ANOVA à deux facteurs croisés avec interaction
et par la méthode des moyennes et étendues, sur le jeu R&R d'exemple.

Calcul refait en Python (statsmodels + contrôle matriciel à la main) :
ce n'est pas une sortie d'Ellistat.

Les opérateurs sont anonymisés A à G dans l'ordre d'apparition du fichier.
Tolérance : le jeu n'en fournit pas ; on SUPPOSE T = 0,30 mm (hypothèse
de travail annoncée dans le texte).
Usage : python3 ch02_rr_anova.py [chemin du fichier csv]
"""
import sys
import string
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm

T = 0.30          # tolérance supposée (mm)
K_SIG = 6.0       # dispersion comptée en 6 sigma (variante 5,15 en fin)

import os
chemin = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "donnees", "RR_exemple.csv")
d = pd.read_csv(chemin, sep=";")
noms = list(dict.fromkeys(d["operateur"]))
code = {n: string.ascii_uppercase[i] for i, n in enumerate(noms)}
d["op"] = d["operateur"].map(code)
d["piece"] = d["part"].astype(int)
d["rep"] = d.groupby(["op", "piece"]).cumcount() + 1

p = d["piece"].nunique(); o = d["op"].nunique(); r = d["rep"].nunique()
N = len(d)
print(f"Plan : {p} pièces x {o} opérateurs x {r} répétitions = {N} mesures")
print(f"Moyenne générale {d.mesure.mean():.4f} ; min {d.mesure.min()} ; max {d.mesure.max()}")

# ---------------------------------------------------------------- ANOVA à la main
y = d["mesure"].to_numpy()
gm = y.mean()
mP = d.groupby("piece")["mesure"].mean()
mO = d.groupby("op")["mesure"].mean()
mPO = d.groupby(["piece", "op"])["mesure"].mean()
SSP = o * r * ((mP - gm) ** 2).sum()
SSO = p * r * ((mO - gm) ** 2).sum()
SSPO_cells = r * ((mPO - gm) ** 2).sum()
SSPO = SSPO_cells - SSP - SSO
SST = ((y - gm) ** 2).sum()
SSE = SST - SSPO_cells
dfP, dfO, dfPO, dfE = p - 1, o - 1, (p - 1) * (o - 1), p * o * (r - 1)
MSP, MSO, MSPO, MSE = SSP / dfP, SSO / dfO, SSPO / dfPO, SSE / dfE
# modèle croisé à effets aléatoires : P et O testés contre l'interaction
FP, FO, FPO = MSP / MSPO, MSO / MSPO, MSPO / MSE
pP = stats.f.sf(FP, dfP, dfPO); pO = stats.f.sf(FO, dfO, dfPO); pPO = stats.f.sf(FPO, dfPO, dfE)
print("\nTable d'ANOVA (effets aléatoires, P et O testés contre P x O)")
print(f"{'Source':12s}{'ddl':>5s}{'SC':>12s}{'CM':>12s}{'F':>9s}{'p':>10s}")
for nom, df_, ss, ms, F, pv in [("Pièces", dfP, SSP, MSP, FP, pP), ("Opérateurs", dfO, SSO, MSO, FO, pO),
                                 ("P x O", dfPO, SSPO, MSPO, FPO, pPO), ("Répétition", dfE, SSE, MSE, None, None),
                                 ("Total", N - 1, SST, None, None, None)]:
    print(f"{nom:12s}{df_:5d}{ss:12.6f}" + (f"{ms:12.7f}" if ms is not None else " " * 12)
          + (f"{F:9.3f}{pv:10.2e}" if F is not None else ""))

# contrôle par statsmodels (somme des carrés de type II, plan équilibré)
fit = smf.ols("mesure ~ C(piece) * C(op)", data=d).fit()
tab = anova_lm(fit, typ=2)
assert np.allclose(tab["sum_sq"].values, [SSP, SSO, SSPO, SSE])
print("Contrôle statsmodels : sommes des carrés identiques.")

# ---------------------------------------------------------------- composantes de variance
def comp(MSPO_, MSE_, MSP_, MSO_):
    s2E = MSE_
    s2PO = max(0.0, (MSPO_ - MSE_) / r)
    s2O = max(0.0, (MSO_ - MSPO_) / (p * r))
    s2P = max(0.0, (MSP_ - MSPO_) / (o * r))
    return s2E, s2O, s2PO, s2P

def rapport(titre, s2E, s2O, s2PO, s2P):
    s2AV = s2O + s2PO
    s2GRR = s2E + s2AV
    s2TV = s2GRR + s2P
    sd = lambda v: np.sqrt(v)
    print(f"\n{titre}")
    print(f"{'Composante':22s}{'variance':>12s}{'%contrib':>10s}{'sigma':>10s}{'6 sigma':>10s}{'%VT':>8s}{'%T':>8s}")
    for nom, v in [("Répétabilité EV", s2E), ("Opérateurs", s2O), ("Interaction PxO", s2PO),
                   ("Reproductibilité AV", s2AV), ("GRR", s2GRR), ("Pièces PV", s2P), ("Totale TV", s2TV)]:
        print(f"{nom:22s}{v:12.3e}{100*v/s2TV:10.2f}{sd(v):10.5f}{K_SIG*sd(v):10.4f}"
              f"{100*sd(v)/sd(s2TV):8.1f}{100*K_SIG*sd(v)/T:8.1f}")
    ndc = 1.41 * sd(s2P) / sd(s2GRR)
    print(f"ndc = 1,41 x PV/GRR = {ndc:.3f} -> tronqué {int(np.floor(ndc))}")
    Cpc = T / (K_SIG * sd(s2GRR))
    print(f"%GRR/VT = {100*sd(s2GRR)/sd(s2TV):.1f} % ; %GRR/T (6s) = {100*K_SIG*sd(s2GRR)/T:.1f} % ; "
          f"%GRR/T (5,15s) = {100*5.15*sd(s2GRR)/T:.1f} %")
    print(f"Cpc supposé = T/(6 sGRR) = {Cpc:.3f}  (100/Cpc = {100/Cpc:.1f} %) ; avec 5,15 : {T/(5.15*sd(s2GRR)):.3f}")
    print(f"Tolérance mini pour Cpc = 4 : {4*K_SIG*sd(s2GRR):.3f} mm ; pour Cpc = 10 : {10*K_SIG*sd(s2GRR):.3f} mm")
    return dict(EV=sd(s2E), AV=sd(s2AV), GRR=sd(s2GRR), PV=sd(s2P), TV=sd(s2TV), ndc=ndc)

res_complet = rapport("Composantes (modèle complet avec interaction)", *comp(MSPO, MSE, MSP, MSO))

# interaction regroupée si p > 0,25 (règle AIAG MSA)
SSpool = SSPO + SSE; dfpool = dfPO + dfE; MSpool = SSpool / dfpool
print(f"\nInteraction p = {pPO:.3g} : regroupement {'possible' if pPO > 0.25 else 'NON (interaction significative)'}")
print(f"CM regroupé = {MSpool:.7f} (ddl {dfpool}) ; F pièces = {MSP/MSpool:.3f} (p = {stats.f.sf(MSP/MSpool, dfP, dfpool):.3g}) ; "
      f"F opérateurs = {MSO/MSpool:.3f} (p = {stats.f.sf(MSO/MSpool, dfO, dfpool):.3g})")
s2E_p = MSpool
s2O_p = max(0.0, (MSO - MSpool) / (p * r))
s2P_p = max(0.0, (MSP - MSpool) / (o * r))
rapport("Composantes avec interaction regroupée (règle MSA p > 0,25)", s2E_p, s2O_p, 0.0, s2P_p)

# ---------------------------------------------------------------- moyennes et étendues
d2 = {2: 1.1284, 3: 1.6926, 4: 2.0588, 5: 2.3259, 6: 2.5344, 7: 2.7044, 8: 2.8472, 9: 2.9700, 10: 3.0775}
d3 = {2: 0.8525, 3: 0.8884, 4: 0.8798, 5: 0.8641, 6: 0.8480, 7: 0.8332, 8: 0.8198, 9: 0.8078, 10: 0.7971}
d2star_g1 = lambda m: np.sqrt(d2[m] ** 2 + d3[m] ** 2)   # approximation de Duncan, g = 1
K1 = 1 / d2[r]
K2 = 1 / d2star_g1(o)
K3 = 1 / d2star_g1(p)
Rbar_op = d.groupby(["op", "piece"])["mesure"].agg(lambda x: x.max() - x.min()).groupby("op").mean()
Rbarbar = Rbar_op.mean()
Xdiff = mO.max() - mO.min()
Rp = mP.max() - mP.min()
EV = Rbarbar * K1
AV2 = (Xdiff * K2) ** 2 - EV ** 2 / (p * r)
AV = np.sqrt(max(0.0, AV2))
GRR = np.sqrt(EV ** 2 + AV ** 2)
PV = Rp * K3
TV = np.sqrt(GRR ** 2 + PV ** 2)
print("\nMéthode des moyennes et étendues")
print(f"K1 = {K1:.4f} (r={r}) ; K2 = {K2:.4f} (o={o}) ; K3 = {K3:.4f} (p={p})")
print("R moyen par opérateur :", {k: round(v, 4) for k, v in Rbar_op.items()})
print(f"R double barre = {Rbarbar:.5f} ; X diff = {Xdiff:.5f} ; R pièces = {Rp:.5f}")
print(f"EV = {EV:.5f} ; AV = {AV:.5f} ; GRR = {GRR:.5f} ; PV = {PV:.5f} ; TV = {TV:.5f}")
print(f"%GRR/VT = {100*GRR/TV:.1f} % ; %GRR/T (6s) = {100*6*GRR/T:.1f} % ; ndc = {1.41*PV/GRR:.3f}")

# ---------------------------------------------------------------- sensibilité : sans l'opérateur G
def anova_composantes(dd):
    pp = dd.piece.nunique(); oo = dd.op.nunique(); rr = dd.rep.nunique()
    yy = dd.mesure.to_numpy(); g = yy.mean()
    a = dd.groupby("piece").mesure.mean(); b = dd.groupby("op").mesure.mean()
    c = dd.groupby(["piece", "op"]).mesure.mean()
    sp = oo * rr * ((a - g) ** 2).sum(); so = pp * rr * ((b - g) ** 2).sum()
    sc = rr * ((c - g) ** 2).sum(); spo = sc - sp - so; se = ((yy - g) ** 2).sum() - sc
    msp, mso, mspo, mse = sp / (pp - 1), so / (oo - 1), spo / ((pp - 1) * (oo - 1)), se / (pp * oo * (rr - 1))
    pint = stats.f.sf(mspo / mse, (pp - 1) * (oo - 1), pp * oo * (rr - 1))
    s2E = mse; s2PO = max(0, (mspo - mse) / rr); s2O = max(0, (mso - mspo) / (pp * rr)); s2P = max(0, (msp - mspo) / (oo * rr))
    return pint, s2E, s2O, s2PO, s2P
pint, *cs = anova_composantes(d[d.op != "G"].copy())
print(f"\nSans l'opérateur G : p interaction = {pint:.3g}")
rapport("Composantes sans l'opérateur G (6 opérateurs, 120 mesures)", *cs)

# ---------------------------------------------------------------- sensibilité : sans la mesure la plus éloignée
print("\nMoyennes opérateurs :", {k: round(v, 4) for k, v in mO.items()})
print("Moyennes pièces :", {k: round(v, 4) for k, v in mP.items()})
cell = d.groupby(["op", "piece"])["mesure"].agg(lambda x: x.max() - x.min())
print("Cinq plus grandes étendues de cellule :")
print(cell.sort_values(ascending=False).head(5))

# ---------------------------------------------------------------- données pour les figures
with open(sys.argv[2] if len(sys.argv) > 2 else "/dev/null", "w") as f:
    f.write("% mesures par pièce (x décalé par opérateur)\n")
    for k, op in enumerate(sorted(code.values())):
        dd = d[d.op == op]
        f.write(f"% op {op}\n\\addplot+[only marks] coordinates {{" + " ".join(
            f"({pc + (k - 3) * 0.09:.2f},{m:.2f})" for pc, m in zip(dd.piece, dd.mesure)) + "};\n")
    f.write("% interaction : moyennes pièce x opérateur\n")
    for op in sorted(code.values()):
        f.write(f"\\addplot coordinates {{" + " ".join(
            f"({pc},{mPO[(pc, op)]:.3f})" for pc in range(1, p + 1)) + "};\n")
    f.write("% étendues moyennes par opérateur\n")
    f.write(" ".join(f"({k},{v:.4f})" for k, v in Rbar_op.items()) + "\n")
