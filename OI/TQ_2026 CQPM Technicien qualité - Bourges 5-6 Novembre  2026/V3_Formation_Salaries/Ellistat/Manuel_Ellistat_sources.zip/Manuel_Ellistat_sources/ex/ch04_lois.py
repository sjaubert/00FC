"""Chapitre 04 : lois discrètes et continues.

1. Probabilités binomiale B(50 ; 0,04), Poisson P(2), hypergéométrique H(N=500, K=20, n=50).
2. Intervalle de confiance d'une proportion pour 2 défectueux sur 50 (Clopper-Pearson, Wilson).
3. Dimensionnement a priori du rebut (loi normale) sur la tolérance des butées.
4. Contrôle des constantes des densités tracées dans le chapitre.
Calcul refait en Python : ce ne sont pas des sorties d'Ellistat.
"""
import math
from scipy import stats

LSL, USL = 11.85, 12.00


def discretes():
    n, p = 50, 0.04
    lam = n * p
    N, K = 500, 20
    b, po, h = stats.binom(n, p), stats.poisson(lam), stats.hypergeom(N, K, n)
    print("k  binom  poisson  hypergeom")
    for k in range(0, 9):
        print(f"{k}  {b.pmf(k):.4f}  {po.pmf(k):.4f}  {h.pmf(k):.4f}")
    for nom, loi in (("binomiale", b), ("Poisson", po), ("hypergéométrique", h)):
        print(f"{nom}: moyenne = {loi.mean():.3f}, variance = {loi.var():.3f}, P(X<=2) = {loi.cdf(2):.4f}, P(X>=5) = {loi.sf(4):.4f}")
    print("coordonnées binomiale :", " ".join(f"({k},{b.pmf(k):.4f})" for k in range(0, 9)))
    print("coordonnées Poisson   :", " ".join(f"({k},{po.pmf(k):.4f})" for k in range(0, 9)))
    print("coordonnées hypergéo  :", " ".join(f"({k},{h.pmf(k):.4f})" for k in range(0, 9)))


def ic_proportion(x=2, n=50, conf=0.95):
    a = 1 - conf
    lo = stats.beta.ppf(a / 2, x, n - x + 1) if x > 0 else 0.0
    hi = stats.beta.ppf(1 - a / 2, x + 1, n - x)
    hi_uni = stats.beta.ppf(conf, x + 1, n - x)
    z = stats.norm.ppf(1 - a / 2)
    ph = x / n
    c = ph + z * z / (2 * n)
    r = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n))
    d = 1 + z * z / n
    wald = z * math.sqrt(ph * (1 - ph) / n)
    print(f"\n{x}/{n} : p̂ = {ph:.3f}")
    print(f"Clopper-Pearson {conf:.0%} bilatéral : [{lo:.4f} ; {hi:.4f}]")
    print(f"Clopper-Pearson unilatéral {conf:.0%} borne sup : {hi_uni:.4f}")
    print(f"Wilson : [{(c - r) / d:.4f} ; {(c + r) / d:.4f}]")
    print(f"Wald (à éviter) : [{ph - wald:.4f} ; {ph + wald:.4f}]")
    # taille d'échantillon pour borne sup 95 % unilatérale <= 2 % avec 0 défectueux
    for cible in (0.05, 0.02, 0.01):
        nmin = math.ceil(math.log(0.05) / math.log(1 - cible))
        print(f"0 défectueux : n minimal pour borne sup 95 % <= {cible:.0%} : {nmin}")


def rebut_a_priori():
    print("\nRebut a priori, loi normale, tolérance 11,85 / 12,00")
    for sig in (0.0215, 0.0264):
        for mu in (11.925, 11.9, 11.8867):
            pinf = stats.norm.cdf((LSL - mu) / sig)
            psup = stats.norm.sf((USL - mu) / sig)
            cp = (USL - LSL) / (6 * sig)
            cpk = min(USL - mu, mu - LSL) / (3 * sig)
            print(f"sigma {sig}  mu {mu}: P<LSL = {pinf:.5f}  P>USL = {psup:.6f}  total = {(pinf + psup) * 100:.3f} %  ({(pinf + psup) * 1e6:.0f} ppm)  Cp {cp:.2f}  Cpk {cpk:.2f}")
    mu, sig = 11.8867, 0.0215
    print(f"médiane = {mu}, Q1 = {stats.norm.ppf(0.25, mu, sig):.4f}")


def constantes():
    print("\nConstantes des densités (figures)")
    print(f"Student nu=3 : {math.gamma(2) / (math.sqrt(3 * math.pi) * math.gamma(1.5)):.5f}")
    print(f"Chi2 k=4 : 1/(2^2 Gamma(2)) = {1 / (4 * math.gamma(2)):.5f}")
    print(f"Beta(2,5) : 1/B(2,5) = {1 / (math.gamma(2) * math.gamma(5) / math.gamma(7)):.1f}")
    # contrôle par scipy en un point
    print(f"t3(1) = {stats.t.pdf(1, 3):.5f} ; chi2_4(2) = {stats.chi2.pdf(2, 4):.5f} ; beta(0,3) = {stats.beta.pdf(0.3, 2, 5):.5f}")
    print(f"lognorm(0,0.5) en 1 = {stats.lognorm.pdf(1, 0.5):.5f} ; weibull(1.5,1) en 1 = {stats.weibull_min.pdf(1, 1.5):.5f}")


if __name__ == "__main__":
    discretes()
    ic_proportion()
    rebut_a_priori()
    constantes()
