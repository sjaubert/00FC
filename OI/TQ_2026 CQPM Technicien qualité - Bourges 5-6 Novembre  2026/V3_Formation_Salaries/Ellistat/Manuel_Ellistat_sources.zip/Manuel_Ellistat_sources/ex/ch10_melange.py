"""Chapitre 10, modes de défaillance multiples (mélange) : beta apparent.

Jeu simulé (graine 2026) : 60 produits ; 25 % suivent un mode de jeunesse
(Weibull beta = 0,6, eta = 150 h), 75 % un mode d'usure (beta = 3, eta = 1000 h).
On ajuste une seule Weibull 2P (MV et régression de Benard) et on regarde
le beta apparent ; on affiche les coordonnées du papier de Weibull.
"""
import math

import numpy as np

from ch10_commun import mle, regression_rang_median, fmt

rng = np.random.default_rng(2026)
n, p = 60, 0.25
mode1 = rng.random(n) < p
t = np.where(mode1, 150 * rng.weibull(0.6, n), 1000 * rng.weibull(3.0, n))
print("Produits du mode 1 (jeunesse) :", int(mode1.sum()), "sur", n)
eta, beta, _, _ = mle(t)
eta_r, beta_r, r2, X, Y = regression_rang_median(t)
print("Une seule Weibull, MV        : eta =", fmt(eta, 1), "; beta apparent =", fmt(beta, 3))
print("Une seule Weibull, régression : eta =", fmt(eta_r, 1), "; beta apparent =", fmt(beta_r, 3),
      "; R² =", fmt(r2, 4))
# modes séparés (si l'on connaît l'appartenance)
e1, b1, _, _ = mle(t[mode1])
e2, b2, _, _ = mle(t[~mode1])
print("Mode 1 séparé : eta =", fmt(e1, 1), "; beta =", fmt(b1, 3))
print("Mode 2 séparé : eta =", fmt(e2, 1), "; beta =", fmt(b2, 3))
print("\nCoordonnées papier de Weibull :")
print(" ".join(f"({x:.3f},{y:.3f})" for x, y in zip(X, Y)))
print("Droite MV : y =", f"{beta:.4f}*(x - {math.log(eta):.4f})")
