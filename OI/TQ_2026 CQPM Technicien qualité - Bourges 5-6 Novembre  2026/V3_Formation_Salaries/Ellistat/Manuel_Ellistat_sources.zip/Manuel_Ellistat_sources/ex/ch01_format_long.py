"""Chapitre 01, section « Typer les données » :
passage du format large (6 x 5) au format long, et rôle de la colonne Echantillon.
Calcul refait en Python ; ce n'est pas une sortie d'Ellistat.
"""
from ch01_commun import lire_large, large_vers_long, sigmas, cp_cpk, fr

large = lire_large()
print("Format large :", large.shape[0], "lignes x", large.shape[1] - 1, "mesures")
long = large_vers_long(large)
print("Format long :", long.shape[0], "lignes x", long.shape[1], "colonnes",
      list(long.columns))
print("Cinq premières lignes du format long :")
for _, r in long.head(6).iterrows():
    print(f"  {int(r.Echantillon)};{int(r.Piece)};{fr(r.Diametre, 2)}")
print("  ...")
for _, r in long.tail(2).iterrows():
    print(f"  {int(r.Echantillon)};{int(r.Piece)};{fr(r.Diametre, 2)}")

# Moyenne et étendue par échantillon
g = long.groupby("Echantillon")["Diametre"]
print("\nPar échantillon (moyenne ; étendue) :")
for k in g.mean().index:
    print(f"  {k} : {fr(g.mean()[k])} ; {fr(g.max()[k] - g.min()[k], 2)}")

s = sigmas(long)
print("\nMoyenne générale :", fr(s["moyenne"]))
print("R barre :", fr(s["Rbar"]), " d2(5) = 2,326")
print("S barre :", fr(s["Sbar"]))
print("MR barre (30 valeurs dans l'ordre échantillon puis pièce) :", fr(s["MRbar"]))

print("\nEstimateur de sigma -> Cp ; Cpk")
for cle, lib in [("R/d2", "R barre / d2"), ("S/c4", "S barre / c4"),
                 ("groupe", "écart-type groupé"), ("MR/1,128", "étendues mobiles"),
                 ("s global", "s global (n-1)")]:
    cp, cpk = cp_cpk(s[cle], s["moyenne"])
    print(f"  {lib:22s} sigma = {fr(s[cle])} -> {fr(cp, 2)} ; {fr(cpk, 2)}")

# Empilement « colonne sous colonne » (P1 des 6 échantillons, puis P2, ...) :
# l'ordre des lignes n'est plus chronologique, les étendues mobiles changent.
mauvais = long.sort_values(["Piece", "Echantillon"]).reset_index(drop=True)
sm = sigmas(mauvais)
cp_m, cpk_m = cp_cpk(sm["MR/1,128"], sm["moyenne"])
print("\nEmpilement colonne sous colonne : MR barre =", fr(sm["MRbar"]),
      "; sigma MR =", fr(sm["MR/1,128"]), "-> Cp", fr(cp_m, 2))
print("  (R barre inchangé si la colonne Echantillon suit :", fr(sm["Rbar"]), ")")

# Contrôle de cohérence avec les résultats connus du cahier des charges
assert abs(s["moyenne"] - 11.8867) < 5e-5
assert abs(s["R/d2"] - 0.0215) < 5e-5 and abs(s["s global"] - 0.0264) < 5e-5
print("\nContrôle : résultats conformes aux valeurs de référence TQ6.")
