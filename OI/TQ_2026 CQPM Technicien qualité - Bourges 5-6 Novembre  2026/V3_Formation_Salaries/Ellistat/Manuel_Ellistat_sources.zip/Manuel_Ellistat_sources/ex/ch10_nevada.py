"""Chapitre 10, suivi des retours : Nevada attendu et Nevada observé (simulé).

Hypothèses (exemple pédagogique, hors guide) :
  - 6 mois de vente, ventes en début de mois : 2000, 2400, 1800, 2200, 2600, 2000 ;
  - loi de fiabilité supposée : Weibull beta = 1,5, eta = 40 mois ;
  - retours attendus du lot i au mois calendaire j (j >= i), âge a = j - i :
        E[i, j] = V_i * (F(a + 1) - F(a)) ;
  - retours « observés » simulés par une loi de Poisson (graine 2026),
    avec un événement calendaire au mois 5 (retours multipliés par 1,8).
"""
import numpy as np

from ch10_commun import fmt

ventes = np.array([2000, 2400, 1800, 2200, 2600, 2000])
beta, eta = 1.5, 40.0
k = len(ventes)


def F(a):
    return 1 - np.exp(-(np.asarray(a, float) / eta) ** beta)


E = np.full((k, k), np.nan)
for i in range(k):
    for j in range(i, k):
        a = j - i
        E[i, j] = ventes[i] * (F(a + 1) - F(a))

rng = np.random.default_rng(2026)
facteur = np.ones(k)
facteur[4] = 1.8           # mois calendaire 5
O = np.full((k, k), np.nan)
for i in range(k):
    for j in range(i, k):
        O[i, j] = rng.poisson(E[i, j] * facteur[j])

print("F(1) =", fmt(100 * F(1), 3), "% ; F(6) =", fmt(100 * F(6), 3), "%")
print("\nNevada attendu (lignes = lots de vente, colonnes = mois de retour) :")
for i in range(k):
    print(f"lot {i+1} ({ventes[i]}) :", " ; ".join("" if np.isnan(x) else fmt(x, 1) for x in E[i]))
print("\nNevada observé (simulé, graine 2026) :")
for i in range(k):
    print(f"lot {i+1} :", " ; ".join("" if np.isnan(x) else str(int(x)) for x in O[i]))

col_E = np.nansum(E, axis=0)
col_O = np.nansum(O, axis=0)
print("\nPar mois calendaire : attendu ; observé ; rapport")
for j in range(k):
    print(f"mois {j+1} :", fmt(col_E[j], 1), ";", int(col_O[j]), ";", fmt(col_O[j] / col_E[j], 2))
print("Cumul attendu :", " ".join(f"({j+1},{v:.1f})" for j, v in enumerate(np.cumsum(col_E))))
print("Cumul observé :", " ".join(f"({j+1},{int(v)})" for j, v in enumerate(np.cumsum(col_O))))

# Lecture par diagonale (âge) : somme par âge
print("\nPar âge a (diagonales) : attendu ; observé")
for a in range(k):
    e = sum(E[i, i + a] for i in range(k - a))
    o = sum(O[i, i + a] for i in range(k - a))
    print(f"âge {a} :", fmt(e, 1), ";", int(o), ";", fmt(o / e, 2))
print("\nPar lot (lignes) : attendu ; observé")
for i in range(k):
    print(f"lot {i+1} :", fmt(np.nansum(E[i]), 1), ";", int(np.nansum(O[i])), ";",
          fmt(np.nansum(O[i]) / np.nansum(E[i]), 2))
