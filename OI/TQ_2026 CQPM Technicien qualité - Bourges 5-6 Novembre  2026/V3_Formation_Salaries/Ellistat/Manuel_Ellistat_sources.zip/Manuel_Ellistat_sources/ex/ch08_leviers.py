"""Chapitre 08 : graphique « Leviers vs Résidus » (régression simple).

Données simulées (graine 88) : 12 essais avec X entre 5 et 10, y = 2 + 1,5 X + bruit N(0 ; 0,4).
On ajoute un essai atypique en X (X = 20, réponse cohérente avec le modèle)
et on fausse la réponse de l'essai n° 4 (+3) pour créer un point aberrant en Y.
Seuils usuels (hors guide) : levier > 2p/n, |résidu studentisé externe| > 2 (repère), > 3 (alerte).
Usage : python3 ch08_leviers.py [dossier_coordonnees]
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import sys, json
import numpy as np

rng = np.random.default_rng(88)
x = np.round(np.linspace(5.2, 9.8, 12) + rng.uniform(-0.2, 0.2, 12), 2)
y = 2 + 1.5 * x + rng.normal(0, 0.4, 12)
y[3] += 3.0                       # aberrant en Y (essai n° 4)
x = np.append(x, 20.0)            # atypique en X (essai n° 13)
y = np.append(y, 2 + 1.5 * 20 + rng.normal(0, 0.4))
n, p = len(x), 2
M = np.column_stack([np.ones(n), x])
H = M @ np.linalg.inv(M.T @ M) @ M.T
h = np.diag(H)
beta = np.linalg.lstsq(M, y, rcond=None)[0]
e = y - M @ beta
s2 = e @ e / (n - p)
# résidu studentisé externe : s_(i) calculé sans l'essai i
s2i = ((n - p) * s2 - e ** 2 / (1 - h)) / (n - p - 1)
t = e / np.sqrt(s2i * (1 - h))
print(f"n = {n}, p = {p}, seuil de levier 2p/n = {2 * p / n:.3f}, levier moyen p/n = {p / n:.3f}")
print(f"Droite : y = {beta[0]:.3f} + {beta[1]:.3f} X")
for i in range(n):
    flag = []
    if h[i] > 2 * p / n: flag.append("levier")
    if abs(t[i]) > 3: flag.append("résidu")
    print(f"essai {i+1:2d} X = {x[i]:6.2f} y = {y[i]:6.2f} levier = {h[i]:.3f} t = {t[i]:+6.2f} {' '.join(flag)}")
if len(sys.argv) > 1:
    fmt = lambda idx: " ".join(f"({h[i]:.4f},{t[i]:.4f})" for i in idx)
    normal = [i for i in range(n) if i not in (3, n - 1)]
    json.dump({"normal": fmt(normal), "aberrY": fmt([3]), "atypX": fmt([n - 1]), "seuilh": 2 * p / n},
              open(sys.argv[1] + "/leviers.json", "w"), indent=0)
