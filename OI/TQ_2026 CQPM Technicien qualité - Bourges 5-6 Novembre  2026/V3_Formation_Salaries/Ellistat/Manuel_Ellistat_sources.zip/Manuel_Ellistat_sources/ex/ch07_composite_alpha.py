"""Chapitre 07 : plan composite centré.
1. alpha d'isovariance par rotation : alpha = F^(1/4), F = nombre de points du cube ;
2. nombre de points centraux de « précision uniforme » (Box et Hunter, 1957) ;
3. nombre d'essais et nombre de coefficients du modèle quadratique complet.
Calcul refait en Python (hors Ellistat).

Précision uniforme : on cherche N tel que, dans l'échelle où le moment
d'ordre 2 vaut 1, le moment pur d'ordre 4 du plan rotatif
    lambda4 = N F / (F + 2 alpha^2)^2
égale la valeur cible  (k + 3 + sqrt(9k^2 + 14k - 7)) / (4 (k + 2)).
Le nombre de points centraux est n0 = N - F - 2k (arrondi).
"""
import math

GUIDE = {2: (5, 1.414), 3: (6, 1.682), 4: (7, 2.0), 5: (6, 2.0), 6: (9, 2.28)}


def n0_uniforme(k, F):
    a2 = math.sqrt(F)                      # alpha^2 pour un plan rotatif
    cible = (k + 3 + math.sqrt(9 * k * k + 14 * k - 7)) / (4 * (k + 2))
    N = cible * (F + 2 * a2) ** 2 / F
    return N, round(N) - F - 2 * k


print("k | cube      | F  | alpha=F^(1/4) | N exact | n0 | essais | coeff. quadratiques")
for k in range(2, 7):
    for nom, F in [("complet", 2 ** k), ("demi-fraction", 2 ** (k - 1))]:
        if nom == "demi-fraction" and k < 5:
            continue
        N, n0 = n0_uniforme(k, F)
        p = (k + 1) * (k + 2) // 2
        print(f"{k} | {nom:13s} | {F:2d} | {F ** 0.25:.3f} | {N:6.2f} | {n0:2d} | {F + 2 * k + n0:3d} | {p}")

print("\nValeurs du guide (n0, alpha) :", GUIDE)
print("Nombre de points du cube qui donnerait alpha = 2,28 :", round(2.28 ** 4, 2))
print("alpha d'une demi-fraction à 6 facteurs arrondi à 2 décimales :", round(32 ** 0.25, 2))
print("Écart relatif 2,28 / 2,378 :", round(2.28 / 32 ** 0.25 - 1, 4))

# Box-Behnken à 3 facteurs : milieux des 12 arêtes du cube
import itertools
bb = []
for i, j in itertools.combinations(range(3), 2):
    for si, sj in itertools.product([-1, 1], repeat=2):
        p = [0, 0, 0]
        p[i], p[j] = si, sj
        bb.append(tuple(p))
print("\nBox-Behnken 3 facteurs : points d'arête =", len(bb))
print("distance au centre d'un point d'arête =", round(math.sqrt(2), 3))
print("aucun point avec 3 extrêmes simultanés :", all(sum(abs(c) for c in p) == 2 for p in bb))
