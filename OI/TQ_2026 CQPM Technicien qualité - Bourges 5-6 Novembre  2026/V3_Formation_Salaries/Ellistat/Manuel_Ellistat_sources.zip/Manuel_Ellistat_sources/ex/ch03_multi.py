# -*- coding: utf-8 -*-
"""Chapitre 03 : données appariées, Multivari, T² (Multi Y), Better to Current.

Toutes les données de ce script sont SIMULÉES (numpy default_rng, graine 2026),
sauf le calcul combinatoire du B vs C (exact).
Calculs refaits en Python, pas des sorties d'Ellistat.
"""
import math
import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.anova import anova_lm
from ch03_commun import fr, c, coords, ecrire, titre, GRAINE

rng = np.random.default_rng(GRAINE)

# ----------------------------------------------------------------- 1. appariement
titre(f"1. Données appariées : dureté HV de 10 pièces avant / après revenu (graine {GRAINE})")
avant = np.round(rng.normal(400, 15, 10), 0)
apres = np.round(avant - 6 + rng.normal(0, 3, 10), 0)
dif = apres - avant
print("Avant :", [int(a) for a in avant])
print("Après :", [int(a) for a in apres])
print("Différences :", [int(d) for d in dif], f"; moyenne = {fr(dif.mean(), 1)} ; s = {fr(dif.std(ddof=1), 2)}")
print(f"Différences négatives : {(dif < 0).sum()} / 10")
ti = stats.ttest_ind(avant, apres, equal_var=False)
tp = stats.ttest_rel(avant, apres)
wi = stats.wilcoxon(avant, apres)
print(f"Moyennes : avant {fr(avant.mean(), 1)} ; après {fr(apres.mean(), 1)} ; s avant {fr(avant.std(ddof=1), 1)} ; s après {fr(apres.std(ddof=1), 1)}")
print(f"Test indépendant (Welch) : t = {fr(ti.statistic, 2)} ; p = {fr(ti.pvalue, 2)}")
print(f"Test apparié (Student) : t = {fr(tp.statistic, 2)} ; p = {tp.pvalue:.1e}")
print(f"Wilcoxon signé : p = {fr(wi.pvalue, 4)}")
seg = "\n".join(rf"\addplot[grisTQ,mark=*,mark size=1.2pt] coordinates {{(1,{int(a)}) (2,{int(b)})}};"
                for a, b in zip(avant, apres))
ecrire("apparie_lignes", seg)
ecrire("apparie_points", r"\addplot[only marks,mark=*,mark size=1.4pt,uimmblue] coordinates {"
       + " ".join(f"(1,{int(a)})" for a in avant) + " " + " ".join(f"(2,{int(b)})" for b in apres) + "};\n"
       + r"\addplot[only marks,mark=-,mark size=8pt,ultra thick,uimmred] coordinates {"
       + f"(1,{c(avant.mean(), 1)}) (2,{c(apres.mean(), 1)})" + "};"
       + rf"\def\chtroispind{{{fr(ti.pvalue, 2)}}}\def\chtroispapp{{{fr(tp.pvalue, 5)}}}")

# ----------------------------------------------------------------- 2. multivari
titre("2. Multivari : diamètre (mm) selon Machine (M1, M2) et Outillage (O1, O2, O3), 4 pièces par case")
rows = []
for mi, m in enumerate(["M1", "M2"]):
    for oi, o in enumerate(["O1", "O2", "O3"]):
        eff = 11.880 + 0.006 * mi + 0.002 * oi + (0.012 if (m == "M2" and o == "O3") else 0.0)
        for _ in range(4):
            rows.append((m, o, round(eff + rng.normal(0, 0.003), 4)))
df = pd.DataFrame(rows, columns=["Machine", "Outil", "Y"])
moy = df.groupby(["Machine", "Outil"])["Y"].mean()
print(moy.round(4).to_string())
mm = df.groupby("Machine")["Y"].mean()
print("Moyennes machine :", {k: fr(v, 4) for k, v in mm.items()})
print(f"Moyenne générale = {fr(df['Y'].mean(), 4)}")
mod = smf.ols("Y ~ C(Machine) * C(Outil)", data=df).fit()
tab = anova_lm(mod, typ=2)
for nom, r in tab.iterrows():
    if nom != "Residual":
        print(f"  {nom:26s} F = {fr(r['F'], 2)} ; p = {r['PR(>F)']:.1e}")
pos = {("M1", "O1"): 1, ("M1", "O2"): 2, ("M1", "O3"): 3, ("M2", "O1"): 5, ("M2", "O2"): 6, ("M2", "O3"): 7}
lig = [r"\addplot[only marks,mark=*,mark size=1.1pt,grisTQ] coordinates {"
       + " ".join(f"({pos[(m, o)]},{c(y, 4)})" for m, o, y in rows) + "};"]
for m, col in [("M1", "uimmblue"), ("M2", "uimmred")]:
    lig.append(rf"\addplot[thick,{col},mark=square*,mark size=2pt] coordinates {{"
               + " ".join(f"({pos[(m, o)]},{c(moy[(m, o)], 4)})" for o in ["O1", "O2", "O3"]) + "};")
lig.append(r"\addplot[thick,dashed,black,mark=diamond*,mark size=3pt] coordinates {"
           + f"(2,{c(mm['M1'], 4)}) (6,{c(mm['M2'], 4)})" + "};")
ecrire("multivari", "\n".join(lig))

# ----------------------------------------------------------------- 3. T² de Hotelling
titre("3. T² : deux cotes corrélées (rho = 0,9), 50 pièces de référence")
n, p = 50, 2
mu = np.array([20.00, 35.00])
sd = 0.02
cov = np.array([[sd ** 2, 0.9 * sd ** 2], [0.9 * sd ** 2, sd ** 2]])
ref = rng.multivariate_normal(mu, cov, n)
xb = ref.mean(axis=0)
S = np.cov(ref, rowvar=False)
r12 = S[0, 1] / math.sqrt(S[0, 0] * S[1, 1])
print(f"Moyennes = {fr(xb[0], 4)} ; {fr(xb[1], 4)} ; écarts-types = {fr(math.sqrt(S[0, 0]), 4)} ; {fr(math.sqrt(S[1, 1]), 4)} ; r = {fr(r12, 3)}")
Si = np.linalg.inv(S)
alpha = 0.0027
F = stats.f.ppf(1 - alpha, p, n - p)
ucl = p * (n + 1) * (n - 1) / (n * (n - p)) * F
print(f"Limite phase II (alpha = 0,0027) : p(n+1)(n-1)/(n(n-p)) F = {fr(ucl, 2)} (F = {fr(F, 3)})")
nouv = np.array([20.030, 34.975])
d = nouv - xb
t2 = float(d @ Si @ d)
z = d / np.sqrt(np.diag(S))
print(f"Pièce testée : ({fr(nouv[0], 3)} ; {fr(nouv[1], 3)}) ; écarts réduits = {fr(z[0], 2)} ; {fr(z[1], 2)} ; T² = {fr(t2, 1)}")
print(f"Tolérances supposées : 20,00 ± 0,06 et 35,00 ± 0,06 ; pièce dans les tolérances : "
      f"{abs(nouv[0] - 20) <= 0.06 and abs(nouv[1] - 35) <= 0.06}")
t2ref = np.einsum("ij,jk,ik->i", ref - xb, Si, ref - xb)
print(f"T² des 50 pièces de référence : max = {fr(t2ref.max(), 2)}")
L = np.linalg.cholesky(S)
th = np.linspace(0, 2 * np.pi, 73)
ell = xb[:, None] + math.sqrt(ucl) * L @ np.vstack([np.cos(th), np.sin(th)])
ecrire("t2", r"\addplot[only marks,mark=*,mark size=1.1pt,uimmblue] coordinates {" + coords(ref[:, 0], ref[:, 1], 4, 4) + "};\n"
       + r"\addplot[thick,vertTQ] coordinates {" + coords(ell[0], ell[1], 4, 4) + "};\n"
       + rf"\addplot[only marks,mark=*,mark size=2.4pt,uimmred] coordinates {{({c(nouv[0], 3)},{c(nouv[1], 3)})}};"
       + rf"\def\chtroisTdeux{{{fr(t2, 1)}}}\def\chtroisLim{{{fr(ucl, 2)}}}")

# ----------------------------------------------------------------- 4. Better to Current (B vs C, Shainin)
titre("4. B vs C : probabilité que les 3 B surclassent les 3 C par hasard")
for nb, nc in [(3, 3), (4, 4), (2, 6)]:
    comb = math.comb(nb + nc, nb)
    print(f"  {nb} B et {nc} C : C({nb + nc},{nb}) = {comb} ; risque = 1/{comb} = {fr(1 / comb * 100, 2)} %")
