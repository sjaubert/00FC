"""Chapitre 04 : décomposition de Fourier sur un signal simulé.

Signal : N = 256 mesures, intervalle d'échantillonnage 1 s, graine 2026.
x(t) = 0,020 sin(2 pi 0,0625 t) + 0,010 sin(2 pi 0,2 t + 0,8) + bruit N(0 ; 0,008).
Fenêtre de Hann, amplitude monolatérale = 2 |X_k| / somme(w).
Reconstruction : moindres carrés sur les fréquences des K raies retenues (choix de
l'auteur, la méthode d'Ellistat n'est pas documentée).
Calcul refait en Python : ce n'est pas une sortie d'Ellistat.
"""
import numpy as np

GRAINE, N, DT = 2026, 256, 1.0
A1, F1, A2, F2, PH2, SIG = 0.020, 0.0625, 0.010, 0.2, 0.8, 0.008


def main():
    rng = np.random.default_rng(GRAINE)
    t = np.arange(N) * DT
    x = A1 * np.sin(2 * np.pi * F1 * t) + A2 * np.sin(2 * np.pi * F2 * t + PH2) + rng.normal(0, SIG, N)
    xc = x - x.mean()
    w = np.hanning(N)
    X = np.fft.rfft(xc * w)
    f = np.fft.rfftfreq(N, DT)
    amp = 2 * np.abs(X) / w.sum()
    print(f"résolution fréquentielle = {1 / (N * DT):.5f} Hz ; Nyquist = {1 / (2 * DT):.3f} Hz")
    # Top K = 2 avec maxima locaux
    loc = [i for i in range(1, len(amp) - 1) if amp[i] > amp[i - 1] and amp[i] >= amp[i + 1]]
    loc.sort(key=lambda i: -amp[i])
    top = loc[:4]
    for i in top:
        print(f"raie : f = {f[i]:.4f} Hz, période = {1 / f[i]:.2f} s, amplitude = {amp[i]:.4f}")
    K = 2
    fk = [f[i] for i in top[:K]]
    cols = [np.ones(N)]
    for fr in fk:
        cols += [np.sin(2 * np.pi * fr * t), np.cos(2 * np.pi * fr * t)]
    M = np.column_stack(cols)
    coef, *_ = np.linalg.lstsq(M, x, rcond=None)
    rec = M @ coef
    res = x - rec
    for j, fr in enumerate(fk):
        a = np.hypot(coef[1 + 2 * j], coef[2 + 2 * j])
        print(f"amplitude ajustée à {fr:.4f} Hz = {a:.4f}")
    print(f"écart-type signal = {x.std(ddof=1):.4f}, résidu = {res.std(ddof=1):.4f}")
    # sans fenêtre : fuite spectrale autour de 0,2 Hz
    amp0 = 2 * np.abs(np.fft.rfft(xc)) / N
    i02 = int(np.argmin(np.abs(f - 0.2)))
    print(f"sans fenêtre : amplitude max près de 0,2 Hz = {amp0[i02 - 1:i02 + 2].max():.4f}")
    print("\nspectre (f, amp*1000) :")
    print(" ".join(f"({a:.4f},{b * 1000:.2f})" for a, b in zip(f, amp)))
    print("\nsignal (t, x*1000) 0..127 :")
    print(" ".join(f"({a:.0f},{b * 1000:.2f})" for a, b in zip(t[:128], x[:128])))
    print("\nreconstruit (t, rec*1000) 0..127 :")
    print(" ".join(f"({a:.0f},{b * 1000:.2f})" for a, b in zip(t[:128], rec[:128])))
    print("\nrésidu (t, res*1000) 0..127 :")
    print(" ".join(f"({a:.0f},{b * 1000:.2f})" for a, b in zip(t[:128], res[:128])))


if __name__ == "__main__":
    main()
