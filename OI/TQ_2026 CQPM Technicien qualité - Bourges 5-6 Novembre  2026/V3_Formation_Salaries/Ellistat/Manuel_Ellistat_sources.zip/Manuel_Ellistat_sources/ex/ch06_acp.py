# -*- coding: utf-8 -*-
"""Chapitre 06, ACP normée sur un procédé simulé à 5 caractéristiques corrélées.

Données simulées (ce ne sont pas des mesures réelles) : graine numpy 2026, n = 50 pièces.
Deux facteurs latents :
  f1 = « dimensionnel » (agit sur diamètre, longueur, masse),
  f2 = « traitement thermique » (agit sur dureté, et en sens inverse sur la rugosité).
Calcul refait en Python selon les conventions FactoMineR annoncées par le guide
(centrage-réduction avec l'écart-type de population, division par n).

Sorties : texte sur la console + fragments pgfplots dans ex/sorties_ch06/.
"""
import os
import numpy as np
from scipy import stats

ICI = os.path.dirname(os.path.abspath(__file__))
SORTIES = os.path.join(ICI, "sorties_ch06")
os.makedirs(SORTIES, exist_ok=True)

rng = np.random.default_rng(2026)
n = 50
f1 = rng.normal(size=n)
f2 = rng.normal(size=n)
bruit = rng.normal(size=(n, 5))
noms = ["Diametre", "Longueur", "Masse", "Durete", "Rugosite"]
etiq = ["Diamètre", "Longueur", "Masse", "Dureté", "Rugosité"]
# moyennes et écarts-types réalistes (mm, mm, g, HV, µm)
diam = 25.00 + 0.010 * (0.80 * f1 + 0.60 * bruit[:, 0])
long_ = 80.00 + 0.040 * (0.70 * f1 + 0.71 * bruit[:, 1])
masse = 312.0 + 1.50 * (0.75 * f1 + 0.20 * f2 + 0.63 * bruit[:, 2])
durete = 420.0 + 12.0 * (0.80 * f2 + 0.60 * bruit[:, 3])
rugo = 0.80 + 0.08 * (-0.55 * f2 + 0.15 * f1 + 0.82 * bruit[:, 4])
X = np.column_stack([diam, long_, masse, durete, rugo])
p = X.shape[1]

# ---------------------------------------------------------------- ACP normée
m = X.mean(axis=0)
s_pop = X.std(axis=0, ddof=0)   # convention FactoMineR / Ellistat (n)
s_ech = X.std(axis=0, ddof=1)   # convention Excel ECARTYPE.STANDARD (n-1)
Z = (X - m) / s_pop
R = (Z.T @ Z) / n               # matrice des corrélations
vp, U = np.linalg.eigh(R)
ordre = np.argsort(vp)[::-1]
vp, U = vp[ordre], U[:, ordre]
# orientation : la plus grande composante de chaque vecteur propre positive
for k in range(p):
    if U[np.argmax(np.abs(U[:, k])), k] < 0:
        U[:, k] *= -1
F = Z @ U                        # coordonnées des individus
coord_var = U * np.sqrt(vp)      # corrélations variable-axe
ctr_var = 100 * U ** 2           # contributions des variables (%)
cos2_var = coord_var ** 2

print("Matrice des corrélations R :")
print(np.round(R, 3))
print("\nValeurs propres, % variance, % cumulé :")
cum = 0
for k in range(p):
    pct = 100 * vp[k] / p
    cum += pct
    print(f"  CP{k+1}: lambda = {vp[k]:.3f}   {pct:.1f} %   cumul {cum:.1f} %")
print("  somme des valeurs propres =", round(vp.sum(), 6), "(= p =", p, ")")
print("  axes avec lambda > 1 :", int((vp > 1).sum()))
print("  axes pour atteindre 80 % :", int(np.argmax(np.cumsum(vp) / p >= 0.80) + 1))

print("\nCorrélations variable-axe (CP1, CP2, CP3) :")
for j in range(p):
    print(f"  {noms[j]:9s}", " ".join(f"{coord_var[j,k]:+.3f}" for k in range(3)))
print("\nContributions (%) sur CP1, CP2 ; moyenne 100/p =", 100 / p)
for j in range(p):
    print(f"  {noms[j]:9s}", " ".join(f"{ctr_var[j,k]:5.1f}" for k in range(3)),
          "  somme CP1..CP5 cos2 =", round(cos2_var[j].sum(), 6))
print("  total par axe :", np.round(ctr_var.sum(axis=0), 6))
print("\nCos2 des variables (CP1, CP2, CP1+CP2) :")
for j in range(p):
    print(f"  {noms[j]:9s} {cos2_var[j,0]:.3f} {cos2_var[j,1]:.3f} {cos2_var[j,0]+cos2_var[j,1]:.3f}")

# p-value d'une corrélation variable-axe (hypothèse : test t de r, n-2 ddl)
print("\np-values (test t de la corrélation, n-2 ddl, hypothèse de travail) :")
for j in range(p):
    pv = []
    for k in range(2):
        r = coord_var[j, k]
        t = r * np.sqrt((n - 2) / (1 - r * r))
        pv.append(2 * stats.t.sf(abs(t), n - 2))
    print(f"  {noms[j]:9s} p(CP1) = {pv[0]:.2g}   p(CP2) = {pv[1]:.2g}")

# ---------------------------------------------------------------- conventions n / n-1
var_F_pop = F.var(axis=0, ddof=0)
var_F_ech = F.var(axis=0, ddof=1)
print("\nVariance des coordonnées des individus :")
print("  division par n   :", np.round(var_F_pop, 4), "(= valeurs propres)")
print("  division par n-1 :", np.round(var_F_ech, 4))
print("  rapport n/(n-1) =", round(n / (n - 1), 4), " facteur sur les coordonnées sqrt =",
      round(np.sqrt(n / (n - 1)), 4))
print("  écart relatif pour n = 10 : sqrt(10/9) =", round(np.sqrt(10 / 9), 4))
Z2 = (X - m) / s_ech
F2 = Z2 @ U
print("  CP1 de l'individu 1 : convention n :", round(F[0, 0], 4),
      " ; convention n-1 :", round(F2[0, 0], 4))
R2 = np.corrcoef(X, rowvar=False)
print("  écart max entre R (n) et corrcoef (n-1) :", float(np.abs(R - R2).max()))
print("  z de l'individu 1 sur Diametre : n :", round(Z[0, 0], 4), " ; n-1 :", round(Z2[0, 0], 4))
print("  moyennes :", np.round(m, 4))
print("  écarts-types (n) :", np.round(s_pop, 4))
print("  écarts-types (n-1) :", np.round(s_ech, 4))

# ---------------------------------------------------------------- individus
d2 = (F ** 2).sum(axis=1)
ctr_ind = 100 * F ** 2 / (n * vp)
cos2_ind = F ** 2 / d2[:, None]
i_max = int(np.argmax(ctr_ind[:, 0]))
print("\nIndividus : contribution max à CP1 :", round(ctr_ind[i_max, 0], 2), "% (individu",
      i_max + 1, ") ; moyenne 100/n =", 100 / n)
print("  cos2 de cet individu sur CP1+CP2 :", round(cos2_ind[i_max, :2].sum(), 3))
print("  somme des cos2 sur les 5 axes (individu 1) :", round(cos2_ind[0].sum(), 6))
print("  distance au centre de l'individu", i_max + 1, ":", round(np.sqrt(d2[i_max]), 3))
for i in range(3):
    print(f"  individu {i+1}: d = {np.sqrt(d2[i]):.3f}  CP1 = {F[i,0]:+.3f}  CP2 = {F[i,1]:+.3f}"
          f"  ctr1 = {ctr_ind[i,0]:.2f} %  cos2(1+2) = {cos2_ind[i,:2].sum():.3f}")

# ---------------------------------------------------------------- fragments TikZ / pgfplots
with open(os.path.join(SORTIES, "acp_individus.tex"), "w", encoding="utf-8") as f:
    f.write("\\addplot[only marks,mark=*,mark size=1.3pt,color=uimmblue] coordinates {")
    f.write(" ".join(f"({F[i,0]:.3f},{F[i,1]:.3f})" for i in range(n) if i != i_max))
    f.write("};\n")
    f.write(f"\\addplot[only marks,mark=square*,mark size=2pt,color=uimmred] coordinates "
            f"{{({F[i_max,0]:.3f},{F[i_max,1]:.3f})}};\n")
    f.write(f"\\node[font=\\scriptsize,anchor=west,text=uimmred] at (axis cs:{F[i_max,0]:.3f},"
            f"{F[i_max,1]:.3f}) {{\\ pièce {i_max+1}}};\n")
with open(os.path.join(SORTIES, "acp_cercle.tex"), "w", encoding="utf-8") as f:
    for j in range(p):
        f.write(f"\\draw[-{{Stealth}},thick,uimmblue] (0,0) -- ({coord_var[j,0]:.3f},{coord_var[j,1]:.3f});"
                f" % {noms[j]}\n")
        ang = np.degrees(np.arctan2(coord_var[j, 1], coord_var[j, 0]))
        f.write(f"\\node[font=\\scriptsize\\sffamily,anchor={(ang+180)%360:.0f},inner sep=2pt] at "
                f"({coord_var[j,0]:.3f},{coord_var[j,1]:.3f}) {{{etiq[j]}}};\n")
with open(os.path.join(SORTIES, "acp_eboulis.tex"), "w", encoding="utf-8") as f:
    f.write("% valeurs propres\n\\addplot[ybar,bar width=14pt,fill=uimmblue!60,draw=uimmblue] coordinates {")
    f.write(" ".join(f"({k+1},{vp[k]:.3f})" for k in range(p)))
    f.write("};\n% cumul (%)\n")
    f.write(" ".join(f"({k+1},{100*np.cumsum(vp)[k]/p:.1f})" for k in range(p)))
    f.write("\n")
np.save(os.path.join(SORTIES, "acp_X.npy"), X)
print("\nFragments écrits dans", SORTIES)
