"""Chapitre 07 : petits dénombrements utilisés dans le texte (hors Ellistat).
- nombre de coefficients (ddl du modèle) selon le modèle ;
- taille d'un plan complet à niveaux mixtes (XN, fullDOE) ;
- plage d'essais Smart DOE (2k+1, 3k, plafond 60) ;
- piège de la courbure en criblage à 2 niveaux (réponse en cloche).
"""
from math import comb, prod

print("Coefficients du modèle (constante incluse)")
for k in range(2, 8):
    lin = 1 + k
    inter = 1 + k + comb(k, 2)
    quad = (k + 1) * (k + 2) // 2
    print(f"k={k} : linéaire {lin} ; + toutes interactions d'ordre 2 {inter} ; quadratique complet {quad}")

print("\nExemple ddl : 3 facteurs à 2 niveaux + interaction A*B déclarée ->", 1 + 3 + 1, "coefficients")
print("Exemple ddl : 7 facteurs sans interaction ->", 1 + 7, "coefficients (une L8 est saturée)")

print("\nXN, plan complet (fullDOE)")
for niveaux in [(3, 2, 5), (3, 3, 2, 2), (6, 6, 6), (3,) * 4]:
    print(f"  niveaux {niveaux} -> {prod(niveaux)} essais")

print("\nSmart DOE, plage d'essais explorée : départ 2k+1, couvre au moins 3k, plafond 60")
for k in [3, 6, 10, 14]:
    print(f"  k={k:2d} : 2k+1 = {2*k+1} ; 3k = {3*k} ; plafond 60")

print("\nPiège de la courbure : y = 10 - 4 x^2")
f = lambda x: 10 - 4 * x * x
print(f"  y(-1) = {f(-1)} ; y(0) = {f(0)} ; y(+1) = {f(1)}")
print(f"  effet à 2 niveaux = y(+1) - y(-1) = {f(1) - f(-1)}")
print(f"  centre - moyenne des extrêmes = {f(0) - (f(-1) + f(1)) / 2}")
