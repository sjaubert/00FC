"""Chapitre 10, estimation de fiabilité sur WEIBUL.csv et FAILTIME.csv
(données complètes, aucune censure).

Pour chaque fichier :
  - maximum de vraisemblance (Weibull 2P), IC 95 % par la matrice de Fisher,
  - régression de rang médian (Benard), Y = ln(-ln(1-F)) sur X = ln t,
  - B10, MTTF, R à une échéance,
  - contrôle avec scipy.stats.weibull_min.fit,
  - coordonnées du papier de Weibull pour la figure (WEIBUL.csv).
"""
import math

import numpy as np
from scipy import stats

from ch10_commun import (lire_colonne, mle, ic_fisher, regression_rang_median,
                         bq, mttf, R, fmt)


def analyse(nom, echeance):
    t = lire_colonne(nom)
    print(f"\n===== {nom} : n = {len(t)}, min = {fmt(t.min(), 3)}, max = {fmt(t.max(), 3)},"
          f" moyenne = {fmt(t.mean(), 3)}, médiane = {fmt(np.median(t), 3)}")
    eta, beta, cov, ll = mle(t)
    (e1, e2), (b1, b2) = ic_fisher(eta, beta, cov)
    c, loc, sc = stats.weibull_min.fit(t, floc=0)
    print("MV      : eta =", fmt(eta, 3), "IC95 [", fmt(e1, 2), ";", fmt(e2, 2), "]",
          "; beta =", fmt(beta, 4), "IC95 [", fmt(b1, 3), ";", fmt(b2, 3), "]")
    print("          contrôle scipy : eta =", fmt(sc, 3), "; beta =", fmt(c, 4))
    print("          B10 =", fmt(bq(0.10, eta, beta), 3), "; MTTF =", fmt(mttf(eta, beta), 3),
          f"; R({echeance}) =", fmt(100 * R(echeance, eta, beta), 1), "%")
    eta_r, beta_r, r2, X, Y = regression_rang_median(t)
    print("Régr.   : eta =", fmt(eta_r, 3), "; beta =", fmt(beta_r, 4), "; R² =", fmt(r2, 4))
    print("          B10 =", fmt(bq(0.10, eta_r, beta_r), 3), "; MTTF =", fmt(mttf(eta_r, beta_r), 3),
          f"; R({echeance}) =", fmt(100 * R(echeance, eta_r, beta_r), 1), "%")
    # test d'adéquation indicatif (hors guide) : Anderson-Darling n'existe pas pour Weibull
    # dans scipy < 1.15 ; on donne Kolmogorov-Smirnov avec paramètres estimés (indicatif).
    ks = stats.kstest(t, "weibull_min", args=(beta, 0, eta))
    print("KS indicatif (paramètres estimés, p surévaluée) : D =", fmt(ks.statistic, 3),
          "; p =", fmt(ks.pvalue, 2))
    return t, (eta, beta), (eta_r, beta_r), X, Y


t, mv, rg, X, Y = analyse("WEIBUL.csv", 10)
print("\nCoordonnées papier de Weibull WEIBUL.csv (ln t, ln(-ln(1-F))) :")
print(" ".join(f"({x:.3f},{y:.3f})" for x, y in zip(X, Y)))
print("Droites : MV  y =", f"{mv[1]:.4f}*(x - {math.log(mv[0]):.4f})",
      "; régression y =", f"{rg[1]:.4f}*(x - {math.log(rg[0]):.4f})")

t2, mv2, rg2, X2, Y2 = analyse("FAILTIME.csv", 1000)
print("\nCoordonnées papier de Weibull FAILTIME.csv :")
print(" ".join(f"({x:.3f},{y:.3f})" for x, y in zip(X2, Y2)))
print("Droites : MV  y =", f"{mv2[1]:.4f}*(x - {math.log(mv2[0]):.4f})",
      "; régression y =", f"{rg2[1]:.4f}*(x - {math.log(rg2[0]):.4f})")

# Graduations de F pour l'axe secondaire du papier de Weibull
print("\nGraduations F -> ln(-ln(1-F)) :")
for F in (0.01, 0.02, 0.05, 0.10, 0.20, 0.30, 0.50, 0.632, 0.80, 0.90, 0.95, 0.99):
    print(f"   F = {F} -> {math.log(-math.log(1 - F)):.3f}")
