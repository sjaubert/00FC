"""Chapitre 09, Spécigraphe : transfert de tolérance Y -> X par régression.

Données INVENTÉES : 25 couples (X, Y), Y = 18,7 + 1,2 X + bruit N(0 ; 0,6),
graine 2026. Spécification de Y : 30 / 40 (celle de l'exemple du guide).

Méthodes de cumul (formules = NOS hypothèses de reconstitution, hors guide) :
  - pire des cas      : IT_X = (IT_Y - 2 Z S_tot) / |b|
  - bande de tolérance: bande de garde k(x) S avec
                        k(x) = z_{(1+p)/2} sqrt(1 + h(x)) sqrt(nu / chi2_{nu, alpha})
                        (approximation classique d'intervalle de tolérance en régression)
  - statistique       : sigma_X max = sqrt((IT_Y/(6 Cpk))^2 - S_tot^2) / |b|, IT_X = 6 sigma_X
  - inertiel          : I_X max = sqrt((IT_Y/6)^2 - S_tot^2) / |b|
avec S_tot = sqrt(S^2 + u^2) (incertitude de mesure u composée en quadrature).
"""
import numpy as np
from scipy import stats
from scipy.optimize import brentq

from ch09_commun import GRAINE, fr, coords, titre

YMIN, YMAX = 30.0, 40.0
ITY = YMAX - YMIN

# ------------------------------------------------------------------ données
rng = np.random.default_rng(GRAINE)
n = 25
x = np.sort(rng.uniform(10.0, 17.0, n))
y = 18.7 + 1.2 * x + rng.normal(0.0, 0.6, n)

# ------------------------------------------------------------------ régression
b, a = np.polyfit(x, y, 1)
res = y - (a + b * x)
nu = n - 2
S = np.sqrt(np.sum(res ** 2) / nu)
r2 = 1 - np.sum(res ** 2) / np.sum((y - y.mean()) ** 2)
r2aj = 1 - (1 - r2) * (n - 1) / nu
xbar, sxx = x.mean(), np.sum((x - x.mean()) ** 2)
se_b = S / np.sqrt(sxx)
t_b = b / se_b
p_b = 2 * stats.t.sf(abs(t_b), nu)

titre("Régression (données inventées, graine 2026)")
print(f"n = {n}, pente b = {fr(b,4)}, ordonnée a = {fr(a,3)}")
print(f"S résiduel = {fr(S,4)}, R2 = {fr(r2,4)}, R2 ajusté = {fr(r2aj,4)}, ddl = {nu}")
print(f"t pente = {fr(t_b,1)}, p = {p_b:.2e}, plage X = [{fr(x.min(),2)} ; {fr(x.max(),2)}]")


def x_de_y(yv):
    return (yv - a) / b


def pire_des_cas(Z, u=0.0):
    g = Z * np.hypot(S, u)
    lo, hi = x_de_y(YMIN + g), x_de_y(YMAX - g)
    return lo, hi, hi - lo, g


def bande_tolerance(p, conf, u=0.0):
    z = stats.norm.ppf((1 + p) / 2)
    chi = stats.chi2.ppf(1 - conf, nu)
    St = np.hypot(S, u)

    def k(xv):
        h = 1 / n + (xv - xbar) ** 2 / sxx
        return z * np.sqrt(1 + h) * np.sqrt(nu / chi)

    lo = brentq(lambda xv: a + b * xv - k(xv) * St - YMIN, 0, 40)
    hi = brentq(lambda xv: a + b * xv + k(xv) * St - YMAX, 0, 40)
    return lo, hi, hi - lo, k(lo), k(hi)


def statistique(cpk_vise=1.0, u=0.0):
    St = np.hypot(S, u)
    sy = ITY / (6 * cpk_vise)
    sx = np.sqrt(sy ** 2 - St ** 2) / abs(b)
    c = x_de_y((YMIN + YMAX) / 2)
    return c - 3 * sx, c + 3 * sx, 6 * sx, sx


def inertiel(u=0.0):
    St = np.hypot(S, u)
    iy = ITY / 6
    return np.sqrt(iy ** 2 - St ** 2) / abs(b)


titre("Sans bande de garde")
sans = ITY / b
print(f"IT_X sans bande de garde = 10 / b = {fr(sans,3)}  "
      f"[{fr(x_de_y(YMIN),3)} ; {fr(x_de_y(YMAX),3)}]")

titre("Comparaison des quatre méthodes (u = 0)")
pc2 = pire_des_cas(2)
pc3 = pire_des_cas(3)
bt = bande_tolerance(0.99, 0.95)
st = statistique(1.0)
ix = inertiel()
print(f"Pire des cas Z=2 : [{fr(pc2[0])} ; {fr(pc2[1])}] IT_X = {fr(pc2[2])}  garde Z.S = {fr(pc2[3])}")
print(f"Pire des cas Z=3 : [{fr(pc3[0])} ; {fr(pc3[1])}] IT_X = {fr(pc3[2])}  garde Z.S = {fr(pc3[3])}")
print(f"Bande tol p=99 %, 95 % : [{fr(bt[0])} ; {fr(bt[1])}] IT_X = {fr(bt[2])}  k = {fr(bt[3])} / {fr(bt[4])}")
print(f"Statistique Cpk=1 : [{fr(st[0])} ; {fr(st[1])}] IT_X = 6 sigma_X = {fr(st[2])}  sigma_X = {fr(st[3],4)}")
print(f"Inertiel : I_X max = {fr(ix,4)}  (I_Y max = IT_Y/6 = {fr(ITY/6,4)})")

print(f"Rapport IT_X(Z=2)/IT_X(Z=3) sur nos données : {fr(pc2[2]/pc3[2],3)} ; S/IT_Y = {fr(S/ITY,4)}")
print(f"Bande de tolérance / pire des cas Z=2 : {fr(bt[2]/pc2[2],3)} ; statistique / pire des cas Z=2 : {fr(st[2]/pc2[2],3)}")

titre("Bilan de tolérance de Y (parts)")
garde_tot = 2 * pc2[3]
print(f"Pire des cas Z=2 : résidu {fr(garde_tot,3)} soit {fr(100*garde_tot/ITY,1)} % ; part X {fr(b*pc2[2],3)} soit {fr(100*b*pc2[2]/ITY,1)} %")
var_y = (ITY / 6) ** 2
print(f"Statistique : part de variance résidu S^2/(IT_Y/6)^2 = {fr(100*S**2/var_y,1)} % ; part X = {fr(100*(1-S**2/var_y),1)} %")

titre("Effet d'une incertitude de mesure u = 0,4 (pire des cas Z = 2)")
pcu = pire_des_cas(2, u=0.4)
print(f"S_tot = {fr(np.hypot(S,0.4),4)}, IT_X = {fr(pcu[2])} (contre {fr(pc2[2])} avec u = 0)")

titre("Exemple du guide : Y 30/40, pente 1,20, IT_X = 5,009 [11,068 ; 16,077]")
itx_g = 16.077 - 11.068
garde_g = (ITY - 1.20 * itx_g) / 2
print(f"IT_X lu = {fr(itx_g)} ; 10/1,20 = {fr(10/1.2)} ; bande de garde par côté = {fr(garde_g,4)}")
print(f"Si Z = 2 (défaut) : S déduit = {fr(garde_g/2,4)} ; si Z = 3 : IT_X = {fr((ITY-6*garde_g/2)/1.2)}")
centre_g = (11.068 + 16.077) / 2
print(f"Centre de l'intervalle X = {fr(centre_g,4)} ; ordonnée à l'origine implicite = {fr(35-1.2*centre_g,3)}")

titre("Rapport IT_X(Z=2)/IT_X(Z=3) selon S/IT_Y")
for r in [0.05, 0.10, 0.12, 0.14, 0.15, 0.16, 0.161]:
    num, den = 1 - 4 * r, 1 - 6 * r
    print(f"S/IT_Y = {r:.3f}: rapport = {num/den:.2f}" if den > 0 else f"{r}: tolérance nulle")
r10 = 9 / 56
print(f"Rapport = 10 pour S/IT_Y = 9/56 = {fr(r10,4)}")
# courbe pour la figure
rs = np.linspace(0, 0.16, 33)
print("COURBE Z2:", coords(rs, 1 - 4 * rs, 3))
print("COURBE Z3:", coords(rs, np.clip(1 - 6 * rs, 0, None), 3))

titre("Coordonnées pour la figure")
print("NUAGE:", coords(x, y, 3))
print(f"Droite: y = {a:.4f} + {b:.4f} x")

# ------------------------------------------------------------------ deux facteurs
titre("Deux facteurs : Y = 10 + 1,0 X1 + 2,0 X2, spécification 20 / 30, S = 0,5, Z = 2")
b1, b2, S2 = 1.0, 2.0, 0.5
sig1, sig2 = 0.8, 0.25           # dispersions observées des X (inventées)
budget = 10.0 - 2 * 2 * S2       # tolérance de Y moins la bande de garde (pire des cas)
# au prorata de la capabilité (pire des cas : cumul arithmétique), hypothèse
k = budget / (b1 * sig1 + b2 * sig2)
t1, t2 = k * sig1, k * sig2       # intervalles (largeurs) sur X1, X2
print(f"budget = {fr(budget)} ; IT_X1 = {fr(t1)} ; IT_X2 = {fr(t2)} ; Cp exigé = IT/(6 sigma) = {fr(t1/(6*sig1))} et {fr(t2/(6*sig2))}")
# cibles : X1 = 5, X2 = 5 -> Y = 25 = milieu
c1, c2 = 5.0, 5.0
print(f"rectangle X1 [{fr(c1-t1/2)} ; {fr(c1+t1/2)}], X2 [{fr(c2-t2/2)} ; {fr(c2+t2/2)}]")
# demi-axes de l'ellipse de dispersion à 95 % (X1, X2 indépendants, normaux)
r95 = np.sqrt(stats.chi2.ppf(0.95, 2))
print(f"ellipse 95 % : rayon chi2 = {fr(r95,3)} ; demi-axes {fr(r95*sig1,3)} et {fr(r95*sig2,3)}")
# coins du rectangle : Y extrêmes atteints
ycoin = [10 + b1*(c1+s1*t1/2) + b2*(c2+s2*t2/2) for s1 in (-1,1) for s2 in (-1,1)]
print("Y aux coins du rectangle :", [fr(v) for v in ycoin], "(limites avec garde Z.S = 1 : 21 / 29)")
