"""Chapitre 07 : plan de remplissage à 2 facteurs, 9 essais.
Comparaison d'une grille 3 x 3 et d'un hypercube latin choisi au critère maximin
parmi 20 000 hypercubes latins tirés au hasard (graine 7).
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.

Domaine codé [0 ; 1]^2. Hypercube latin : 9 niveaux i/8, i = 0..8, sur chaque facteur,
chaque niveau utilisé une fois.
Indicateurs (hors guide) :
  - distance minimale entre deux points (maximin : la plus grande possible) ;
  - critère d'Audze-Eglais  U = somme sur i<j de 1 / d_ij^2  (plus bas = meilleur) ;
  - |r| : corrélation entre les deux colonnes ;
  - nombre de valeurs distinctes par facteur (qualité des projections).
"""
import itertools
import numpy as np

n = 9


def indicateurs(P):
    d = [np.linalg.norm(P[i] - P[j]) for i, j in itertools.combinations(range(len(P)), 2)]
    d = np.array(d)
    r = np.corrcoef(P[:, 0], P[:, 1])[0, 1]
    return d.min(), (1 / d ** 2).sum(), abs(r), [len(set(np.round(P[:, k], 6))) for k in range(2)]


grille = np.array([[x, y] for x in (0, 0.5, 1) for y in (0, 0.5, 1)])

rng = np.random.default_rng(7)
niveaux = np.arange(n) / (n - 1)
meilleur, crit = None, None
for _ in range(20000):
    P = np.column_stack([niveaux, niveaux[rng.permutation(n)]])
    dmin, ae, r, _ = indicateurs(P)
    c = (round(dmin, 9), -ae)
    if crit is None or c > crit:
        meilleur, crit = P, c

for nom, P in [("Grille 3x3", grille), ("Hypercube latin maximin", meilleur)]:
    dmin, ae, r, proj = indicateurs(P)
    print(f"{nom} : dmin = {dmin:.4f} ; Audze-Eglais U = {ae:.2f} ; |r| = {r:.4f} ; valeurs distinctes {proj}")
    print("  points :", " ".join(f"({x:.4f},{y:.4f})" for x, y in P))

# effet d'un facteur inactif : projection sur X1 seul
print("\nProjection sur X1 : grille ->", [float(v) for v in sorted(set(grille[:, 0]))], "; hypercube ->", len(set(meilleur[:, 0])), "valeurs")
# règle par défaut du guide pour le nombre d'essais : 5 par facteur, minimum 9
for k in [2, 3, 4, 10, 20]:
    print(f"k = {k:2d} facteurs -> essais par défaut = max(5k, 9) = {max(5 * k, 9)}")
