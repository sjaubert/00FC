"""Chapitre 05 : règles classiques de la littérature Shainin (hors guide Ellistat).

Ce n'est pas une sortie d'Ellistat : le guide ne cite pas Shainin et ne documente ni ses tests
ni ses limites. Ce script chiffre les règles classiques pour le formateur.
1. Test « B vs C » : probabilité, sous H0, que les nB pièces B soient toutes mieux classées
   que les nC pièces C : 1 / C(nB + nC, nB).
2. Test de comptage des extrémités de Tukey (end count) pour 6 BOB / 6 WOW :
   loi exacte sous H0 par énumération des C(12, 6) = 924 rangements.
3. Exemple BoB vs WoW simulé (graine 2026) : 6 paires BOB / WOW, X1 discriminante, X2 sans effet.
4. Inversion de composants (component search, étape 1) : 3 mesures par assemblage
   (montage initial puis 2 démontages/remontages), D = écart des médianes, d = moyenne des étendues,
   rapport D/d, limites médiane ± t(0,975 ; 4) x d / d2* avec d2* = 1,81. Données simulées (graine 2026).
"""
from itertools import combinations
from math import comb

import numpy as np
from scipy import stats

print("=== 1. B vs C ===")
for nb, nc in ((3, 3), (2, 5), (1, 19), (4, 4)):
    print(f"nB = {nb}, nC = {nc} : risque si tous les B devant tous les C = 1/{comb(nb+nc, nb)} "
          f"= {1/comb(nb+nc, nb):.4f}")

print("\n=== 2. Comptage des extrémités de Tukey, 6 BOB / 6 WOW ===")


def end_count(labels):
    """labels : suite de 0 (WOW) / 1 (BOB) triée par valeur croissante."""
    if labels[0] == labels[-1]:
        return 0
    bas = 1
    while labels[bas] == labels[0]:
        bas += 1
    haut = 1
    while labels[-1 - haut] == labels[-1]:
        haut += 1
    return bas + haut


n = 6
dist = {}
for pos in combinations(range(2 * n), n):
    lab = [0] * (2 * n)
    for p in pos:
        lab[p] = 1
    t = end_count(lab)
    dist[t] = dist.get(t, 0) + 1
tot = comb(2 * n, n)
for t in range(6, 13):
    queue = sum(c for k, c in dist.items() if k >= t) / tot
    print(f"P(end count >= {t:2d}) = {queue:.4f}  (confiance {100*(1-queue):.1f} %)")

print("\n=== 3. Exemple BoB vs WoW simulé (graine 2026) ===")
# 6 paires BOB/WOW, deux variables : X1 décalée de 2 écarts-types chez les WOW, X2 sans effet.
rng = np.random.default_rng(2026)
donnees = {
    "X1 (dureté)": (np.round(rng.normal(20.0, 1.0, 6), 1), np.round(rng.normal(22.0, 1.0, 6), 1)),
    "X2 (rugosité)": (np.round(rng.normal(1.60, 0.10, 6), 2), np.round(rng.normal(1.60, 0.10, 6), 2)),
}
for nom, (bob, wow) in donnees.items():
    vals = np.concatenate([bob, wow])
    lab = np.concatenate([np.ones(6, int), np.zeros(6, int)])
    ordre = np.argsort(vals, kind="stable")
    t = end_count(list(lab[ordre]))
    u = stats.mannwhitneyu(bob, wow, alternative="two-sided", method="exact")
    tp = stats.ttest_rel(bob, wow)
    print(f"{nom} : BOB {bob.tolist()} | WOW {wow.tolist()}")
    print(f"   end count = {t} ; Mann-Whitney exact p = {u.pvalue:.4f} ; t apparié p = {tp.pvalue:.4f}")

print("\n=== 4. Inversion de composants, étape 1 (graine 2026) ===")
rng = np.random.default_rng(2026)
b_mes = np.round(10.0 + rng.normal(0, 0.15, 3), 2)   # assemblage bon (BOB)
w_mes = np.round(13.0 + rng.normal(0, 0.15, 3), 2)   # assemblage mauvais (WOW)
print("BOB (initial, remontage 1, remontage 2) :", b_mes.tolist())
print("WOW (initial, remontage 1, remontage 2) :", w_mes.tolist())
mb, mw = np.median(b_mes), np.median(w_mes)
rb, rw = np.ptp(b_mes), np.ptp(w_mes)
D = abs(mw - mb)
d = (rb + rw) / 2
print(f"médianes : BOB {mb:.2f}, WOW {mw:.2f} ; étendues : {rb:.2f}, {rw:.2f}")
print(f"D = {D:.2f}, d = {d:.3f}, D/d = {D/d:.1f}")
tq = stats.t.ppf(0.975, 4)
demi = tq * d / 1.81
print(f"t(0,975 ; 4) = {tq:.3f} ; demi-largeur = {demi:.3f}")
print(f"limites BOB = [{mb-demi:.2f} ; {mb+demi:.2f}] ; limites WOW = [{mw-demi:.2f} ; {mw+demi:.2f}]")
