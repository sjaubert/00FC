"""Chapitre 05 : tests sur statistiques résumées (n, moyenne, écart-type ; k et n ; tableau de contingence).

Calcul refait en Python (scipy, statsmodels), ce n'est pas une sortie d'Ellistat.
1. Quantitatives : butées (Butees_diametre.csv, 30 valeurs) contre mesures des opérateurs
   (ANOVA_TP_R.csv, 100 valeurs), en ne gardant que n, moyenne et s. On vérifie que le test
   fait sur les résumés redonne celui fait sur les données brutes.
2. Qualitatives : non-conformes des lots 1 à 20 contre lots 21 à 40 (SPC-1_inspection.csv).
3. Indépendance : tableau 3 x 2 (trois périodes de 40 lots x non conforme / conforme),
   khi-deux, effectifs attendus (règle de Cochran), résidus standardisés ; Fisher exact sur le 2 x 2.
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.proportion import proportions_ztest

DONNEES = Path(__file__).resolve().parent.parent / "donnees"

but = pd.read_csv(DONNEES / "Butees_diametre.csv", sep=";", decimal=",", encoding="utf-8-sig")
x = but[["P1", "P2", "P3", "P4", "P5"]].dropna().to_numpy().ravel()
ope = pd.read_csv(DONNEES / "ANOVA_TP_R.csv", sep=";", decimal=",", encoding="utf-8-sig").dropna()
y = ope["Mesure"].to_numpy()

print("=== 1. Quantitatives ===")
r = dict(n1=len(x), m1=x.mean(), s1=x.std(ddof=1), n2=len(y), m2=y.mean(), s2=y.std(ddof=1))
print("Résumés : n1 = {n1}, moy1 = {m1:.4f}, s1 = {s1:.4f} | n2 = {n2}, moy2 = {m2:.4f}, s2 = {s2:.4f}".format(**r))
for eq, nom in ((True, "t de Student (variances égales)"), (False, "t de Welch")):
    t_r = stats.ttest_ind_from_stats(r["m1"], r["s1"], r["n1"], r["m2"], r["s2"], r["n2"], equal_var=eq)
    t_b = stats.ttest_ind(x, y, equal_var=eq)
    print(f"{nom} : résumés t = {t_r.statistic:.3f}, p = {t_r.pvalue:.3g} | bruts t = {t_b.statistic:.3f}, p = {t_b.pvalue:.3g}")
F = r["s1"] ** 2 / r["s2"] ** 2
pF = 2 * min(stats.f.cdf(F, r["n1"] - 1, r["n2"] - 1), stats.f.sf(F, r["n1"] - 1, r["n2"] - 1))
print(f"Test F des variances : F = {F:.3f} (ddl {r['n1']-1} et {r['n2']-1}), p bilatérale = {pF:.3f}")
# Même calcul avec les résumés arrondis comme dans un rapport (4 décimales)
t_a = stats.ttest_ind_from_stats(round(r["m1"], 4), round(r["s1"], 4), r["n1"],
                                 round(r["m2"], 4), round(r["s2"], 4), r["n2"], equal_var=False)
print(f"Welch avec résumés arrondis à 4 décimales : t = {t_a.statistic:.3f}, p = {t_a.pvalue:.3g}")

print("\n=== 2. Qualitatives (test 2P) ===")
spc = pd.read_csv(DONNEES / "SPC-1_inspection.csv", sep=";", encoding="utf-8-sig")
k1, n1 = spc["Non_conformes"][:20].sum(), spc["Taille_lot"][:20].sum()
k2, n2 = spc["Non_conformes"][20:40].sum(), spc["Taille_lot"][20:40].sum()
print(f"lots 1-20 : k = {k1}, n = {n1}, p = {k1/n1:.4f} | lots 21-40 : k = {k2}, n = {n2}, p = {k2/n2:.4f}")
for alt, nom in (("two-sided", "bilatéral"), ("smaller", "unilatéral (p1 < p2)")):
    z, p = proportions_ztest([k1, k2], [n1, n2], alternative=alt)
    print(f"test z de deux proportions, {nom} : z = {z:.3f}, p = {p:.3g}")
tab2 = np.array([[k1, n1 - k1], [k2, n2 - k2]])
_, pfis = stats.fisher_exact(tab2)
chi2c, pc, _, _ = stats.chi2_contingency(tab2, correction=True)
print(f"Fisher exact 2 x 2 : p = {pfis:.3g} ; khi-deux avec correction de Yates : khi2 = {chi2c:.3f}, p = {pc:.3g}")

print("\n=== 3. Indépendance (3 périodes de 40 lots) ===")
lignes = []
for a, b in ((0, 40), (40, 80), (80, 120)):
    k = spc["Non_conformes"][a:b].sum()
    n = spc["Taille_lot"][a:b].sum()
    lignes.append([k, n - k])
tab = np.array(lignes)
chi2, p, ddl, att = stats.chi2_contingency(tab, correction=False)
print("observés :", tab.tolist())
print("attendus :", np.round(att, 1).tolist(), "-> plus petit attendu =", round(att.min(), 1))
print(f"khi2 = {chi2:.3f}, ddl = {ddl}, p = {p:.3f}")
res = (tab - att) / np.sqrt(att)
print("résidus de Pearson (o - e)/sqrt(e) :", np.round(res, 2).tolist())
lig = tab.sum(axis=1, keepdims=True) / tab.sum()
col = tab.sum(axis=0, keepdims=True) / tab.sum()
adj = (tab - att) / np.sqrt(att * (1 - lig) * (1 - col))
print("résidus standardisés ajustés :", np.round(adj, 2).tolist())
