"""Chapitre 01, section « Clic droit » : trois critères classiques de valeur aberrante
(hors guide : le critère d'Ellistat n'est pas documenté), appliqués aux 30 butées,
puis au même jeu après une faute de frappe simulée (11,93 saisi 11,39).
Calcul refait en Python ; ce n'est pas une sortie d'Ellistat.
"""
import math

import numpy as np
from scipy import stats

from ch01_commun import lire_large, large_vers_long, fr


def criteres(x, alpha=0.05):
    x = np.asarray(x, dtype=float)
    n, m, s = len(x), x.mean(), x.std(ddof=1)
    # Règle des 3 s
    hors3s = x[np.abs(x - m) > 3 * s]
    # Règle de Tukey (quartiles par interpolation linéaire, méthode par défaut de numpy)
    q1, q3 = np.percentile(x, [25, 75])
    iqr = q3 - q1
    bas, haut = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    tukey = x[(x < bas) | (x > haut)]
    # Test de Grubbs bilatéral (une valeur)
    g = np.max(np.abs(x - m)) / s
    t = stats.t.ppf(1 - alpha / (2 * n), n - 2)
    gcrit = (n - 1) / math.sqrt(n) * math.sqrt(t * t / (n - 2 + t * t))
    return dict(n=n, m=m, s=s, lim3s=(m - 3 * s, m + 3 * s), hors3s=hors3s,
                q1=q1, q3=q3, tukey_lim=(bas, haut), tukey=tukey, G=g, Gcrit=gcrit)


def affiche(titre, r):
    print(titre)
    print(f"  n = {r['n']}, moyenne = {fr(r['m'])}, s = {fr(r['s'])}")
    print(f"  3 s : [{fr(r['lim3s'][0])} ; {fr(r['lim3s'][1])}] -> signalées : "
          f"{[fr(v, 2) for v in r['hors3s']]}")
    print(f"  Tukey : Q1 = {fr(r['q1'])}, Q3 = {fr(r['q3'])}, bornes "
          f"[{fr(r['tukey_lim'][0])} ; {fr(r['tukey_lim'][1])}] -> signalées : "
          f"{[fr(v, 2) for v in r['tukey']]}")
    print(f"  Grubbs : G = {fr(r['G'], 3)}, G critique (5 %) = {fr(r['Gcrit'], 3)} -> "
          f"{'aberrante' if r['G'] > r['Gcrit'] else 'rien'}")


long = large_vers_long(lire_large())
x = long["Diametre"].to_numpy()
affiche("Butées telles quelles (30 valeurs)", criteres(x))

# Faute de frappe simulée : la 23e valeur (échantillon 5, pièce 3 : 11,93) saisie 11,39
y = x.copy()
idx = int(np.where((long["Echantillon"] == 5) & (long["Piece"] == 3))[0][0])
print(f"\nValeur modifiée : échantillon 5, pièce 3 : {fr(y[idx], 2)} -> 11,39")
y[idx] = 11.39
r = criteres(y)
affiche("Butées avec la faute de frappe", r)

# Après retrait de la valeur fautive, reste-t-il une valeur signalée ?
z = np.delete(y, idx)
affiche("\nAprès retrait de la valeur fautive (29 valeurs)", criteres(z))

# Effet de la faute de frappe sur Pp (s global)
from ch01_commun import cp_cpk
print("\nPp avec s global : sans faute", fr(cp_cpk(x.std(ddof=1), x.mean())[0], 2),
      "| avec faute", fr(cp_cpk(y.std(ddof=1), y.mean())[0], 2))
