"""Chapitre 08 : domaine d'un mélange à 3 composants sous contraintes min/max.

Composants (fractions) : x1 dans [0,30 ; 0,70], x2 dans [0,10 ; 0,50], x3 dans [0,05 ; 0,30].
1) Contrôle de faisabilité : somme des minimums <= 1 <= somme des maximums.
1 bis) Bornes implicites (resserrement par les autres composants).
2) Sommets du polygone réalisable et sa part de l'aire du triangle.
3) Un plan maximin de 10 mélanges (construction gloutonne sur 20 000 candidats tirés
   uniformément sur le simplexe, graine 2026) : une construction possible, pas celle d'Ellistat.
4) Deux corrections possibles d'un mélange de somme 1,05 : renormalisation et projection euclidienne.
Usage : python3 ch08_melange.py [dossier_coordonnees]
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import sys, json, itertools
import numpy as np

lo = np.array([0.30, 0.10, 0.05]); hi = np.array([0.70, 0.50, 0.30])

def faisable(lo, hi):
    return lo.sum() <= 1 + 1e-12 and hi.sum() >= 1 - 1e-12

for nom, l, h in (("domaine étudié", lo, hi),
                  ("minimums 0,50/0,35/0,20", np.array([0.50, 0.35, 0.20]), hi),
                  ("maximums 0,40/0,30/0,25", lo, np.array([0.40, 0.30, 0.25]))):
    print(f"{nom} : somme min = {l.sum():.2f}, somme max = {h.sum():.2f} -> {'réalisable' if faisable(l, h) else 'IMPOSSIBLE'}")

# bornes implicites : l'_i = max(l_i, 1 - somme des u_j, j != i) ; u'_i = min(u_i, 1 - somme des l_j, j != i)
def implicites(lo, hi):
    l2 = np.maximum(lo, 1 - (hi.sum() - hi)); u2 = np.minimum(hi, 1 - (lo.sum() - lo))
    return l2, u2
for nom, l, h in (("domaine étudié", lo, hi), ("x1 max porté à 0,90", lo, np.array([0.90, 0.50, 0.30]))):
    l2, u2 = implicites(l, h)
    print(f"Bornes implicites ({nom}) : min {np.round(l2, 2)}, max {np.round(u2, 2)}")

# sommets : deux composants sur une borne, le troisième par complément
V = []
for i, j in itertools.combinations(range(3), 2):
    k = 3 - i - j
    for bi in (lo[i], hi[i]):
        for bj in (lo[j], hi[j]):
            x = np.zeros(3); x[i], x[j] = bi, bj; x[k] = 1 - bi - bj
            if lo[k] - 1e-12 <= x[k] <= hi[k] + 1e-12 and not any(np.allclose(x, v) for v in V):
                V.append(x)
xy = lambda x: np.array([x[2] + 0.5 * x[0], np.sqrt(3) / 2 * x[0]])  # x1 en haut, x2 en bas à gauche, x3 en bas à droite
P = np.array([xy(v) for v in V]); c = P.mean(0)
order = np.argsort(np.arctan2(P[:, 1] - c[1], P[:, 0] - c[0]))
V = [V[o] for o in order]; P = P[order]
area = 0.5 * abs(np.dot(P[:, 0], np.roll(P[:, 1], -1)) - np.dot(P[:, 1], np.roll(P[:, 0], -1)))
print(f"{len(V)} sommets :")
for v in V:
    print("   ", np.round(v, 2))
print(f"Part de l'aire du triangle réalisable : {area / (np.sqrt(3) / 4):.3f}")

# plan maximin glouton (10 mélanges)
rng = np.random.default_rng(2026)
cand = rng.dirichlet(np.ones(3), 20000)
cand = cand[np.all((cand >= lo) & (cand <= hi), axis=1)]
cand = np.vstack([np.array(V), cand])
print(f"Candidats réalisables : {len(cand)} (dont {len(V)} sommets)")
sel = [int(np.argmin(np.linalg.norm(cand - cand.mean(0), axis=1)))]  # départ : le candidat le plus central
for _ in range(9):
    d = np.min(np.linalg.norm(cand[:, None, :] - cand[sel][None, :, :], axis=2), axis=1)
    sel.append(int(np.argmax(d)))
D = cand[sel]
dm = min(np.linalg.norm(a - b) for a, b in itertools.combinations(D, 2))
print("Plan maximin (x1, x2, x3) :")
for x in D:
    print("   ", np.round(x, 3), " somme =", round(x.sum(), 6))
print(f"Distance minimale entre deux mélanges du plan : {dm:.3f}")
sur_bord = [np.any(np.isclose(x, lo, atol=1e-3) | np.isclose(x, hi, atol=1e-3)) for x in D]
sommet = [any(np.allclose(x, v) for v in V) for x in D]
print(f"Mélanges à moins de 0,001 d'une borne : {sum(sur_bord)} sur {len(D)}, dont {sum(sommet)} sommets")

# correction d'un mélange de somme 1,05
x = np.array([0.50, 0.30, 0.25])
ren = x / x.sum()
a, b = -1.0, 1.0
for _ in range(100):
    tau = (a + b) / 2
    s = np.clip(x - tau, lo, hi).sum()
    a, b = (tau, b) if s > 1 else (a, tau)
proj = np.clip(x - tau, lo, hi)
print(f"Saisie {x}, somme {x.sum():.2f} -> renormalisation {np.round(ren, 3)} ; projection euclidienne {np.round(proj, 3)}")

if len(sys.argv) > 1:
    fmt = lambda pts: " ".join(f"({p[0]:.4f},{p[1]:.4f})" for p in pts)
    json.dump({"poly": fmt(P), "plan": fmt([xy(v) for v in D]),
               "polyfill": " -- ".join(f"({p[0]:.4f},{p[1]:.4f})" for p in P),
               "planlist": ",".join("{" + f"({q[0]:.4f},{q[1]:.4f})" + "}" for q in [xy(v) for v in D])}, open(sys.argv[1] + "/melange.json", "w"), indent=0)
