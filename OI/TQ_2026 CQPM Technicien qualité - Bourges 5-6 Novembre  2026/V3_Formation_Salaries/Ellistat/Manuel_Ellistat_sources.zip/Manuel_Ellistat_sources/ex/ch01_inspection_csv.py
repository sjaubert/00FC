"""Chapitre 01, section « Faire entrer les données » :
ce que contient réellement le fichier Butees_diametre.csv, octet par octet.
Calcul refait en Python ; ce n'est pas une sortie d'Ellistat.
"""
from ch01_commun import DONNEES

brut = (DONNEES / "Butees_diametre.csv").read_bytes()
print("BOM UTF-8 en tête :", brut.startswith(b"\xef\xbb\xbf"))
print("Fins de ligne CRLF :", brut.count(b"\r\n"), "| LF seuls :",
      brut.count(b"\n") - brut.count(b"\r\n"))

texte = brut.decode("utf-8-sig")
lignes = texte.splitlines()
print("Lignes totales (en-tête compris) :", len(lignes))
entete, donnees = lignes[0], lignes[1:]
print("En-tête :", entete)

vides = [l for l in donnees if all(c == "" for c in l.split(";")[1:])]
print("Lignes de données :", len(donnees), "| dont lignes sans mesure :", len(vides),
      "->", [l.split(";")[0] for l in vides])

# Nombre de champs par ligne selon le séparateur supposé
for sep in [";", ","]:
    nb = sorted({len(l.split(sep)) for l in lignes})
    print(f"Séparateur {sep!r} : nombre de champs par ligne = {nb}")

# Valeurs à virgule décimale
nb_virg = sum(1 for l in donnees for c in l.split(";")[1:] if "," in c)
print("Cellules de mesure écrites avec une virgule décimale :", nb_virg)
print("Exemple de cellule :", donnees[0].split(";")[1])
