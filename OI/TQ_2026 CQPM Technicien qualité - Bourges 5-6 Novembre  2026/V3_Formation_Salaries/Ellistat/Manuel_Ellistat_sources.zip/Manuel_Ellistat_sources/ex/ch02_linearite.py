# -*- coding: utf-8 -*-
"""Chapitre 02 - Étude de linéarité sur données SIMULÉES (graine 2027).

Micromètre 0-25 mm, 5 cales étalons (5, 10, 15, 20, 25 mm), 10 mesures par cale.
Modèle de simulation : biais vrai = 0,001 + 0,0003 x (ref - 15) mm, sigma 0,0015 mm,
arrondi à la résolution 0,001 mm.
Régression du biais sur la valeur de référence (convention MSA).
Calcul refait en Python : ce n'est pas une sortie d'Ellistat.
"""
import numpy as np
from scipy import stats

rng = np.random.default_rng(2027)
refs = np.array([5.0, 10.0, 15.0, 20.0, 25.0])
m = 10
T = 0.15              # tolérance de la caractéristique contrôlée (hypothèse)

X, B = [], []
for ref in refs:
    vrai = 0.001 + 0.0003 * (ref - 15)
    mes = np.round(ref + vrai + 0.0015 * rng.standard_normal(m), 3)
    X += [ref] * m
    B += list(mes - ref)
X = np.array(X); B = np.round(np.array(B), 4)

reg = stats.linregress(X, B)
n = len(X)
tcrit = stats.t.ppf(0.975, n - 2)

def echelle(p):
    return ("non significatif" if p > 0.1 else "significatif limite" if p > 0.05
            else "significatif" if p > 0.01 else "très significatif")

print(f"n = {n} mesures ({len(refs)} cales x {m})")
print(f"Pente b = {reg.slope:.6f} (ET {reg.stderr:.6f}) ; t = {reg.slope/reg.stderr:.2f} ; p = {reg.pvalue:.2g} -> {echelle(reg.pvalue)}")
p_a = 2 * stats.t.sf(abs(reg.intercept / reg.intercept_stderr), n - 2)
print(f"Ordonnée a = {reg.intercept:.5f} (ET {reg.intercept_stderr:.5f}) ; p = {p_a:.2g}")
print(f"R2 = {reg.rvalue**2:.3f}")
bm = B.mean(); sb = B.std(ddof=1)
pb = 2 * stats.t.sf(abs(bm / (sb / np.sqrt(n))), n - 1)
print(f"Biais moyen (justesse) = {bm:.5f} mm ; t = {bm/(sb/np.sqrt(n)):.2f} ; p = {pb:.2g} -> {echelle(pb)}")
print("Biais moyen par cale :", " ; ".join(f"{r:.0f} mm : {B[X == r].mean():+.4f}" for r in refs))
print(f"Biais prédit à 5 mm : {reg.intercept + reg.slope*5:.4f} ; à 25 mm : {reg.intercept + reg.slope*25:.4f}")
etendue = refs.max() - refs.min()
print(f"Variation du biais sur la plage = |b| x {etendue:.0f} mm = {abs(reg.slope)*etendue:.4f} mm = {100*abs(reg.slope)*etendue/T:.1f} % de T")
print(f"Convention MSA 3e éd. : %linéarité = 100|b| = {100*abs(reg.slope):.3f} %")
print("Points pgfplots :", " ".join(f"({x:.0f},{b*1000:.1f})" for x, b in zip(X, B)))
print("Moyennes pgfplots :", " ".join(f"({r:.0f},{B[X == r].mean()*1000:.2f})" for r in refs))
print(f"Biais nul (droite ajustée) pour une référence de {-reg.intercept/reg.slope:.1f} mm")
