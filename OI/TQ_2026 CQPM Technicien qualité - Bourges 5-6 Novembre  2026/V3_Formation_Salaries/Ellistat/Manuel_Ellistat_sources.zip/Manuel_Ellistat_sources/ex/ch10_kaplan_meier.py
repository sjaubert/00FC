"""Chapitre 10, données censurées : Kaplan-Meier et effet des censures.

Jeu simulé (graine 2026) : 15 produits, durées Weibull beta = 2, eta = 1000 h.
Essai arrêté à 900 h (censure de fin d'essai) ; chaque produit a une chance
sur quatre d'être retiré avant (retrait uniforme sur [0 ; 900 h]).

On compare :
  - Kaplan-Meier avec les censures,
  - la courbe naïve qui écarte les censures (défaillants seuls),
  - Weibull MV avec censures et Weibull MV sur les défaillants seuls.
"""
import numpy as np

from ch10_commun import kaplan_meier, mle, R, bq, fmt

rng = np.random.default_rng(2026)
n, beta0, eta0, fin = 15, 2.0, 1000.0, 900.0
T = eta0 * rng.weibull(beta0, n)
retire = rng.random(n) < 0.25
W = np.where(retire, rng.uniform(0, fin, n), np.inf)
obs = np.minimum(np.minimum(T, W), fin)
d = (T <= np.minimum(W, fin)).astype(int)
obs = np.round(obs).astype(float)
ordre = np.argsort(obs)
obs, d = obs[ordre], d[ordre]

print("Données simulées (graine 2026) : temps en h, d = 1 défaillance, 0 censure")
print(" ; ".join(f"{int(x)}{'' if di else '+'}" for x, di in zip(obs, d)))
print("Défaillances :", int(d.sum()), "; censures :", int(n - d.sum()))

print("\nKaplan-Meier : t ; à risque ; défaillances ; S(t)")
km = kaplan_meier(obs, d)
for ti, nr, nd, S in km:
    print(f"   {int(ti)} ; {nr} ; {nd} ; {fmt(S, 4)}")

# courbe naïve : on écarte les censures
tf = obs[d == 1]
print("\nCourbe naïve (censures écartées) : S(t) = 1 - i / n_f, n_f =", len(tf))
for i, ti in enumerate(tf, 1):
    print(f"   {int(ti)} ; {fmt(1 - i / len(tf), 4)}")

def S_km(t):
    s = 1.0
    for ti, _, _, S in km:
        if ti <= t:
            s = S
    return s

def S_naif(t):
    return 1 - np.sum(tf <= t) / len(tf)

eta_c, beta_c, _, _ = mle(obs, d)
eta_n, beta_n, _, _ = mle(tf)
print("\nWeibull MV avec censures   : eta =", fmt(eta_c, 1), "; beta =", fmt(beta_c, 3),
      "; B10 =", fmt(bq(0.1, eta_c, beta_c), 0))
print("Weibull MV défaillants seuls : eta =", fmt(eta_n, 1), "; beta =", fmt(beta_n, 3),
      "; B10 =", fmt(bq(0.1, eta_n, beta_n), 0))
print("Vraie loi                  : eta =", fmt(eta0, 1), "; beta =", fmt(beta0, 3),
      "; B10 =", fmt(bq(0.1, eta0, beta0), 0))
for t in (300, 500, 800):
    print(f"R({t}) : KM = {fmt(100*S_km(t),1)} % ; naïf = {fmt(100*S_naif(t),1)} % ;"
          f" MV cens. = {fmt(100*R(t, eta_c, beta_c),1)} % ; MV défaillants = {fmt(100*R(t, eta_n, beta_n),1)} % ;"
          f" vraie = {fmt(100*R(t, eta0, beta0),1)} %")

# coordonnées pgfplots (escaliers, const plot)
print("\nKM coord :", "(0,1) " + " ".join(f"({int(ti)},{S:.4f})" for ti, _, _, S in km)
      + f" ({int(obs.max())},{km[-1][3]:.4f})")
print("Naïf coord :", "(0,1) " + " ".join(f"({int(ti)},{1 - i/len(tf):.4f})" for i, ti in enumerate(tf, 1)))
print("Censures (t, S_KM(t)) :", " ".join(f"({int(x)},{S_km(x):.4f})" for x, di in zip(obs, d) if di == 0))
