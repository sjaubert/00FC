"""Chapitre 04 : carte p et carte P' de Laney sur SPC-1_inspection.csv (lots de 150).

Calcul refait en Python : ce ne sont pas des sorties d'Ellistat.
"""
from pathlib import Path
import math
import numpy as np

DATA = Path(__file__).resolve().parent.parent / "donnees" / "SPC-1_inspection.csv"


def lire():
    lignes = DATA.read_text(encoding="utf-8-sig").splitlines()
    lot, n, d = [], [], []
    for ligne in lignes[1:]:
        c = ligne.split(";")
        if len(c) < 3 or not c[2].strip():
            continue
        lot.append(int(c[0]))
        n.append(int(c[1]))
        d.append(int(c[2]))
    return np.array(lot), np.array(n, float), np.array(d, float)


def main():
    lot, n, d = lire()
    k = len(lot)
    p = d / n
    pbar = d.sum() / n.sum()
    print(f"{k} lots, tailles distinctes : {sorted(set(int(v) for v in n))}, total non conformes = {int(d.sum())}")
    print(f"p̄ = {pbar:.5f} ({pbar * 100:.2f} %), min p = {p.min():.4f}, max p = {p.max():.4f}")
    sp = np.sqrt(pbar * (1 - pbar) / n)
    lcs = pbar + 3 * sp
    lci = np.maximum(0, pbar - 3 * sp)
    print(f"carte p : sigma_p = {sp[0]:.5f}, LCI = {lci[0]:.5f}, LCS = {lcs[0]:.5f}")
    hors = lot[(p > lcs) | (p < lci)]
    print(f"lots hors limites p : {len(hors)} -> {[int(v) for v in hors]}")
    # np
    npbar = pbar * n[0]
    s_np = math.sqrt(npbar * (1 - pbar))
    print(f"carte np : LC = {npbar:.3f}, LCI = {max(0, npbar - 3 * s_np):.3f}, LCS = {npbar + 3 * s_np:.3f}")

    # Laney
    z = (p - pbar) / sp
    MR = np.abs(np.diff(z))
    sz = MR.mean() / 1.128
    lcs_l = pbar + 3 * sp * sz
    lci_l = np.maximum(0, pbar - 3 * sp * sz)
    print(f"Laney : MR̄(z) = {MR.mean():.4f}, sigma_z = {sz:.4f}")
    print(f"carte P' : LCI = {lci_l[0]:.5f}, LCS = {lcs_l[0]:.5f}")
    hors_l = lot[(p > lcs_l) | (p < lci_l)]
    print(f"lots hors limites P' : {len(hors_l)} -> {[int(v) for v in hors_l]}")
    # rapport de dispersion (contrôle de sur-dispersion, hors guide)
    var_obs = p.var(ddof=1)
    print(f"variance observée des p = {var_obs:.3e}, variance binomiale = {sp[0] ** 2:.3e}, rapport = {var_obs / sp[0] ** 2:.3f}")
    chi2 = ((d - n * pbar) ** 2 / (n * pbar * (1 - pbar))).sum()
    from scipy import stats
    print(f"khi2 de dispersion = {chi2:.1f} pour {k - 1} ddl, p = {stats.chi2.sf(chi2, k - 1):.2e}")
    # écart-type des z global (autre estimation)
    print(f"écart-type global des z = {z.std(ddof=1):.4f}")

    # Phase I sur les lots 1 à 30
    m1 = slice(0, 30)
    pb1 = d[m1].sum() / n[m1].sum()
    s1 = math.sqrt(pb1 * (1 - pb1) / 150)
    print(f"Phase I lots 1-30 : p̄ = {pb1:.5f}, LCS = {pb1 + 3 * s1:.5f}, LCI = {max(0, pb1 - 3 * s1):.5f}")
    h1 = lot[(p > pb1 + 3 * s1)]
    print(f"  lots au-dessus de la LCS phase I : {len(h1)} -> {[int(v) for v in h1]}")

    print("\nCoordonnées p (lot, p) :")
    print(" ".join(f"({a},{b:.4f})" for a, b in zip(lot, p)))


if __name__ == "__main__":
    main()
