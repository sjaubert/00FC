# -*- coding: utf-8 -*-
"""Chapitre 02 - Gage R&R par attributs sur données SIMULÉES (graine 2028).

30 pièces : 20 bonnes (standard OK) et 10 mauvaises (standard KO), dont
6 pièces « limites » (3 OK, 3 KO) plus difficiles à juger.
3 contrôleurs (C1 strict, C2 correct, C3 laxiste), 2 passages chacun.
Indicateurs : répétabilité, efficacité, taux d'erreur (KO accepté),
taux de fausse alarme (OK rejeté), kappa de Cohen (contre le standard et
entre contrôleurs), kappa de Fleiss global.
Calcul refait en Python : ce n'est pas une sortie d'Ellistat.
"""
import numpy as np

rng = np.random.default_rng(2028)
std = np.array([1] * 20 + [0] * 10)          # 1 = OK, 0 = KO
limite = np.zeros(30, bool); limite[[17, 18, 19, 20, 21, 22]] = True
# probabilité de rejeter (dire KO) : (pièce OK nette, OK limite, KO limite, KO nette)
profils = {"C1": (0.03, 0.45, 0.90, 0.99),   # strict
           "C2": (0.02, 0.15, 0.80, 0.98),   # correct
           "C3": (0.01, 0.05, 0.45, 0.85)}   # laxiste

def p_rejet(prof, i):
    if std[i] == 1:
        return prof[1] if limite[i] else prof[0]
    return prof[2] if limite[i] else prof[3]

J = {c: np.array([[0 if rng.random() < p_rejet(pr, i) else 1 for _ in range(2)] for i in range(30)])
     for c, pr in profils.items()}

def kappa(a, b):
    a = np.asarray(a); b = np.asarray(b)
    po = np.mean(a == b)
    pa, pb = a.mean(), b.mean()
    pe = pa * pb + (1 - pa) * (1 - pb)
    return po, pe, (po - pe) / (1 - pe) if pe < 1 else float("nan")

print("Jugements (ligne = pièce ; standard | C1 C1 | C2 C2 | C3 C3) :")
for i in range(30):
    print(f"{i+1:2d}{'*' if limite[i] else ' '} {'OK' if std[i] else 'KO'} | " +
          " | ".join(" ".join("OK" if v else "KO" for v in J[c][i]) for c in profils))

print(f"\n{'Ctrl':5s}{'répét.%':>9s}{'effic.%':>9s}{'erreur%':>9s}{'f.alarme%':>11s}{'kappa/std':>11s}{'p_o':>7s}{'p_e':>7s}")
for c in profils:
    j = J[c]
    rep = np.mean(j[:, 0] == j[:, 1]) * 100
    eff = np.mean(np.all(j == std[:, None], axis=1)) * 100     # pièce juste aux 2 passages
    err = np.mean(j[std == 0] == 1) * 100                        # KO accepté / jugements KO
    fa = np.mean(j[std == 1] == 0) * 100                         # OK rejeté / jugements OK
    po, pe, k = kappa(j.ravel(), np.repeat(std, 2))
    print(f"{c:5s}{rep:9.1f}{eff:9.1f}{err:9.1f}{fa:11.1f}{k:11.3f}{po:7.3f}{pe:7.3f}")

print("\nKappa de Cohen entre contrôleurs (passage par passage, 60 paires) :")
noms = list(profils)
for a in range(3):
    for b in range(a + 1, 3):
        po, pe, k = kappa(J[noms[a]].ravel(), J[noms[b]].ravel())
        print(f"  {noms[a]}-{noms[b]} : p_o = {po:.3f} ; p_e = {pe:.3f} ; kappa = {k:.3f}")

# accord global : les 6 jugements identiques et égaux au standard
tout = np.hstack([J[c] for c in profils])
acc = np.mean(np.all(tout == std[:, None], axis=1)) * 100
print(f"Accord global (6 jugements = standard) : {acc:.1f} % des pièces")

# kappa de Fleiss sur les 6 jugements par pièce
nr = tout.shape[1]
nOK = tout.sum(axis=1); nKO = nr - nOK
Pi = (nOK * (nOK - 1) + nKO * (nKO - 1)) / (nr * (nr - 1))
pOK = nOK.sum() / tout.size
Pbar = Pi.mean(); Pe = pOK ** 2 + (1 - pOK) ** 2
print(f"Kappa de Fleiss (6 jugements/pièce) = {(Pbar - Pe)/(1 - Pe):.3f}")

# piège du « tout OK »
toutok = np.ones(30, int)
po, pe, k = kappa(toutok, std)
print(f"\nContrôleur qui dit tout OK : accord brut avec le standard = {po*100:.1f} % ; kappa = {k:.3f}")
po, pe, k = kappa(toutok, toutok)
print(f"Deux contrôleurs qui disent tout OK : accord = {po*100:.0f} % ; p_e = {pe:.0f} ; kappa indéfini ({k})")
