"""Chapitre 07 : table L8 de Taguchi, table des interactions entre colonnes,
alias et résolution pour deux placements de 4 facteurs.
Calcul refait en Python (hors Ellistat).

Construction : trois colonnes de base a, b, c (bits 0/1 du numéro d'essai),
les autres colonnes sont des sommes modulo 2 (produits en codage -1/+1).
Numérotation standard de Taguchi : 1=a, 2=b, 3=ab, 4=c, 5=ac, 6=bc, 7=abc.
Niveaux notés 1 et 2 (1 si le bit vaut 0).
"""
import itertools
import numpy as np

# Chaque colonne est identifiée par son « mot » (sous-ensemble de {a,b,c})
MOTS = {1: "a", 2: "b", 3: "ab", 4: "c", 5: "ac", 6: "bc", 7: "abc"}


def produit(m1, m2):
    """Produit de deux mots (différence symétrique)."""
    return "".join(sorted(set(m1) ^ set(m2)))


def col_de_mot(m):
    for k, v in MOTS.items():
        if sorted(v) == sorted(m):
            return k
    return None


# ---------------------------------------------------------------- table L8
lignes = []
for a, b, c in itertools.product([0, 1], repeat=3):
    bits = {"a": a, "b": b, "c": c}
    ligne = []
    for k in range(1, 8):
        s = sum(bits[ch] for ch in MOTS[k]) % 2
        ligne.append(1 + s)
    lignes.append(ligne)
L8 = np.array(lignes)
print("Table L8 (niveaux 1/2)")
for i, l in enumerate(L8, 1):
    print(i, " ".join(map(str, l)))

# contrôle d'orthogonalité en codage -1/+1
X = np.where(L8 == 1, -1, 1)
G = X.T @ X
print("X'X diagonale ?", np.allclose(G, 8 * np.eye(7)))
# chaque couple de colonnes : les 4 combinaisons (1,1),(1,2),(2,1),(2,2) apparaissent 2 fois
ok = all(
    sorted(itertools.product([1, 2], repeat=2))
    == sorted(set(zip(L8[:, i], L8[:, j])))
    and all(list(zip(L8[:, i], L8[:, j])).count(p) == 2 for p in itertools.product([1, 2], repeat=2))
    for i in range(7) for j in range(i + 1, 7)
)
print("Équilibre par paires :", ok)

# ---------------------------------------------------------------- table des interactions
print("\nTable des interactions (colonne i x colonne j -> colonne)")
for i in range(1, 8):
    print(i, [col_de_mot(produit(MOTS[i], MOTS[j])) if j > i else "-" for j in range(1, 8)])

# vérification numérique : produit des colonnes codées
for i in range(1, 8):
    for j in range(i + 1, 8):
        k = col_de_mot(produit(MOTS[i], MOTS[j]))
        # au signe près (avec 1 -> -1, 2 -> +1, le produit vaut l'opposé de la colonne)
        assert np.array_equal(X[:, i - 1] * X[:, j - 1], -X[:, k - 1])
print("Table des interactions vérifiée sur les colonnes codées (au signe près).")


# ---------------------------------------------------------------- placements
def alias(placement):
    """placement : dict facteur -> colonne. Renvoie pour chaque colonne
    les effets (principaux et interactions d'ordre 2) qui y tombent."""
    contenu = {k: [] for k in range(1, 8)}
    for f, c in placement.items():
        contenu[c].append(f)
    for (f1, c1), (f2, c2) in itertools.combinations(placement.items(), 2):
        contenu[col_de_mot(produit(MOTS[c1], MOTS[c2]))].append(f1 + "*" + f2)
    return contenu


def resolution(placement):
    """Longueur du plus court mot du sous-groupe de définition
    (produits de facteurs qui donnent la colonne constante)."""
    facteurs = list(placement)
    rmin = None
    for r in range(2, len(facteurs) + 1):
        for comb in itertools.combinations(facteurs, r):
            m = ""
            for f in comb:
                m = produit(m, MOTS[placement[f]])
            if m == "":
                rmin = r if rmin is None else min(rmin, r)
    return rmin


for nom, pl in [("Placement 1 (A,B,C,D en 1,2,4,7)", {"A": 1, "B": 2, "C": 4, "D": 7}),
                ("Placement 2 (A,B,C,D en 1,2,3,4)", {"A": 1, "B": 2, "C": 3, "D": 4})]:
    print("\n" + nom, "-> résolution", resolution(pl))
    for k, v in alias(pl).items():
        print(" colonne", k, ":", ", ".join(v) if v else "(vide)")
