"""Chapitre 01, section « Clic droit » :
trier une seule colonne casse l'appariement des mesures.
Deux cas : (a) format large, tri de P1 seule ; (b) format long, tri de Diametre seule.
Calcul refait en Python ; ce n'est pas une sortie d'Ellistat.
"""
import numpy as np

from ch01_commun import lire_large, large_vers_long, sigmas, cp_cpk, fr

large = lire_large()
long = large_vers_long(large)
ref = sigmas(long)

# (a) Format large : seule la colonne P1 est triée (les autres ne suivent pas)
a = large.copy()
a["P1"] = np.sort(a["P1"].to_numpy())
lignes_modifiees = int((a["P1"].to_numpy() != large["P1"].to_numpy()).sum())
la = large_vers_long(a)
sa = sigmas(la)
print("(a) Tri de P1 seule dans le format large")
print("    P1 avant :", [fr(v, 2) for v in large["P1"]])
print("    P1 après :", [fr(v, 2) for v in a["P1"]])
print("    lignes dont P1 a changé :", lignes_modifiees, "sur", len(a))

# (b) Format long : seule la colonne Diametre est triée, Echantillon reste en place
b = long.copy()
b["Diametre"] = np.sort(b["Diametre"].to_numpy())
sb = sigmas(b)
print("\n(b) Tri de Diametre seule dans le format long")

print("\nComparaison            référence | (a) P1 triée | (b) Diametre trié")
for cle, lib, nd in [("moyenne", "moyenne", 4), ("s global", "s global", 4),
                     ("Rbar", "R barre", 4), ("R/d2", "sigma R/d2", 4),
                     ("MR/1,128", "sigma MR/1,128", 4)]:
    print(f"  {lib:16s} {fr(ref[cle], nd):>10s} | {fr(sa[cle], nd):>12s} | {fr(sb[cle], nd):>12s}")
for nom, s in [("référence", ref), ("(a)", sa), ("(b)", sb)]:
    cp, cpk = cp_cpk(s["R/d2"], s["moyenne"])
    pp, ppk = cp_cpk(s["s global"], s["moyenne"])
    print(f"  {nom:10s} Cp = {fr(cp, 2)}  Cpk = {fr(cpk, 2)}  Pp = {fr(pp, 2)}  Ppk = {fr(ppk, 2)}")

# Coordonnées pgfplots : étendue par échantillon avant / après (b)
def etendues(df):
    g = df.groupby("Echantillon")["Diametre"]
    return (g.max() - g.min()).round(4)

print("\nCoordonnées pgfplots, étendue par échantillon (référence) :")
print("  " + " ".join(f"({k},{v:.2f})" for k, v in etendues(long).items()))
print("Coordonnées pgfplots, étendue par échantillon (b) Diametre trié :")
print("  " + " ".join(f"({k},{v:.2f})" for k, v in etendues(b).items()))
print("Coordonnées pgfplots, étendue par échantillon (a) P1 triée :")
print("  " + " ".join(f"({k},{v:.2f})" for k, v in etendues(la).items()))
