"""Chapitre 05 : puissance et taille d'échantillon.

Calcul refait en Python (scipy, statsmodels), ce n'est pas une sortie d'Ellistat.
1. Courbes de puissance du test t pour deux moyennes indépendantes (bilatéral, alpha = 5 %),
   en fonction de l'écart réel exprimé en écarts-types (d = delta / sigma), pour n = 5, 10, 20 par groupe.
2. Taille par groupe pour une puissance de 80 % : loi en 1 / d².
3. Plus petit écart détectable à 80 % entre deux opérateurs de ANOVA_TP_R.csv (n = 20, sigma résiduel).
4. Recalcul de l'exemple du guide « 15 % -> 5 %, 111 pièces par lot » sous plusieurs hypothèses.
"""
import math

import numpy as np
from scipy import stats
from statsmodels.stats.power import NormalIndPower, TTestIndPower
from statsmodels.stats.proportion import proportion_effectsize

tt = TTestIndPower()

print("=== 1. Puissance du test t (deux groupes, bilatéral, alpha = 0,05) ===")
grille = np.round(np.arange(0.0, 3.01, 0.1), 2)
for n in (5, 10, 20):
    pts = [(d, tt.power(effect_size=d, nobs1=n, alpha=0.05, ratio=1.0, alternative="two-sided"))
           if d > 0 else (0.0, 0.05) for d in grille]
    print(f"n = {n:2d} : " + " ".join(f"({d:.2f},{p:.3f})" for d, p in pts))
for n in (5, 10, 20):
    d80 = tt.solve_power(nobs1=n, alpha=0.05, power=0.80, ratio=1.0, alternative="two-sided")
    print(f"n = {n:2d} par groupe : écart détectable à 80 % = {d80:.2f} sigma")

print("\n=== 2. Taille par groupe pour 80 % de puissance (t bilatéral, alpha = 0,05) ===")
for d in (0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 3.0):
    n = tt.solve_power(effect_size=d, alpha=0.05, power=0.80, ratio=1.0, alternative="two-sided")
    n_norm = 2 * (stats.norm.ppf(0.975) + stats.norm.ppf(0.80)) ** 2 / d ** 2
    print(f"d = {d:4.2f} : n = {n:7.2f} (arrondi {math.ceil(n)}), approximation normale 2(z+z)²/d² = {n_norm:7.2f}")

print("\n=== 3. Opérateurs (ANOVA_TP_R.csv) : n = 20 par opérateur, sigma résiduel 0,0206 ===")
sig = 0.0206
d80 = tt.solve_power(nobs1=20, alpha=0.05, power=0.80, ratio=1.0, alternative="two-sided")
print(f"écart détectable à 80 % entre deux opérateurs : {d80:.3f} sigma = {d80*sig:.4f} mm "
      f"= {100*d80*sig/0.15:.1f} % de l'IT 0,15 mm")

print("\n=== 4. Exemple du guide : proportion 15 % -> 5 %, deux lots de même taille ===")
p1, p2 = 0.15, 0.05
pbar = (p1 + p2) / 2
dp = p1 - p2


def n_pool(za, zb):
    """Approximation normale, variance groupée sous H0, sans correction de continuité."""
    return (za * math.sqrt(2 * pbar * (1 - pbar)) + zb * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / dp ** 2


def n_nonpool(za, zb):
    """Approximation normale, variances non groupées (formule de Wald)."""
    return (za + zb) ** 2 * (p1 * (1 - p1) + p2 * (1 - p2)) / dp ** 2


def cc(n):
    """Correction de continuité de Fleiss."""
    return n / 4 * (1 + math.sqrt(1 + 4 / (n * dp))) ** 2


h = proportion_effectsize(p1, p2)
print(f"taille d'effet arcsinus h = {h:.4f}")
lignes = []
for sens in ("bilatéral", "unilatéral"):
    for puis in (0.80, 0.90):
        za = stats.norm.ppf(1 - 0.05 / 2) if sens == "bilatéral" else stats.norm.ppf(1 - 0.05)
        zb = stats.norm.ppf(puis)
        a = n_pool(za, zb)
        b = cc(a)
        c = n_nonpool(za, zb)
        alt = "two-sided" if sens == "bilatéral" else "larger"
        d = NormalIndPower().solve_power(effect_size=h, alpha=0.05, power=puis, ratio=1.0, alternative=alt)
        print(f"{sens:10s} puissance {puis:.0%} : groupée {a:6.1f} -> {math.ceil(a):3d} | "
              f"groupée + Fleiss {b:6.1f} -> {math.ceil(b):3d} | non groupée {c:6.1f} -> {math.ceil(c):3d} | "
              f"arcsinus {d:6.1f} -> {math.ceil(d):3d}")

# Puissance exacte (énumération binomiale) du test z groupé unilatéral à n = 111 par lot
n = 111
k = np.arange(n + 1)
pm1 = stats.binom.pmf(k, n, p1)
pm2 = stats.binom.pmf(k, n, p2)
K1, K2 = np.meshgrid(k, k, indexing="ij")
ph1, ph2 = K1 / n, K2 / n
pb = (K1 + K2) / (2 * n)
se = np.sqrt(np.where(pb * (1 - pb) > 0, 2 * pb * (1 - pb) / n, np.nan))
z = np.where(np.isnan(se), 0.0, (ph1 - ph2) / np.where(np.isnan(se), 1, se))
rejet = z > stats.norm.ppf(0.95)
proba = np.outer(pm1, pm2)
print(f"\nn = 111 par lot, test z groupé unilatéral à 5 % : puissance exacte = {proba[rejet].sum():.3f}")
# Risque alpha réel sous H0 (p = 0,10 dans les deux lots)
pm0 = stats.binom.pmf(k, n, pbar)
print(f"risque alpha réel sous H0 (p = 0,10 dans les deux lots) = {np.outer(pm0, pm0)[rejet].sum():.4f}")
