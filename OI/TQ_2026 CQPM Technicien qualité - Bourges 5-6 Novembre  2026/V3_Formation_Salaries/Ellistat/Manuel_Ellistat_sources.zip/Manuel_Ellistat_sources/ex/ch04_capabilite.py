"""Chapitre 04 : capabilité des butées (Butees_diametre.csv), tolérance 11,85 / 12,00 mm.

Produit : statistiques de base, grille des estimateurs de sigma court terme,
Cp/Cpk/Pp/Ppk, ppm estimés et observés, tests de normalité, intervalle de
confiance de Cpk (Bissell), coordonnées de l'histogramme, de la droite de Henry,
des cartes X-barre/R et du schéma court terme / global.
Calcul refait en Python : ce ne sont pas des sorties d'Ellistat.
"""
from pathlib import Path
import math
import numpy as np
from scipy import stats
from scipy.special import gammaln

DATA = Path(__file__).resolve().parent.parent / "donnees" / "Butees_diametre.csv"
LSL, USL = 11.85, 12.00


def lire():
    lignes = DATA.read_text(encoding="utf-8-sig").splitlines()
    groupes = []
    for ligne in lignes[1:]:
        champs = ligne.split(";")[1:]
        vals = [float(c.replace(",", ".")) for c in champs if c.strip()]
        if vals:
            groupes.append(vals)
    return np.array(groupes)


def c4(n):
    return math.sqrt(2.0 / (n - 1)) * math.exp(gammaln(n / 2) - gammaln((n - 1) / 2))


D2 = {2: 1.128, 3: 1.693, 4: 2.059, 5: 2.326, 6: 2.534}
A2, D3, D4 = 0.577, 0.0, 2.114  # constantes n = 5


def cap(sig, m):
    cp = (USL - LSL) / (6 * sig)
    cpk = min(USL - m, m - LSL) / (3 * sig)
    return cp, cpk


def main():
    X = lire()
    k, n = X.shape
    x = X.ravel()  # ordre chronologique : échantillon puis pièce
    N = x.size
    m = x.mean()
    print(f"k = {k} échantillons, n = {n}, N = {N}")
    print(f"moyenne = {m:.4f}  min = {x.min():.2f}  max = {x.max():.2f}  médiane = {np.median(x):.3f}")
    moy = X.mean(axis=1)
    R = X.max(axis=1) - X.min(axis=1)
    S = X.std(axis=1, ddof=1)
    print("moyennes échantillons :", np.round(moy, 4))
    print("étendues :", np.round(R, 3))
    print("écarts-types :", np.round(S, 5))

    # --- grille des estimateurs de sigma court terme
    Rbar = R.mean()
    s_rd2 = Rbar / D2[n]
    s_pool = math.sqrt(np.mean(S ** 2))
    dfp = k * (n - 1)
    s_pool_c4 = s_pool / c4(dfp + 1)
    Sbar = S.mean()
    s_sc4 = Sbar / c4(n)
    MR = np.abs(np.diff(x))
    s_mr = MR.mean() / D2[2]
    s_glob = x.std(ddof=1)
    s_glob_n = x.std(ddof=0)
    print(f"\nR̄ = {Rbar:.4f}, S̄ = {Sbar:.5f}, MR̄ = {MR.mean():.5f}")
    print(f"c4(5) = {c4(5):.4f}, c4({dfp + 1}) = {c4(dfp + 1):.4f}, d2(5) = {D2[5]}, d2(2) = {D2[2]}")
    grille = [
        ("R̄/d2", s_rd2), ("écart-type groupé", s_pool), ("groupé/c4", s_pool_c4),
        ("S̄/c4", s_sc4), ("étendues mobiles MR̄/1,128", s_mr),
        ("s global (n-1)", s_glob), ("sigma global (n)", s_glob_n),
    ]
    print("\nGrille sigma -> Cp, Cpk")
    for nom, s in grille:
        cp, cpk = cap(s, m)
        print(f"  {nom:28s} sigma = {s:.5f}  Cp = {cp:.3f}  Cpk = {cpk:.3f}")

    cp, cpk = cap(s_rd2, m)
    pp, ppk = cap(s_glob, m)
    cpu = (USL - m) / (3 * s_rd2)
    cpl = (m - LSL) / (3 * s_rd2)
    print(f"\nRetenu fiche C : Cp = {cp:.2f}, Cpk = {cpk:.2f} (Cpu {cpu:.2f}, Cpl {cpl:.2f}) ; Pp = {pp:.2f}, Ppk = {ppk:.2f}")
    print(f"centre tolérance = {(LSL + USL) / 2:.3f}, décentrage = {m - (LSL + USL) / 2:.4f}")
    print(f"Cpk si centré = Cp ; Cpm (cible = milieu) = {(USL - LSL) / (6 * math.sqrt(s_glob ** 2 + (m - 11.925) ** 2)):.3f}")

    # --- ppm
    for nom, s in (("court terme R̄/d2", s_rd2), ("global s", s_glob)):
        pinf = stats.norm.cdf((LSL - m) / s)
        psup = stats.norm.sf((USL - m) / s)
        print(f"ppm {nom}: < LSL {pinf * 1e6:.0f}  > USL {psup * 1e6:.3f}  total {(pinf + psup) * 1e6:.0f}")
    obs_inf = int((x < LSL).sum())
    obs_eq = int((np.isclose(x, LSL)).sum())
    print(f"observé : {obs_inf} valeurs < 11,85 ({obs_inf / N * 1e6:.0f} ppm), {obs_eq} valeurs = 11,85, {(x > USL).sum()} > 12,00")

    # --- normalité et forme
    W, pW = stats.shapiro(x)
    F = stats.norm.cdf((np.sort(x) - m) / x.std(ddof=1))
    i = np.arange(1, N + 1)
    A2stat = -N - np.sum((2 * i - 1) * (np.log(F) + np.log(1 - F[::-1]))) / N

    class _AD:  # même convention que scipy.stats.anderson (s avec n-1)
        statistic = A2stat
    ad = _AD()
    A2s = ad.statistic * (1 + 0.75 / N + 2.25 / N ** 2)
    if A2s >= 0.6:
        pad = math.exp(1.2937 - 5.709 * A2s + 0.0186 * A2s ** 2)
    elif A2s >= 0.34:
        pad = math.exp(0.9177 - 4.279 * A2s - 1.38 * A2s ** 2)
    elif A2s >= 0.2:
        pad = 1 - math.exp(-8.318 + 42.796 * A2s - 59.938 * A2s ** 2)
    else:
        pad = 1 - math.exp(-13.436 + 101.14 * A2s - 223.73 * A2s ** 2)
    print(f"\nShapiro-Wilk W = {W:.4f}, p = {pW:.3f}")
    print(f"Anderson-Darling A2 = {ad.statistic:.3f}, A2* = {A2s:.3f}, p ≈ {pad:.3f}")
    print(f"asymétrie (skewness, biais corrigé) = {stats.skew(x, bias=False):.3f}, kurtosis excès = {stats.kurtosis(x, bias=False):.3f}")
    print(f"nombre de valeurs distinctes = {len(np.unique(x))} (résolution 0,01)")

    # --- IC de Cpk (Bissell) et de Cp (chi2)
    z = stats.norm.ppf(0.975)
    for nom, val in (("Cpk", cpk), ("Ppk", ppk)):
        se = math.sqrt(1 / (9 * N) + val ** 2 / (2 * (N - 1)))
        print(f"Bissell {nom} = {val:.3f} : SE = {se:.4f}, IC95 = [{val - z * se:.2f} ; {val + z * se:.2f}]")
    nu = N - 1
    lo = pp * math.sqrt(stats.chi2.ppf(0.025, nu) / nu)
    hi = pp * math.sqrt(stats.chi2.ppf(0.975, nu) / nu)
    print(f"IC95 de Pp (chi2, {nu} ddl) = [{lo:.2f} ; {hi:.2f}]")

    # --- histogramme (classes de largeur 0,01 centrées sur les valeurs)
    centres = np.round(np.arange(11.84, 11.931, 0.01), 2)
    eff = [int(np.isclose(x, c).sum()) for c in centres]
    print("\nHistogramme (centre, effectif) :")
    print(" ".join(f"({c:.2f},{e})" for c, e in zip(centres, eff)), " total", sum(eff))
    print(f"échelle courbe normale : N*w = {N * 0.01:.2f}")

    # --- droite de Henry (rangs de Blom)
    xs = np.sort(x)
    q = stats.norm.ppf((np.arange(1, N + 1) - 0.375) / (N + 0.25))
    print("\nHenry (x, z) :")
    print(" ".join(f"({a:.2f},{b:.3f})" for a, b in zip(xs, q)))
    pente, ordo = np.polyfit(q, xs, 1)
    print(f"droite x = {ordo:.4f} + {pente:.4f} z (ajustée) ; théorique x = {m:.4f} + {s_glob:.4f} z")

    # --- cartes X-barre / R
    lcs = m + A2 * Rbar
    lci = m - A2 * Rbar
    lcs3 = m + 3 * s_rd2 / math.sqrt(n)
    print(f"\nCarte Xbarre : LC = {m:.4f}, LCI = {lci:.4f}, LCS = {lcs:.4f} (3 sigma R̄/d2 : {m - 3 * s_rd2 / math.sqrt(n):.4f} ; {lcs3:.4f})")
    print(f"Carte R : LC = {Rbar:.4f}, LCI = {D3 * Rbar:.4f}, LCS = {D4 * Rbar:.4f}")
    print("points X̄ :", " ".join(f"({i + 1},{v:.4f})" for i, v in enumerate(moy)))
    print("points R :", " ".join(f"({i + 1},{v:.2f})" for i, v in enumerate(R)))
    cible = (LSL + USL) / 2
    print(f"Carte centrée cible {cible:.3f} : LCI = {cible - A2 * Rbar:.4f}, LCS = {cible + A2 * Rbar:.4f}")
    hors = [i + 1 for i, v in enumerate(moy) if v > cible + A2 * Rbar or v < cible - A2 * Rbar]
    print(f"échantillons hors limites centrées cible : {hors}")

    # --- découpage arbitraire : groupes = colonnes P1..P5 (6 valeurs prises dans le temps)
    G = X.T
    sp_arb = math.sqrt(np.mean(G.std(axis=1, ddof=1) ** 2))
    Rb_arb = (G.max(axis=1) - G.min(axis=1)).mean() / 2.534
    print(f"\nDécoupage arbitraire par colonne (5 groupes de 6) : sigma groupé = {sp_arb:.4f} -> Cp = {cap(sp_arb, m)[0]:.2f} ; R̄/d2(6) = {Rb_arb:.4f} -> Cp = {cap(Rb_arb, m)[0]:.2f}")

    # --- format long attendu pour Butees_diametre_colonne.csv (contrôle)
    print("\nFormat long (5 premières lignes) : Echantillon;Piece;Diametre")
    for i in range(1):
        for j in range(n):
            print(f"{i + 1};{j + 1};{X[i, j]:.2f}".replace(".", ","))


if __name__ == "__main__":
    main()
