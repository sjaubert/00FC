"""Chapitre 10, contrainte-résistance (formules hors guide).

1. Deux lois normales : P(R < C) = Phi(-(muR - muC) / sqrt(sR^2 + sC^2)).
   Deux jeux de valeurs pour tester le conseil du guide (+20 % sur la moyenne
   de la résistance contre dispersion divisée par 2).
2. Exemple du guide : résistance Weibull beta = 1, eta = 15 000 cycles ;
   contrainte trapézoïdale support [200 ; 30 000], plateau [500 ; 2000]
   (sommets déduits du texte). P = E_S[1 - exp(-S / 15 000)].
   Deux lectures du trapèze : échelle linéaire et échelle logarithmique.
"""
import math

import numpy as np
from scipy import integrate, stats

from ch10_commun import fmt


def p_def_normales(muR, sR, muC, sC):
    z = (muR - muC) / math.hypot(sR, sC)
    return z, stats.norm.cdf(-z)


def cas(nom, muR, sR, muC, sC):
    print(f"\n{nom} : résistance N({muR} ; {sR}), contrainte N({muC} ; {sC})")
    for lib, (m, s) in {"référence": (muR, sR), "moyenne +20 %": (1.2 * muR, sR),
                        "dispersion / 2": (muR, sR / 2)}.items():
        z, p = p_def_normales(m, s, muC, sC)
        print(f"   {lib:15s} : z =", fmt(z, 3), "; P(R < C) =", f"{p:.3e}".replace(".", ","),
              "=", fmt(100 * p, 3), "%")


cas("Cas A (résistance peu dispersée, CV 8 %)", 500, 40, 380, 30)
cas("Cas B (résistance très dispersée, CV 30 %)", 100, 30, 60, 5)

# Point de croisement des deux densités du cas A (pour la figure)
from scipy import optimize
xc = optimize.brentq(lambda x: stats.norm.pdf(x, 380, 30) - stats.norm.pdf(x, 500, 40), 380, 500)
print("\nCas A : les densités se croisent en x =", fmt(xc, 1), "MPa")


# 2. Exemple du guide
a, b, c, d = 200.0, 500.0, 2000.0, 30000.0
eta = 15000.0


def trapeze(x, a, b, c, d):
    h = 2.0 / ((d - a) + (c - b))
    x = np.asarray(x, float)
    y = np.where(x < a, 0, np.where(x < b, h * (x - a) / (b - a),
                 np.where(x <= c, h, np.where(x <= d, h * (d - x) / (d - c), 0))))
    return y


def F_res(s):
    return 1 - np.exp(-s / eta)


pts = [a, b, c, d]
p_lin = sum(integrate.quad(lambda s: trapeze(s, a, b, c, d) * F_res(s), u, v, limit=200)[0]
            for u, v in zip(pts[:-1], pts[1:]))
print("\nGuide, trapèze en échelle linéaire : P =", fmt(100 * p_lin, 2), "%")
# moyenne de la contrainte trapézoïdale (lecture linéaire)
m_lin = sum(integrate.quad(lambda s: s * trapeze(s, a, b, c, d), u, v)[0]
            for u, v in zip(pts[:-1], pts[1:]))
print("   moyenne de la contrainte (linéaire) =", fmt(m_lin, 0), "cycles")

la, lb, lc, ld = map(math.log, pts)
p_log = sum(integrate.quad(lambda u: trapeze(u, la, lb, lc, ld) * F_res(math.exp(u)), u1, u2, limit=200)[0]
            for u1, u2 in zip([la, lb, lc], [lb, lc, ld]))
print("Guide, trapèze en échelle logarithmique : P =", fmt(100 * p_log, 2), "%")
m_log = sum(integrate.quad(lambda u: math.exp(u) * trapeze(u, la, lb, lc, ld), u1, u2)[0]
            for u1, u2 in zip([la, lb, lc], [lb, lc, ld]))
print("   moyenne de la contrainte (log) =", fmt(m_log, 0), "cycles")
print("   contrôle : intégrale de la densité linéaire =",
      fmt(sum(integrate.quad(lambda s: trapeze(s, a, b, c, d), u, v)[0] for u, v in zip(pts[:-1], pts[1:])), 4))
