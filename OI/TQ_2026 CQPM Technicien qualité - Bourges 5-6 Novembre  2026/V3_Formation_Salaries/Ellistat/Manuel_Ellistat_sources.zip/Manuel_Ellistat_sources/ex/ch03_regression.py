# -*- coding: utf-8 -*-
"""Chapitre 03 : corrélation et régression.

Toutes les données de ce script sont SIMULÉES (numpy default_rng, graine 2026).
  1. Nuage XY : température de la pièce au contrôle (°C) et diamètre mesuré (mm), n = 30.
  2. Trois pièges : point extrême, relation en cloche, facteur caché.
  3. Matrice de corrélation de 5 grandeurs (facteur caché : température ambiante).
  4. Corrélations fortuites : 10 caractéristiques indépendantes, 45 couples.
Calculs refaits en Python, pas des sorties d'Ellistat.
"""
import numpy as np
from scipy import stats
from ch03_commun import fr, c, coords, ecrire, titre, GRAINE

rng = np.random.default_rng(GRAINE)

# ----------------------------------------------------------------- 1. régression
titre(f"1. Nuage XY avec droite de régression (simulé, graine {GRAINE})")
n = 30
T = np.round(rng.uniform(18, 30, n), 1)
D = np.round(11.880 + 0.0011 * (T - 20) + rng.normal(0, 0.004, n), 4)
reg = stats.linregress(T, D)
print(f"n = {n} ; T de {fr(T.min(), 1)} à {fr(T.max(), 1)} °C")
print(f"Pente b = {reg.slope:.6f} mm/°C ; ordonnée à l'origine a = {fr(reg.intercept, 4)} mm")
print(f"r = {fr(reg.rvalue, 3)} ; R² = {fr(reg.rvalue ** 2, 3)} ; p (pente) = {reg.pvalue:.2e}")
res = D - (reg.intercept + reg.slope * T)
se = np.sqrt((res ** 2).sum() / (n - 2))
print(f"Écart-type résiduel = {fr(se, 4)} mm")
tc = stats.t.ppf(0.975, n - 2)
print(f"IC 95 % de la pente : [{reg.slope - tc * reg.stderr:.6f} ; {reg.slope + tc * reg.stderr:.6f}]")
print(f"Prévision à 20 °C : {fr(reg.intercept + reg.slope * 20, 4)} mm ; à 28 °C : {fr(reg.intercept + reg.slope * 28, 4)} mm")
xx = np.array([17.5, 30.5])
ecrire("nuage_reg", r"\addplot[only marks,mark=*,mark size=1.4pt,uimmblue] coordinates {" + coords(T, D, 1, 4) + "};\n"
       + r"\addplot[thick,uimmred] coordinates {" + coords(xx, reg.intercept + reg.slope * xx, 1, 5) + "};\n"
       + rf"\def\chtroispente{{{fr(reg.slope * 1000, 2)}}}\def\chtroisorig{{{fr(reg.intercept, 4)}}}"
       + rf"\def\chtroisrr{{{fr(reg.rvalue ** 2, 3)}}}\def\chtroisr{{{fr(reg.rvalue, 3)}}}")

# ----------------------------------------------------------------- 2. pièges
titre("2a. Point extrême")
xa = rng.normal(0, 1, 19)
ya = rng.normal(0, 1, 19)
r19, p19 = stats.pearsonr(xa, ya)
EXT = 16.0  # coordonnées (16 ; 16) du point extrême ajouté
xa2, ya2 = np.append(xa, EXT), np.append(ya, EXT)
r20 = stats.pearsonr(xa2, ya2)[0]
rs20 = stats.spearmanr(xa2, ya2)[0]
print(f"19 points tirés indépendamment : r = {fr(r19, 2)} (p = {fr(p19, 2)}) ; "
      f"avec le point (16 ; 16) : r = {fr(r20, 2)} ; Spearman = {fr(rs20, 2)}")
ecrire("piege_extreme", r"\addplot[only marks,mark=*,mark size=1.2pt,uimmblue] coordinates {" + coords(xa, ya, 3, 3) + "};\n"
       + r"\addplot[only marks,mark=*,mark size=2pt,uimmred] coordinates {(16,16)};"
       + rf"\def\chtroisra{{{fr(r20, 2)}}}\def\chtroisrasans{{{fr(r19, 2)}}}")

titre("2b. Relation en cloche")
xb = np.linspace(0, 10, 25)
yb = 10 - (xb - 5) ** 2 / 2.5 + rng.normal(0, 0.6, xb.size)
rb = stats.pearsonr(xb, yb)[0]
print(f"25 points, y = 10 - (x - 5)²/2,5 + bruit : r = {fr(rb, 2)}")
ecrire("piege_cloche", r"\addplot[only marks,mark=*,mark size=1.2pt,uimmblue] coordinates {" + coords(xb, yb, 3, 3) + "};"
       + rf"\def\chtroisrb{{{fr(rb, 2)}}}")

titre("2c / 3. Facteur caché et matrice de corrélation (n = 40)")
m = 40
amb = rng.normal(22, 3, m)                                  # température ambiante (°C)
dil = 0.012 * (amb - 22) + rng.normal(0, 0.012, m)          # dilatation de la pièce (mm)
der = 0.25 * (amb - 22) + rng.normal(0, 0.35, m)            # dérive du capteur (µm)
pre = rng.normal(6.0, 0.2, m)                               # pression (bar), sans lien
ser = rng.normal(25, 1.0, m) + 0.0 * amb                    # couple de serrage (N.m), sans lien
noms = ["Temp. ambiante", "Dilatation", "Dérive capteur", "Pression", "Couple"]
X = np.vstack([amb, dil, der, pre, ser])
R = np.corrcoef(X)
for i in range(5):
    print("  " + noms[i].ljust(16) + " ".join(f"{fr(R[i, j], 2):>6s}" for j in range(5)))
rdc = stats.pearsonr(dil, der)
print(f"Dilatation / dérive : r = {fr(rdc[0], 2)} ; p = {rdc.pvalue:.1e}")
# corrélation partielle à température constante
def partielle(a, b, z):
    ra = a - np.polyval(np.polyfit(z, a, 1), z)
    rb_ = b - np.polyval(np.polyfit(z, b, 1), z)
    return np.corrcoef(ra, rb_)[0, 1]
print(f"Corrélation partielle dilatation / dérive à température fixée : {fr(partielle(dil, der, amb), 2)}")
ecrire("piege_cache", r"\addplot[only marks,mark=*,mark size=1.2pt,uimmblue] coordinates {" + coords(dil * 1000, der, 2, 3) + "};"
       + rf"\def\chtroisrc{{{fr(rdc[0], 2)}}}")
cell = []
for i in range(5):
    for j in range(5):
        v = R[i, j]
        coul = ("uimmred" if v > 0 else "uimmblue") + f"!{int(round(abs(v) * 60))}"
        cell.append(rf"\chtroiscase{{{j}}}{{{i}}}{{{coul}}}{{{fr(v, 2)}}}")
ecrire("matrice", "\n".join(cell))

# ----------------------------------------------------------------- 4. corrélations fortuites
titre("4. Corrélations fortuites : 10 caractéristiques indépendantes, n = 30")
nsim, k, nn = 2000, 10, 30
seuil = stats.t.ppf(0.975, nn - 2)
rcrit = seuil / np.sqrt(nn - 2 + seuil ** 2)
compte = []
for _ in range(nsim):
    Z = rng.normal(size=(nn, k))
    Rz = np.corrcoef(Z, rowvar=False)
    iu = np.triu_indices(k, 1)
    compte.append((np.abs(Rz[iu]) > rcrit).sum())
compte = np.array(compte)
print(f"Couples : {k * (k - 1) // 2} ; |r| critique à 5 % (n = 30) = {fr(rcrit, 3)}")
print(f"Attendu théorique : 45 x 0,05 = {fr(45 * 0.05, 2)} couples « significatifs »")
print(f"Simulation ({nsim} tirages) : moyenne = {fr(compte.mean(), 2)} ; "
      f"P(au moins un) = {fr((compte >= 1).mean() * 100, 1)} %")
