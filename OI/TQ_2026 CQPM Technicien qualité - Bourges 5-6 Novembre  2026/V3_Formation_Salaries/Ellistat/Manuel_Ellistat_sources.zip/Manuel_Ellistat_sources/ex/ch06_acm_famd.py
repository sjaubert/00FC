# -*- coding: utf-8 -*-
"""Chapitre 06, ACM et FAMD sur un exemple réduit (8 pièces).

Données inventées pour l'exemple (pas des mesures réelles) : 3 variables qualitatives
(Machine, Équipe, Aspect) et, pour la FAMD, 2 variables quantitatives simulées avec la
graine numpy 88. Calcul refait en Python selon les définitions usuelles
(ACM = analyse des correspondances du tableau disjonctif complet ; FAMD de Pagès :
quantitatives centrées-réduites avec l'écart-type n, indicatrices divisées par la racine
de leur fréquence puis centrées). Ce n'est pas une sortie d'Ellistat.
"""
import os
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
SORTIES = os.path.join(ICI, "sorties_ch06")

pieces = [f"P{i}" for i in range(1, 9)]
machine = ["A", "A", "A", "B", "B", "A", "B", "B"]
equipe = ["Matin", "Matin", "Après-midi", "Après-midi", "Après-midi", "Matin", "Nuit", "Après-midi"]
aspect = ["Conforme", "Conforme", "Conforme", "Défaut", "Défaut", "Conforme", "Défaut", "Conforme"]
qual = {"Machine": machine, "Équipe": equipe, "Aspect": aspect}
n, Q = len(pieces), len(qual)


def disjonctif(vars_):
    cols, noms = [], []
    for v, val in vars_.items():
        mods = sorted(set(val), key=val.index)
        for mo in mods:
            cols.append([1.0 if x == mo else 0.0 for x in val])
            noms.append(f"{v}={mo}")
    return np.array(cols).T, noms


Zd, noms = disjonctif(qual)
K = Zd.shape[1]
print("Tableau disjonctif complet (", n, "x", K, ") :")
print("       " + " ".join(f"{c.split('=')[1][:6]:>6s}" for c in noms))
for i in range(n):
    print(f"  {pieces[i]:4s} " + " ".join(f"{int(v):6d}" for v in Zd[i]))
print("  somme de chaque ligne =", set(Zd.sum(axis=1)), "(= Q)")
nk = Zd.sum(axis=0)
print("  effectifs des modalités :", dict(zip(noms, nk.astype(int))))

# ---------------------------------------------------------------- ACM
P = Zd / (n * Q)
r = P.sum(axis=1)
c = P.sum(axis=0)
S = (P - np.outer(r, c)) / np.sqrt(np.outer(r, c))
U, sv, Vt = np.linalg.svd(S, full_matrices=False)
lam = sv ** 2
nb = K - Q
lam = lam[:nb]
print(f"\nACM : K = {K}, Q = {Q}, axes non triviaux K - Q = {nb}")
print("  valeurs propres :", np.round(lam, 4), " somme =", round(lam.sum(), 4),
      " ; K/Q - 1 =", round(K / Q - 1, 4))
print("  % d'inertie :", np.round(100 * lam / lam.sum(), 1))
print("  1/Q =", round(1 / Q, 4), "(seuil analogue à lambda > 1 en ACP)")
inert_mod = (1 - nk / n) / Q
print("  inertie de chaque modalité (1 - nk/n)/Q :")
for nm, v in zip(noms, inert_mod):
    print(f"    {nm:22s} {v:.4f}")
print("  inertie de chaque variable (Kj - 1)/Q : Machine", round(1 / Q, 4), " Équipe", round(2 / Q, 4),
      " Aspect", round(1 / Q, 4))
Fi = (U[:, :nb] * sv[:nb]) / np.sqrt(r)[:, None]      # coordonnées des individus
Gk = (Vt[:nb].T * sv[:nb]) / np.sqrt(c)[:, None]      # coordonnées des modalités
for a in range(2):                                    # orientation
    if Gk[np.argmax(np.abs(Gk[:, a])), a] < 0:
        Gk[:, a] *= -1
        Fi[:, a] *= -1
ctr = 100 * c[:, None] * Gk ** 2 / lam
print("  modalités : coord. axe 1, axe 2, contribution axe 1 (%), axe 2 (%)")
for k in range(K):
    print(f"    {noms[k]:22s} {Gk[k,0]:+.3f} {Gk[k,1]:+.3f}   {ctr[k,0]:5.1f} {ctr[k,1]:5.1f}")
# rapport de corrélation eta2 de chaque variable avec les axes
deb = 0
eta = []
for v, val in qual.items():
    Kj = len(set(val))
    e = []
    for a in range(2):
        f = Fi[:, a]
        moy = [f[Zd[:, deb + t] == 1].mean() for t in range(Kj)]
        eff = [nk[deb + t] for t in range(Kj)]
        e.append(sum(ef * mo ** 2 for ef, mo in zip(eff, moy)) / n / f.var())
    eta.append(e)
    print(f"  eta2 {v:8s} axe 1 = {e[0]:.3f}  axe 2 = {e[1]:.3f}")
    deb += Kj
print("  moyenne des eta2 sur l'axe 1 =", round(np.mean([e[0] for e in eta]), 4), "= lambda1 =", round(lam[0], 4))
print("  barycentre : modalité Machine=B, coord axe1 =", round(Gk[noms.index('Machine=B'), 0], 4),
      " ; moyenne des individus B / sqrt(lambda1) =",
      round(Fi[np.array(machine) == "B", 0].mean() / np.sqrt(lam[0]), 4))

with open(os.path.join(SORTIES, "acm_plan.tex"), "w", encoding="utf-8") as f:
    vus = {}
    for i in range(n):
        cle = (round(Fi[i, 0], 3), round(Fi[i, 1], 3))
        vus.setdefault(cle, []).append(pieces[i])
    for (x, y), ps in vus.items():
        f.write(f"\\addplot[only marks,mark=*,mark size=1.2pt,grisTQ] coordinates {{({x},{y})}};"
                f" \\node[font=\\tiny,text=grisTQ,anchor=north] at (axis cs:{x},{y}) {{{','.join(ps)}}};\n")
    coul = {"Machine": "uimmblue", "Équipe": "orangeTQ", "Aspect": "uimmred"}
    for k in range(K):
        v, mo = noms[k].split("=")
        f.write(f"\\addplot[only marks,mark=square*,mark size={1.0 + 0.6*nk[k]:.1f}pt,{coul[v]},opacity=0.75] "
                f"coordinates {{({Gk[k,0]:.3f},{Gk[k,1]:.3f})}}; \\node[font=\\scriptsize\\sffamily,text={coul[v]},"
                f"anchor=south,yshift=3pt] at (axis cs:{Gk[k,0]:.3f},{Gk[k,1]:.3f}) {{{mo} ({int(nk[k])})}};\n")
print("  individus : coordonnées axe 1, axe 2")
for i in range(n):
    print(f"    {pieces[i]} {Fi[i,0]:+.3f} {Fi[i,1]:+.3f}")

# ---------------------------------------------------------------- FAMD
rng = np.random.default_rng(88)
diam = np.round(25.00 + 0.01 * rng.normal(size=n) + 0.008 * (np.array(machine) == "B"), 3)
masse = np.round(312 + 60 * (diam - 25.0) + 0.8 * rng.normal(size=n), 1)
print("\nFAMD : quantitatives Diamètre, Masse ; qualitatives Machine, Équipe")
print("  Diamètre :", diam.tolist())
print("  Masse    :", masse.tolist())
Xq = np.column_stack([diam, masse])
Zq = (Xq - Xq.mean(axis=0)) / Xq.std(axis=0, ddof=0)
Zm, nm_m = disjonctif({"Machine": machine, "Équipe": equipe})
pk = Zm.mean(axis=0)
Zm2 = (Zm - pk) / np.sqrt(pk)
M = np.column_stack([Zq, Zm2])
var_col = M.var(axis=0, ddof=0)
print("  variance (inertie) de chaque colonne :", np.round(var_col, 4))
print("  inertie Diamètre =", round(var_col[0], 4), " Masse =", round(var_col[1], 4),
      " Machine =", round(var_col[2:4].sum(), 4), " Équipe =", round(var_col[4:7].sum(), 4))
vp = np.sort(np.linalg.eigvalsh(M.T @ M / n))[::-1]
print("  valeurs propres FAMD :", np.round(vp[vp > 1e-10], 4), " somme =", round(vp.sum(), 4))
print("  inertie totale attendue = 2 + (2-1) + (3-1) =", 2 + 1 + 2)
print("  variable à 8 modalités : inertie = 8 - 1 =", 7, " ; variable binaire : 1 ; quantitative : 1")

# FAMD sur quantitatives seules = ACP
Xacp = np.load(os.path.join(SORTIES, "acp_X.npy"))
Za = (Xacp - Xacp.mean(axis=0)) / Xacp.std(axis=0, ddof=0)
vp_famd = np.sort(np.linalg.eigvalsh(Za.T @ Za / len(Za)))[::-1]
vp_acp = np.sort(np.linalg.eigvalsh(np.corrcoef(Xacp, rowvar=False)))[::-1]
print("\nFAMD sans qualitative sur les données ACP : écart max des valeurs propres avec l'ACP =",
      float(np.abs(vp_famd - vp_acp).max()))
