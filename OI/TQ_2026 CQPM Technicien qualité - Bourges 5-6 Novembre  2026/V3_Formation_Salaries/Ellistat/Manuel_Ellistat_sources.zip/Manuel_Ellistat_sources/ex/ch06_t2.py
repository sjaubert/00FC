# -*- coding: utf-8 -*-
"""Chapitre 06, carte T² de Hotelling sur deux variables simulées corrélées.

Données simulées : graine numpy 606, 40 pièces, diamètre (mm) et masse (g),
corrélation théorique 0,85. Les lignes 1 à 30 servent d'apprentissage.
Deux défauts sont injectés à la main dans la période de surveillance :
  pièce 34 : combinaison anormale (diamètre haut, masse basse), chaque cote reste
             dans ses limites univariées ;
  pièce 38 : décalage franc du diamètre.
Limites calculées avec les formules classiques de la littérature (hors guide) :
  phase I  (points de l'apprentissage) : (m-1)^2/m * Beta_{1-a}(p/2, (m-p-1)/2)
  phase II (points nouveaux)           : p(m+1)(m-1)/(m(m-p)) * F_{1-a}(p, m-p)
  asymptotique                         : chi2_{1-a}(p)
Cartes univariées : cartes aux valeurs individuelles, limites moyenne +/- 3 MRbarre/1,128
calculées sur l'apprentissage.
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import os
import numpy as np
from scipy import stats

ICI = os.path.dirname(os.path.abspath(__file__))
SORTIES = os.path.join(ICI, "sorties_ch06")
os.makedirs(SORTIES, exist_ok=True)

rng = np.random.default_rng(606)
N, m, p = 40, 30, 2
alpha = 0.0027
mu = np.array([25.000, 312.0])
sig = np.array([0.010, 1.5])
rho = 0.85
C = np.array([[1, rho], [rho, 1]])
Zs = rng.multivariate_normal([0, 0], C, size=N)
Zs[33] = [1.9, -1.6]      # pièce 34
Zs[37] = [3.8, 2.2]       # pièce 38
X = mu + Zs * sig

A = X[:m]
xbar = A.mean(axis=0)
S = np.cov(A, rowvar=False, ddof=1)
Sinv = np.linalg.inv(S)
D = X - xbar
T2 = np.einsum("ij,jk,ik->i", D, Sinv, D)

ucl_I = (m - 1) ** 2 / m * stats.beta.ppf(1 - alpha, p / 2, (m - p - 1) / 2)
ucl_II = p * (m + 1) * (m - 1) / (m * (m - p)) * stats.f.ppf(1 - alpha, p, m - p)
ucl_chi = stats.chi2.ppf(1 - alpha, p)

print(f"Apprentissage m = {m}, p = {p}, alpha = {alpha}")
print("moyennes d'apprentissage :", np.round(xbar, 4))
print("écarts-types (n-1) :", np.round(np.sqrt(np.diag(S)), 4),
      " corrélation :", round(S[0, 1] / np.sqrt(S[0, 0] * S[1, 1]), 3))
print(f"UCL phase I (bêta)  = {ucl_I:.2f}")
print(f"UCL phase II (F)    = {ucl_II:.2f}")
print(f"UCL chi2            = {ucl_chi:.2f}")

# estimateur de Sullivan & Woodall (différences successives), pour information
V = np.diff(A, axis=0)
S_D = V.T @ V / (2 * (m - 1))
T2_D = np.einsum("ij,jk,ik->i", A - xbar, np.linalg.inv(S_D), A - xbar)
print("T2 max en apprentissage, S classique :", round(T2[:m].max(), 2),
      " ; avec S_D (différences successives) :", round(T2_D.max(), 2))

# cartes univariées XmR sur l'apprentissage
lim = []
for j, nom in enumerate(["Diametre", "Masse"]):
    mr = np.abs(np.diff(A[:, j])).mean()
    sigma = mr / 1.128
    lic, lsc = xbar[j] - 3 * sigma, xbar[j] + 3 * sigma
    lim.append((lic, xbar[j], lsc))
    print(f"{nom}: moyenne {xbar[j]:.4f}  MRbar {mr:.4f}  sigma {sigma:.4f}  LIC {lic:.4f}  LSC {lsc:.4f}")

print("\nPièce  Diametre  Masse     T2    hors T2(I/II)  hors univarié")
for i in range(N):
    ucl = ucl_I if i < m else ucl_II
    hu = [j for j in range(2) if not (lim[j][0] <= X[i, j] <= lim[j][2])]
    flag = "OUI" if T2[i] > ucl else ""
    if flag or hu or i in (33, 37):
        print(f"{i+1:5d}  {X[i,0]:.4f}  {X[i,1]:.3f}  {T2[i]:7.2f}  {flag:5s}  {hu}")
print("nombre de points hors T2 :", sum(T2[i] > (ucl_I if i < m else ucl_II) for i in range(N)))
z34 = (X[33] - xbar) / np.sqrt(np.diag(S))
print("pièce 34 en écarts-types d'apprentissage :", np.round(z34, 2))

# ellipse de la limite de phase II dans le plan des variables
vals, vecs = np.linalg.eigh(S)
t = np.linspace(0, 2 * np.pi, 73)
circ = np.vstack([np.cos(t), np.sin(t)])
ell = (vecs @ (np.sqrt(vals * ucl_II)[:, None] * circ)).T + xbar
print("demi-axes de l'ellipse :", np.round(np.sqrt(vals * ucl_II), 4))

with open(os.path.join(SORTIES, "t2_nuage.tex"), "w", encoding="utf-8") as f:
    f.write("\\addplot[thick,uimmblue,smooth] coordinates {" +
            " ".join(f"({x:.5f},{y:.4f})" for x, y in ell) + "};\n")
    f.write("\\addplot[only marks,mark=*,mark size=1.3pt,grisTQ] coordinates {" +
            " ".join(f"({X[i,0]:.5f},{X[i,1]:.4f})" for i in range(m)) + "};\n")
    f.write("\\addplot[only marks,mark=triangle*,mark size=1.8pt,vertTQ] coordinates {" +
            " ".join(f"({X[i,0]:.5f},{X[i,1]:.4f})" for i in range(m, N) if i not in (33, 37)) + "};\n")
    for i in (33, 37):
        f.write(f"\\addplot[only marks,mark=square*,mark size=2.2pt,uimmred] coordinates "
                f"{{({X[i,0]:.5f},{X[i,1]:.4f})}};\n")
        f.write(f"\\node[font=\\scriptsize,text=uimmred,anchor=south west] at "
                f"(axis cs:{X[i,0]:.5f},{X[i,1]:.4f}) {{{i+1}}};\n")
    f.write(f"% limites univariees : D [{lim[0][0]:.5f}, {lim[0][2]:.5f}]  M [{lim[1][0]:.4f}, {lim[1][2]:.4f}]\n")
    f.write(f"\\draw[dashed,orangeTQ,thick] (axis cs:{lim[0][0]:.5f},{lim[1][0]:.4f}) rectangle "
            f"(axis cs:{lim[0][2]:.5f},{lim[1][2]:.4f});\n")

with open(os.path.join(SORTIES, "t2_carte.tex"), "w", encoding="utf-8") as f:
    f.write("\\addplot[mark=*,mark size=1.1pt,uimmblue] coordinates {" +
            " ".join(f"({i+1},{T2[i]:.3f})" for i in range(N)) + "};\n")
    f.write(f"\\draw[uimmred,thick] (axis cs:0.5,{ucl_I:.3f}) -- (axis cs:30.5,{ucl_I:.3f});\n")
    f.write(f"\\draw[uimmred,thick] (axis cs:30.5,{ucl_II:.3f}) -- (axis cs:40.5,{ucl_II:.3f});\n")
    f.write(f"\\draw[grisTQ,dashed] (axis cs:0.5,{ucl_chi:.3f}) -- (axis cs:40.5,{ucl_chi:.3f});\n")
    f.write(f"% ucl_I={ucl_I:.3f} ucl_II={ucl_II:.3f} chi2={ucl_chi:.3f}\n")
for j, nom in enumerate(["diam", "masse"]):
    with open(os.path.join(SORTIES, f"t2_uni_{nom}.tex"), "w", encoding="utf-8") as f:
        fmt = ".5f" if j == 0 else ".4f"
        f.write("\\addplot[mark=*,mark size=1.1pt,uimmblue] coordinates {" +
                " ".join(f"({i+1},{X[i,j]:{fmt}})" for i in range(N)) + "};\n")
        for v, st in zip(lim[j], ["uimmred,thick", "grisTQ", "uimmred,thick"]):
            f.write(f"\\draw[{st}] (axis cs:0.5,{v:{fmt}}) -- (axis cs:40.5,{v:{fmt}});\n")
        for i in (33, 37):
            f.write(f"\\addplot[only marks,mark=square*,mark size=2pt,uimmred] coordinates "
                    f"{{({i+1},{X[i,j]:{fmt}})}};\n")
print("Fragments écrits.")
