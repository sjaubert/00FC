# -*- coding: utf-8 -*-
"""Outils communs aux scripts du chapitre 03 (Graphiques).

Chaque script ch03_*.py :
  - imprime les nombres cités dans les encadrés « exemple » du chapitre ;
  - écrit les coordonnées des figures pgfplots dans ex/sorties_ch03/<nom>.tex
    (blocs recopiés tels quels dans chapitres/ch03.tex entre les marqueurs
    « % DONNEES ch03:<nom> DEBUT » et « % DONNEES ch03:<nom> FIN »).
"""
import os
import re
import pandas as pd

ICI = os.path.dirname(os.path.abspath(__file__))
RACINE = os.path.dirname(ICI)
DONNEES = os.path.join(RACINE, "donnees")
SORTIES = os.path.join(ICI, "sorties_ch03")
os.makedirs(SORTIES, exist_ok=True)

GRAINE = 2026  # graine commune des données simulées du chapitre 03


def lire(nom, decimal="."):
    return pd.read_csv(os.path.join(DONNEES, nom), sep=";", decimal=decimal,
                       encoding="utf-8-sig")


def fr(x, nd=3):
    """Nombre au format français (virgule décimale)."""
    return f"{x:.{nd}f}".replace(".", ",")


def c(x, nd=4):
    """Nombre au format pgfplots (point décimal)."""
    return f"{x:.{nd}f}"


def coords(xs, ys, nx=4, ny=4):
    return " ".join(f"({c(x, nx)},{c(y, ny)})" for x, y in zip(xs, ys))


_DEF = re.compile(r"\\def\\(\w+)\{((?:[^{}]|\{[^{}]*\})*)\}")


def ecrire(nom, texte):
    """Écrit <nom>.tex (tracés) et, s'il y a des macros, <nom>_def.tex (\\gdef à placer avant la figure)."""
    defs = _DEF.findall(texte)
    corps = _DEF.sub("", texte)
    with open(os.path.join(SORTIES, nom + ".tex"), "w", encoding="utf-8") as f:
        f.write(corps.rstrip() + "\n")
    if defs:
        with open(os.path.join(SORTIES, nom + "_def.tex"), "w", encoding="utf-8") as f:
            f.write("\n".join(rf"\gdef\{k}{{{v}}}" for k, v in defs) + "\n")


def titre(t):
    print("\n" + "=" * 70 + "\n" + t + "\n" + "=" * 70)
