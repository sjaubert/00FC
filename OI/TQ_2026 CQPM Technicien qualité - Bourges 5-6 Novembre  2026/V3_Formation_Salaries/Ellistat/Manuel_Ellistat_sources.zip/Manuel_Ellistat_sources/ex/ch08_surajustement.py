"""Chapitre 08 : surajustement d'un polynôme (degrés 1 à 12).

Données simulées (graine 2026) : 20 lignes, y = 10 + 3 sin(2 pi x) + 2 x + bruit N(0 ; 0,5).
6 lignes tirées au hasard servent de lignes de test, 14 d'apprentissage.
Usage : python3 ch08_surajustement.py [dossier_coordonnees]
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import sys, json
import numpy as np
from numpy.polynomial import Polynomial

rng = np.random.default_rng(2026)
n = 20
x = np.sort(rng.uniform(0, 1, n))
f = lambda t: 10 + 3 * np.sin(2 * np.pi * t) + 2 * t
y = f(x) + rng.normal(0, 0.5, n)
test = np.zeros(n, bool)
test[rng.choice(np.arange(1, n - 1), 6, replace=False)] = True  # test à l'intérieur du domaine
xa, ya, xt, yt = x[~test], y[~test], x[test], y[test]

def r2(obs, pred):
    return 1 - np.sum((obs - pred) ** 2) / np.sum((obs - obs.mean()) ** 2)

def rmse(obs, pred):
    return np.sqrt(np.mean((obs - pred) ** 2))

res = {}
print("deg  R2_app   RMSE_app  RMSE_test  R2_test")
for d in range(1, 13):
    p = Polynomial.fit(xa, ya, d)
    res[d] = dict(r2a=r2(ya, p(xa)), rmsea=rmse(ya, p(xa)), rmset=rmse(yt, p(xt)), r2t=r2(yt, p(xt)))
    print(f"{d:3d}  {res[d]['r2a']:.4f}  {res[d]['rmsea']:.4f}  {res[d]['rmset']:9.4f}  {res[d]['r2t']:.4f}")
print("n apprentissage =", (~test).sum(), " n test =", test.sum())
print("RMSE vrai bruit = 0.5")

if len(sys.argv) > 1:
    out = {}
    fmt = lambda pts: " ".join(f"({a:.4f},{b:.4f})" for a, b in pts)
    out["app"] = fmt(zip(xa, ya)); out["test"] = fmt(zip(xt, yt))
    g = np.linspace(x.min(), x.max(), 121)
    for d in (1, 3, 12):
        p = Polynomial.fit(xa, ya, d)
        out[f"c{d}"] = fmt(zip(g, np.clip(p(g), 2, 18)))
        out[f"op{d}a"] = fmt(zip(ya, p(xa))); out[f"op{d}t"] = fmt(zip(yt, p(xt)))
    out["r2a"] = fmt((d, res[d]["r2a"]) for d in res)
    out["rmset"] = fmt((d, res[d]["rmset"]) for d in res)
    out["rmsea"] = fmt((d, res[d]["rmsea"]) for d in res)
    json.dump(out, open(sys.argv[1] + "/surajustement.json", "w"), indent=0)
