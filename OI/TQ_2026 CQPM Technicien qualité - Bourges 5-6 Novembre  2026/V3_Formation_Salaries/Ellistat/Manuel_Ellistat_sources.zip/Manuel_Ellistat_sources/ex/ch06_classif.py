# -*- coding: utf-8 -*-
"""Chapitre 06, classification non supervisée et dendrogrammes.

Données simulées : graine numpy 3004, 90 pièces issues de trois populations
(30 + 30 + 30) qui diffèrent par l'écart de diamètre (µm) et la rugosité Ra (µm),
mais pas par la température de l'atelier (°C), simulée identique dans les trois.
Les trois populations ont des formes différentes : compacte, large, allongée.

Hypothèses de calcul (ce sont nos choix, le guide ne documente pas ceux d'Ellistat) :
variables centrées-réduites (écart-type n), distance euclidienne, K-means de
scikit-learn (k-means++, n_init = 10, random_state = 1), division binaire = BisectingKMeans,
mélanges gaussiens à covariances complètes, DBSCAN eps = 0,8 et min_samples = 5 (puis eps = 1,0 pour comparaison),
dendrogramme des individus par la méthode de Ward, dendrogramme des variables avec
la distance 1 - |r| et le lien moyen.
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import os
import numpy as np
from scipy import stats
from scipy.cluster.hierarchy import linkage, dendrogram, fcluster
from scipy.spatial.distance import squareform
from sklearn.cluster import KMeans, BisectingKMeans, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score, adjusted_rand_score

ICI = os.path.dirname(os.path.abspath(__file__))
SORTIES = os.path.join(ICI, "sorties_ch06")
os.makedirs(SORTIES, exist_ok=True)

rng = np.random.default_rng(3004)
g1 = rng.multivariate_normal([-10, 0.55], [[2.25, 0], [0, 0.0016]], 30)        # compacte
g2 = rng.multivariate_normal([8, 0.72], [[6.25, 0], [0, 0.0036]], 30)          # large
g3 = rng.multivariate_normal([0, 1.05], [[12, 0.15], [0.15, 0.0036]], 30)      # allongée
XY = np.vstack([g1, g2, g3])
temp = 21 + 1.2 * rng.normal(size=90)
X = np.column_stack([XY, temp])
vrai = np.repeat([0, 1, 2], 30)
noms = ["Ecart diametre", "Rugosite Ra", "Temperature"]
Z = (X - X.mean(axis=0)) / X.std(axis=0, ddof=0)

# ---------------------------------------------------------------- choix de K
print("Inertie intra (K-means) et silhouette :")
for k in range(2, 7):
    km = KMeans(n_clusters=k, n_init=10, random_state=1).fit(Z)
    print(f"  K = {k}: inertie intra = {km.inertia_:7.2f}   silhouette = {silhouette_score(Z, km.labels_):.3f}")

km = KMeans(n_clusters=3, n_init=10, random_state=1).fit(Z)
lab_km = km.labels_
# renumérotation des familles par diamètre moyen croissant (1, 2, 3)
ordre = np.argsort([X[lab_km == c, 0].mean() for c in range(3)])
ren = {old: new for new, old in enumerate(ordre)}
lab_km = np.array([ren[c] for c in lab_km])
print("\nK-means K = 3 : effectifs", np.bincount(lab_km), " ARI vs vraies populations =",
      round(adjusted_rand_score(vrai, lab_km), 3))
centres = np.array([X[lab_km == c].mean(axis=0) for c in range(3)])
for c in range(3):
    print(f"  famille {c+1}: n = {np.sum(lab_km==c)}  centre diam = {centres[c,0]:.2f}  Ra = {centres[c,1]:.3f}"
          f"  T = {centres[c,2]:.2f}")

print("\nTests par variable (familles K-means) :")
for j in range(3):
    grp = [X[lab_km == c, j] for c in range(3)]
    F, pF = stats.f_oneway(*grp)
    H, pK = stats.kruskal(*grp)
    print(f"  {noms[j]:15s} F = {F:7.2f}  p = {pF:.2g}   H = {H:6.2f}  p = {pK:.2g}")

# ---------------------------------------------------------------- comparaison des méthodes
bk = BisectingKMeans(n_clusters=3, random_state=1).fit(Z).labels_
gm = GaussianMixture(n_components=3, covariance_type="full", random_state=1).fit(Z).predict(Z)
db = DBSCAN(eps=0.8, min_samples=5).fit(Z).labels_
for e in (0.5, 0.8, 1.0, 1.5):
    l_ = DBSCAN(eps=e, min_samples=5).fit(Z).labels_
    print(f"  DBSCAN eps = {e}: familles = {len(set(l_) - {-1})}  hors groupe = {np.sum(l_ == -1)}")
print("\nComparaison (indice de Rand ajusté avec les vraies populations) :")
for nom, lab in [("K-means", lab_km), ("Division binaire", bk), ("Melanges gaussiens", gm), ("DBSCAN", db)]:
    nb = len(set(lab) - {-1})
    print(f"  {nom:18s} familles = {nb}  hors groupe = {np.sum(lab==-1):2d}  ARI = {adjusted_rand_score(vrai, lab):.3f}")

couleurs = ["uimmblue", "orangeTQ", "vertTQ", "uimmred", "violet"]
marques = ["*", "square*", "triangle*", "diamond*", "pentagon*"]


def nuage(lab, fic, centres_=None):
    """Écrit un nuage diamètre / Ra coloré par famille (familles renumérotées par diamètre)."""
    familles = sorted(set(lab) - {-1}, key=lambda c: X[lab == c, 0].mean())
    with open(os.path.join(SORTIES, fic), "w", encoding="utf-8") as f:
        for r, c in enumerate(familles):
            f.write(f"\\addplot[only marks,mark={marques[r]},mark size=1.4pt,{couleurs[r]}] coordinates {{" +
                    " ".join(f"({x:.2f},{y:.3f})" for x, y in X[lab == c, :2]) + "};\n")
        if np.any(lab == -1):
            f.write("\\addplot[only marks,mark=x,mark size=2.2pt,black,thick] coordinates {" +
                    " ".join(f"({x:.2f},{y:.3f})" for x, y in X[lab == -1, :2]) + "};\n")
        if centres_ is not None:
            for r in range(len(centres_)):
                f.write(f"\\addplot[only marks,mark=+,mark size=5pt,very thick,black] coordinates "
                        f"{{({centres_[r,0]:.2f},{centres_[r,1]:.3f})}};\n")


nuage(lab_km, "km_nuage.tex", centres)
nuage(bk, "cmp_bk.tex")
nuage(gm, "cmp_gm.tex")
nuage(db, "cmp_db.tex")
nuage(lab_km, "cmp_km.tex")

# ---------------------------------------------------------------- dendrogramme des individus
idx = np.concatenate([np.arange(0, 4), np.arange(30, 34), np.arange(60, 64)])
etiq = [f"P{i+1}" for i in idx]
Zs = Z[idx]
L = linkage(Zs, method="ward", metric="euclidean")
print("\nWard sur 12 pièces (4 par population) : hauteurs de fusion")
print("  ", np.round(L[:, 2], 2))
sauts = np.diff(L[:, 2])
print("  sauts :", np.round(sauts, 2))
coupe = (L[-3, 2] + L[-2, 2]) / 2
print(f"  coupe à {coupe:.2f} -> familles :", fcluster(L, t=coupe, criterion="distance"))
# contrôle : hauteur scipy de Ward = racine de 2 x (augmentation de l'inertie intra)
def sse(A):
    return float(((A - A.mean(axis=0)) ** 2).sum())
cl2 = fcluster(L, t=2, criterion="maxclust")
cl1 = np.ones(len(idx), dtype=int)
dW = sse(Zs) - sum(sse(Zs[cl2 == c]) for c in (1, 2))
print(f"  dernière fusion : hauteur = {L[-1,2]:.3f} ; sqrt(2 x dW) = {np.sqrt(2*dW):.3f} (dW = {dW:.3f})")
dn = dendrogram(L, no_plot=True, labels=etiq)
print("  ordre des feuilles :", dn["ivl"])


def tikz_dendro(dn, fic, ech_x, ech_y, coupe=None, couleur="uimmblue"):
    with open(os.path.join(SORTIES, fic), "w", encoding="utf-8") as f:
        for xs, ys in zip(dn["icoord"], dn["dcoord"]):
            pts = " -- ".join(f"({(x-5)/10*ech_x:.3f},{y*ech_y:.3f})" for x, y in zip(xs, ys))
            f.write(f"\\draw[{couleur},thick] {pts};\n")
        for k, nom in enumerate(dn["ivl"]):
            f.write(f"\\node[font=\\scriptsize,anchor=north] at ({k*ech_x:.3f},-0.05) {{{nom}}};\n")
        if coupe is not None:
            f.write(f"\\draw[uimmred,dashed,thick] (-0.4,{coupe*ech_y:.3f}) -- "
                    f"({(len(dn['ivl'])-1)*ech_x+0.4:.3f},{coupe*ech_y:.3f});\n")
        hmax = max(max(y) for y in dn["dcoord"])
        f.write(f"% hauteur max = {hmax:.3f} ; echelle y = {ech_y}\n")


tikz_dendro(dn, "dendro_ind.tex", 0.95, 0.42, coupe)

# ---------------------------------------------------------------- dendrogramme des variables (données ACP)
Xacp = np.load(os.path.join(SORTIES, "acp_X.npy"))
R = np.corrcoef(Xacp, rowvar=False)
Dv = 1 - np.abs(R)
np.fill_diagonal(Dv, 0)
Lv = linkage(squareform(Dv, checks=False), method="average")
print("\nVariables du chapitre ACP, distance 1-|r|, lien moyen : hauteurs", np.round(Lv[:, 2], 3))
dnv = dendrogram(Lv, no_plot=True, labels=["Diamètre", "Longueur", "Masse", "Dureté", "Rugosité"])
print("  ordre :", dnv["ivl"])
tikz_dendro(dnv, "dendro_var.tex", 1.25, 4.0, None, "vertTQ")
print("Fragments écrits.")
