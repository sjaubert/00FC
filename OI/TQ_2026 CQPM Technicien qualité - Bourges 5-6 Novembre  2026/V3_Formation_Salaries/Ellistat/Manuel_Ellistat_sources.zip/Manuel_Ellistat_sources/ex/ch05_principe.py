"""Chapitre 05 : nombres de la figure « principe d'un test » et des comparaisons multiples.

Calculs standard (hors guide Ellistat) :
  - test z bilatéral, alpha = 5 % : valeur critique, p-value d'une statistique observée ;
  - risque bêta et puissance quand le décalage réel vaut 2,5 erreurs-types ;
  - comparaisons multiples : nombre de paires, fausses alarmes attendues.
"""
from math import comb

from scipy import stats

ALPHA = 0.05
DECALAGE = 2.5        # décalage réel sous H1, en erreurs-types (choix pédagogique)
Z_OBS = 2.3           # statistique observée (choix pédagogique)

z_crit = stats.norm.ppf(1 - ALPHA / 2)
p_obs = 2 * stats.norm.sf(abs(Z_OBS))
beta = stats.norm.cdf(z_crit - DECALAGE) - stats.norm.cdf(-z_crit - DECALAGE)
print("=== Figure du principe (test z bilatéral) ===")
print(f"alpha = {ALPHA}, z critique = {z_crit:.3f}")
print(f"z observé = {Z_OBS}, p-value bilatérale = {p_obs:.4f}")
print(f"décalage réel = {DECALAGE} -> beta = {beta:.3f}, puissance = {1 - beta:.3f}")

# Points des densités pour vérifier le tracé pgfplots (formule exacte de la loi normale)
print("densité N(0,1) en 0 :", round(stats.norm.pdf(0), 4))

print("\n=== Comparaisons multiples ===")
for k in (3, 5, 10):
    paires = comb(k, 2)
    attendu = paires * ALPHA
    au_moins_une = 1 - (1 - ALPHA) ** paires
    bonf = ALPHA / paires
    print(f"k = {k:2d} groupes : {paires:2d} paires, fausses alarmes attendues = {attendu:.2f}, "
          f"P(au moins une) = {au_moins_une:.3f} (tests supposés indépendants), "
          f"seuil de Bonferroni = {bonf:.4f}")
