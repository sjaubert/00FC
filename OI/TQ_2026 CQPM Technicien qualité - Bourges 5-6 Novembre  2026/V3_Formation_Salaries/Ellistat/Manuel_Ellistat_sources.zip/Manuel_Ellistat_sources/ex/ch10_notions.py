"""Chapitre 10, notions indispensables : proportion défaillante à t = MTTF et à t = eta.

Vérifie l'affirmation du guide (« plus d'un tiers du parc » défaillant au bout
d'un MTTF pour une loi exponentielle) et la généralise à d'autres beta.
"""
import math

from ch10_commun import mttf, fmt

print("Loi exponentielle (beta = 1) : F(MTTF) = 1 - exp(-1) =", fmt(100 * (1 - math.exp(-1)), 1), "%")
print("Weibull, tout beta : F(eta) = 1 - exp(-1) =", fmt(100 * (1 - math.exp(-1)), 1), "% ; R(eta) =",
      fmt(100 * math.exp(-1), 1), "%")
print()
print("beta ; MTTF/eta ; F(MTTF) en %")
for beta in (0.5, 1.0, 1.5, 2.0, 3.0, 3.6):
    m = mttf(1.0, beta)
    F = 1 - math.exp(-m ** beta)
    print(fmt(beta, 1), ";", fmt(m, 3), ";", fmt(100 * F, 1))

print()
# Exemple du guide : MTTF = 10 ans, loi exponentielle
for t in (1, 5, 10):
    print(f"MTTF 10 ans, exponentielle : R({t} ans) =", fmt(100 * math.exp(-t / 10), 1), "%")
# Durée garantie pour R = 90 % si MTTF = 10 ans (exponentielle)
print("Durée telle que R = 90 % :", fmt(-10 * math.log(0.9), 2), "ans")
