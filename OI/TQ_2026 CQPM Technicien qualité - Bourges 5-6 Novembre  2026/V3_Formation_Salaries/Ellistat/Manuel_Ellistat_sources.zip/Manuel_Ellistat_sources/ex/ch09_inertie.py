"""Chapitre 09, inertie I = sqrt(sigma^2 + delta^2) et lien avec Cpm (hors guide).

Données réelles : butées TQ6 (Butees_diametre.csv), tolérance 11,85 / 12,00.
Cpm = (USL - LSL) / (6 sqrt(sigma^2 + (mu - T)^2)), T = milieu de la tolérance
=> Cpm = IT / (6 I) : les iso-Cpm sont des iso-inerties (quarts de cercle).
"""
import numpy as np

from ch01_commun import lire_large, large_vers_long, sigmas, cp_cpk, LSL, USL
from ch09_commun import fr, titre

IT = USL - LSL
T = (USL + LSL) / 2
s = sigmas(large_vers_long(lire_large()))
mu = s["moyenne"]
delta = mu - T

titre("Butées TQ6 : inertie et Cpm")
print(f"IT = {fr(IT,3)} ; cible T = {fr(T,4)} ; moyenne = {fr(mu,4)} ; delta = {fr(delta,4)}")
for cle in ("R/d2", "s global"):
    sig = s[cle]
    I = np.hypot(sig, delta)
    cpm = IT / (6 * I)
    cp, ck = cp_cpk(sig, mu)
    print(f"sigma {cle:8s} = {fr(sig,4)} : I = {fr(I,4)} ; Cpm = {fr(cpm,2)} ; Cp = {fr(cp,2)} ; Cpk = {fr(ck,2)}")
print(f"Inertie maximale pour Cpm = 1 : IT/6 = {fr(IT/6,4)} ; pour Cpm = 1,33 : {fr(IT/(6*1.33),4)}")
print(f"Centrer parfaitement avec sigma R/d2 : I = {fr(s['R/d2'],4)} -> Cpm = {fr(IT/(6*s['R/d2']),2)}")
sig_req = np.sqrt((IT / 6) ** 2 - delta ** 2) if IT / 6 > abs(delta) else float('nan')
print(f"Sans recentrer, sigma maximal pour Cpm = 1 : {sig_req}")
print(f"|delta| = {fr(abs(delta),4)} > IT/6 = {fr(IT/6,4)} : le seul décentrage interdit Cpm = 1.")

titre("Points de référence de la figure (plan delta, sigma), en mm")
for c in (0.67, 1.0, 1.33, 1.67):
    print(f"Cpm = {c}: rayon iso-inertie = {fr(IT/(6*c),4)} ; Cpk = {c}: sommet sigma = {fr(IT/(6*c),4)}, base |delta| = {fr(IT/2,3)}")
