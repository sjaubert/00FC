"""Chapitre 05 : recherche dichotomique, nombre d'essais et signatures binaires.

Illustration de la logique, ce n'est pas une sortie d'Ellistat.
1. k = ceil(log2 N) pour quelques valeurs de N.
2. Signatures binaires de N = 8 facteurs (A à H) sur k = 3 essais : le facteur numéro i (0 à 7)
   est au niveau WOW à l'essai j si le bit j de i vaut 1 (bit de poids fort à l'essai 1).
3. Déroulé simulé (graine 2026) : un seul facteur actif (E), effet WOW - BOB = 1,0 unité,
   bruit sigma = 0,1. Références : tout BOB = 10,0 et tout WOW = 11,0.
   Lecture d'un essai : niveau BOB + effet si E est au niveau WOW, plus le bruit.
   Bandes : référence ± 3 sigma (sigma supposé connu, mode « Écart-type connu ») ; choix pour l'exemple.
"""
import math

import numpy as np

print("=== 1. Nombre d'essais k = ceil(log2 N) ===")
for N in (2, 3, 4, 5, 8, 9, 12, 16, 17, 24, 32, 33, 64):
    print(f"N = {N:2d} -> k = {math.ceil(math.log2(N))}")

print("\n=== 2. Signatures binaires (N = 8, k = 3) ===")
noms = "ABCDEFGH"
k = 3
sig = {f: [(i >> (k - 1 - j)) & 1 for j in range(k)] for i, f in enumerate(noms)}
for f in noms:
    print(f, " ".join("WOW" if b else "BOB" for b in sig[f]))
for j in range(k):
    print(f"essai {j+1} : WOW = {[f for f in noms if sig[f][j]]}, BOB = {[f for f in noms if not sig[f][j]]}")

print("\n=== 3. Déroulé simulé (facteur actif E, graine 2026) ===")
rng = np.random.default_rng(2026)
BOB, WOW, SIGMA, ACTIF = 10.0, 11.0, 0.1, "E"
bande = 3 * SIGMA
print(f"bande BOB = [{BOB-bande:.1f} ; {BOB+bande:.1f}], bande WOW = [{WOW-bande:.1f} ; {WOW+bande:.1f}]")
suspects = set(noms)
for j in range(k):
    lecture = (WOW if sig[ACTIF][j] else BOB) + rng.normal(0, SIGMA)
    if abs(lecture - BOB) <= bande:
        verdict, garde = "BOB", {f for f in suspects if sig[f][j] == 0}
    elif abs(lecture - WOW) <= bande:
        verdict, garde = "WOW", {f for f in suspects if sig[f][j] == 1}
    else:
        verdict, garde = "INC", set(suspects)
    elimines = sorted(suspects - garde)
    suspects = garde
    print(f"essai {j+1} : lecture = {lecture:.2f} -> {verdict} ; éliminés {elimines} ; restent {sorted(suspects)}")
