"""Chapitre 09, Simulation Monte-Carlo à deux niveaux (lot puis pièce).

Exemple INVENTÉ, graine 2026 : même chaîne J = A - B - C - D que ch09_chaine.py,
tolérances du plan ± 0,075 (répartition quadratique), exigence J dans [0,05 ; 0,35].
Chaque cote : Cpk minimal par lot 1,33, dérive admise de la moyenne de lot ± 0,03.
200 lots x 500 pièces = 100 000 pièces par mode.

Règles de tirage du lot (NOS hypothèses, le guide ne les donne pas) :
  - moyenne du lot : Idéaux = cible ; Au pire = uniforme sur [cible - 0,03 ; cible + 0,03] ;
                     « réaliste » (hypothèse) = loi triangulaire symétrique sur la même plage ;
  - écart-type du lot : le fournisseur tient juste le Cpk minimal :
                     sigma_lot = (0,075 - |mu_lot - cible|) / (3 x 1,33).
Cpk cible par lot sur J : 1,00.
Seconde partie : hypercube latin contre tirage simple.
"""
import numpy as np
from scipy import stats
from scipy.stats import qmc

from ch09_commun import GRAINE, fr, frint, coords, titre

cible = np.array([60.00, 12.00, 18.00, 29.80])
alpha = np.array([1, -1, -1, -1])
tol = 0.075
cpk_min = 1.33
derive = 0.03
Jmin, Jmax, cJ = 0.05, 0.35, 0.20
n_lots, n_pieces = 200, 500
cpk_cible = 1.00


def simuler(mode, rng):
    mu_lots = np.empty((n_lots, 4))
    for i in range(4):
        if mode == "Idéaux":
            d = np.zeros(n_lots)
        elif mode == "Au pire":
            d = rng.uniform(-derive, derive, n_lots)
        else:
            d = rng.triangular(-derive, 0.0, derive, n_lots)
        mu_lots[:, i] = cible[i] + d
    sig_lots = (tol - np.abs(mu_lots - cible)) / (3 * cpk_min)
    J = np.empty((n_lots, n_pieces))
    for l in range(n_lots):
        X = mu_lots[l] + sig_lots[l] * rng.standard_normal((n_pieces, 4))
        J[l] = X @ alpha
    return J


titre("Paramètres")
print(f"sigma lot centré = {fr(tol/(3*cpk_min),4)} ; sigma lot au bout de la dérive = {fr((tol-derive)/(3*cpk_min),4)}")

rng = np.random.default_rng(GRAINE)
res = {}
for mode in ["Idéaux", "Réaliste (hyp. triangulaire)", "Au pire"]:
    J = simuler(mode, rng)
    tout = J.ravel()
    hors = np.sum((tout < Jmin) | (tout > Jmax))
    m, s = tout.mean(), tout.std(ddof=1)
    pp = (Jmax - Jmin) / (6 * s)
    ppk = min(Jmax - m, m - Jmin) / (3 * s)
    ml, sl = J.mean(axis=1), J.std(axis=1, ddof=1)
    cpk_l = np.minimum(Jmax - ml, ml - Jmin) / (3 * sl)
    res[mode] = (ml, sl, cpk_l)
    print(f"{mode:30s} ppm = {frint(1e6*hors/tout.size)} ({hors} pièces) ; Pp = {fr(pp,2)} ; Ppk = {fr(ppk,2)} ; "
          f"Cpk lot médian = {fr(np.median(cpk_l),2)} ; Cpk lot P5 = {fr(np.percentile(cpk_l,5),2)} ; "
          f"lots sous {fr(cpk_cible,2)} : {np.sum(cpk_l < cpk_cible)}/{n_lots} ; s = {fr(s,4)}")

titre("Valeur théorique du mode Idéaux (J normal centré, Cpk_J = 1,33)")
sig1 = tol / (3 * cpk_min)
print(f"sigma_J = 2 x {fr(sig1,4)} = {fr(2*sig1,4)} ; Cpk_J = {fr(0.15/(6*sig1),2)} ; "
      f"ppm théorique = {frint(2e6*stats.norm.sf(0.15/(2*sig1)))}")

titre("Triangle de conformité, mode Au pire (coordonnées)")
ml, sl, cpk_l = res["Au pire"]
ok = cpk_l >= cpk_cible
print("VERT:", coords(ml[ok], sl[ok], 4))
print("ROUGE:", coords(ml[~ok], sl[~ok], 4))
print(f"lot le plus critique : moyenne {fr(ml[np.argmin(cpk_l)],4)}, s {fr(sl[np.argmin(cpk_l)],4)}, Cpk {fr(cpk_l.min(),2)}")
print(f"plage des moyennes de lot : [{fr(ml.min(),3)} ; {fr(ml.max(),3)}], s de lot : [{fr(sl.min(),4)} ; {fr(sl.max(),4)}]")

# ------------------------------------------------------------------ LHS contre MC simple
titre("Hypercube latin contre Monte-Carlo simple")
rng2 = np.random.default_rng(GRAINE)
u_mc = rng2.uniform(size=(10, 2))
u_lh = qmc.LatinHypercube(d=2, seed=GRAINE).random(10)
print("MC10:", coords(u_mc[:, 0], u_mc[:, 1], 3))
print("LH10:", coords(u_lh[:, 0], u_lh[:, 1], 3))
# stabilité : estimation de l'écart-type de J (sigma vrai 0,05) avec n = 200 tirages, 1 000 répétitions
s_vrai = 2 * 0.025
for n in (50, 200, 1000):
    est_mc, est_lh, moy_mc, moy_lh = [], [], [], []
    for r in range(1000):
        z_mc = rng2.standard_normal((n, 4))
        u = qmc.LatinHypercube(d=4, seed=rng2).random(n)
        z_lh = stats.norm.ppf(u)
        est_mc.append(np.std((0.025 * z_mc) @ alpha, ddof=1))
        est_lh.append(np.std((0.025 * z_lh) @ alpha, ddof=1))
        moy_mc.append(np.mean((0.025 * z_mc) @ alpha))
        moy_lh.append(np.mean((0.025 * z_lh) @ alpha))
    est_mc, est_lh = np.array(est_mc), np.array(est_lh)
    print(f"n = {n:5d} : écart-type de l'estimation de sigma_J (vrai {fr(s_vrai,3)}) : "
          f"MC {fr(est_mc.std(),5)} ; LHS {fr(est_lh.std(),5)} ; rapport {fr(est_mc.std()/est_lh.std(),2)}")
    moy_mc, moy_lh = np.array(moy_mc), np.array(moy_lh)
    print(f"          écart-type de l'estimation de la moyenne de J : MC {fr(moy_mc.std(),5)} ; "
          f"LHS {fr(moy_lh.std(),6)} ; rapport {fr(moy_mc.std()/moy_lh.std(),0)}")
