"""Chapitre 10, essais accélérés (formules hors guide).

1. Arrhenius : AF = exp[(Ea / k) (1/T_use - 1/T_test)], T en kelvins,
   k = 8,617e-5 eV/K. Sensibilité à Ea et piège des unités (eV / kJ/mol).
2. Loi puissance inverse L = C * S^(-n) sur un essai simulé (graine 2026) :
   4 niveaux de charge (4, 5, 6, 8 kN), 5 pièces par niveau, durées Weibull
   beta = 2,5 autour de eta(S) = 1,28e6 * S^-3 cycles ; au niveau 8 kN un autre
   mécanisme apparaît (eta divisé par 3). Usage : 2,5 kN.
   Pour chaque niveau : eta estimé par MV ; puis droite ln eta = ln C - n ln S.
"""
import math

import numpy as np
from scipy import stats

from ch10_commun import mle, fmt

k_B = 8.617e-5          # eV/K
EV_KJMOL = 96.485       # 1 eV = 96,485 kJ/mol


def af_arrhenius(ea_ev, t_use_c, t_test_c):
    tu, tt = t_use_c + 273.15, t_test_c + 273.15
    return math.exp(ea_ev / k_B * (1 / tu - 1 / tt))


print("1. Arrhenius, usage 55 °C, essai 125 °C")
for ea in (0.5, 0.7, 1.0):
    print("   Ea =", fmt(ea, 1), "eV (", fmt(ea * EV_KJMOL, 1), "kJ/mol ) : AF =", fmt(af_arrhenius(ea, 55, 125), 1))
af = af_arrhenius(0.7, 55, 125)
print("   1000 h d'essai à 125 °C équivalent à", fmt(1000 * af, 0), "h à 55 °C, soit",
      fmt(1000 * af / 8760, 1), "ans en continu")
print("   Piège d'unité : 0,7 saisi comme des kJ/mol (= ", fmt(0.7 / EV_KJMOL, 5), "eV ) : AF =",
      fmt(af_arrhenius(0.7 / EV_KJMOL, 55, 125), 3))
for tt in (85, 105, 125, 150):
    print(f"   T essai = {tt} °C : AF =", fmt(af_arrhenius(0.7, 55, tt), 1))

print("\n2. Loi puissance inverse (simulation, graine 2026)")
rng = np.random.default_rng(2026)
C0, n0, beta0 = 1.28e6, 3.0, 2.5
niveaux = np.array([4.0, 5.0, 6.0, 8.0])
eta_vrai = C0 * niveaux ** (-n0)
eta_vrai[-1] /= 3          # changement de mécanisme à 8 kN
S_use = 2.5
etas = []
for S, ev in zip(niveaux, eta_vrai):
    t = np.round(ev * rng.weibull(beta0, 5))
    e, b, _, _ = mle(t)
    etas.append(e)
    print(f"   S = {fmt(S,0)} kN : durées =", ", ".join(str(int(x)) for x in np.sort(t)),
          "; eta MV =", fmt(e, 0), "; beta MV =", fmt(b, 2))
etas = np.array(etas)


def ajuste(idx, lib):
    x, y = np.log(niveaux[idx]), np.log(etas[idx])
    res = stats.linregress(x, y)
    n_est, C_est = -res.slope, math.exp(res.intercept)
    L_use = C_est * S_use ** (-n_est)
    print(f"   {lib} : n =", fmt(n_est, 3), "; C =", f"{C_est:.4e}".replace(".", ","), "; R² =",
          fmt(res.rvalue ** 2, 4), "; eta à 2,5 kN =", fmt(L_use, 0),
          "; AF(4 kN -> 2,5 kN) =", fmt((niveaux[0] / S_use) ** n_est, 2))
    return n_est, C_est


print()
n4, C4 = ajuste(slice(0, 4), "4 niveaux")
n3, C3 = ajuste(slice(0, 3), "3 niveaux (8 kN exclu)")
print("   valeur vraie à 2,5 kN :", fmt(C0 * S_use ** (-n0), 0), "; AF vrai =", fmt((4 / 2.5) ** n0, 3))
print("   écart au niveau 8 kN, prédit par 3 niveaux / observé :",
      fmt(C3 * 8 ** (-n3) / etas[-1], 2))
print("\nCoordonnées log-log (ln S, ln eta) :", " ".join(f"({math.log(s):.4f},{math.log(e):.4f})"
                                                     for s, e in zip(niveaux, etas)))
print("Droite 3 niveaux : y =", f"{math.log(C3):.4f} - {n3:.4f}*x", "; 4 niveaux : y =",
      f"{math.log(C4):.4f} - {n4:.4f}*x")
print("ln 2,5 =", f"{math.log(2.5):.4f}")
