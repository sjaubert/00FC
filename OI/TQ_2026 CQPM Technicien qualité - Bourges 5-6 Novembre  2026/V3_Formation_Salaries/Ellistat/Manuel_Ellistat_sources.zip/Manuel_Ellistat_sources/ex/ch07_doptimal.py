"""Chapitre 07 : idée du critère D-optimal, det(X'X), sur un petit exemple.
Calcul refait en Python par recherche exhaustive, ce n'est pas une sortie d'Ellistat
(Ellistat utilise un algorithme d'échange avec simulations répétées, non décrit).

Candidats : grille 3 x 3 en unités codées, x1, x2 dans {-1, 0, +1}.
Modèle M1 : y = b0 + b1 x1 + b2 x2              (3 coefficients)
Modèle M2 : y = b0 + b1 x1 + b2 x2 + b12 x1 x2  (4 coefficients)
Modèle MQ : M2 + b11 x1^2 + b22 x2^2              (6 coefficients, quadratique complet)
"""
import itertools
import numpy as np

cand = [(a, b) for a in (-1, 0, 1) for b in (-1, 0, 1)]


def X_de(points, modele):
    lignes = []
    for x1, x2 in points:
        l = [1, x1, x2]
        if modele in ("M2", "MQ"):
            l.append(x1 * x2)
        if modele == "MQ":
            l += [x1 * x1, x2 * x2]
        lignes.append(l)
    return np.array(lignes, dtype=float)


def det_info(points, modele):
    X = X_de(points, modele)
    return float(np.linalg.det(X.T @ X))


def meilleurs(cands, n, modele):
    res = sorted(((det_info(s, modele), s) for s in itertools.combinations(cands, n)),
                 key=lambda t: -t[0])
    best = res[0][0]
    return best, [s for d, s in res if abs(d - best) < 1e-9], len(res)


def fmt(s):
    return " ".join(f"({a:+d},{b:+d})" for a, b in s)


# 1. Quelques plans à 4 essais pour M1
print("Plans à 4 essais, modèle M1 (p = 3)")
exemples = {
    "4 coins": [(-1, -1), (1, -1), (-1, 1), (1, 1)],
    "3 coins + centre": [(-1, -1), (1, -1), (-1, 1), (0, 0)],
    "4 milieux de côtés": [(-1, 0), (1, 0), (0, -1), (0, 1)],
    "3 points alignés + 1": [(-1, -1), (0, 0), (1, 1), (1, -1)],
}
for nom, s in exemples.items():
    X = X_de(s, "M1")
    print(f"  {nom:22s} det(X'X) = {det_info(s, 'M1'):6.2f}")
print("  X'X des 4 coins :\n", (X_de(exemples['4 coins'], 'M1').T @ X_de(exemples['4 coins'], 'M1')).astype(int))

best, sols, ntot = meilleurs(cand, 4, "M1")
print(f"Recherche exhaustive, 9 candidats, 4 essais, M1 : {ntot} sous-ensembles ; det max = {best:.2f} ; solutions : {[fmt(s) for s in sols]}")

# 2. Le coin (+1,+1) est irréalisable (exclu des candidats)
cand8 = [c for c in cand if c != (1, 1)]
ref = 64.0
for modele, n in [("M1", 4), ("M2", 4), ("M2", 5)]:
    best, sols, ntot = meilleurs(cand8, n, modele)
    p = 3 if modele == "M1" else 4
    print(f"\nSans (+1,+1), {n} essais, {modele} : {ntot} sous-ensembles ; det max = {best:.2f}")
    for s in sols:
        print("   ", fmt(s))
    if modele == "M1":
        sol_M1 = sols
    if n == 4 and modele == "M2":
        ref_M2 = det_info(exemples["4 coins"], "M2")
        print(f"   référence 4 coins sous M2 : det = {ref_M2:.2f} ; rapport = {best/ref_M2:.4f} ; "
              f"efficacité D (rapport^(1/p)) = {(best/ref_M2)**(1/p):.4f}")
    if modele == "M1":
        print(f"   rapport au plan des 4 coins (det 64) = {best/ref:.4f} ; efficacité D = {(best/ref)**(1/p):.4f}")

# 3. Un plan optimal pour un modèle peut être inutilisable pour un autre
print("\n6 essais parmi les 9 candidats : modèle M1 contre modèle quadratique MQ")
bL, solsL, ntot = meilleurs(cand, 6, "M1")
bQ, solsQ, _ = meilleurs(cand, 6, "MQ")
print(f"  {ntot} sous-ensembles ; det max M1 = {bL:.2f} ; det max MQ = {bQ:.2f}")
for s in solsL:
    print("   optimal M1 :", fmt(s), f"| det M1 = {det_info(s, 'M1'):.2f} ; det MQ = {abs(det_info(s, 'MQ')):.2f}")
for s in solsQ:
    print("   optimal MQ :", fmt(s), f"| det M1 = {det_info(s, 'M1'):.2f} ; det MQ = {det_info(s, 'MQ'):.2f}"
          f" ; rapport M1 = {det_info(s, 'M1')/bL:.4f}")
