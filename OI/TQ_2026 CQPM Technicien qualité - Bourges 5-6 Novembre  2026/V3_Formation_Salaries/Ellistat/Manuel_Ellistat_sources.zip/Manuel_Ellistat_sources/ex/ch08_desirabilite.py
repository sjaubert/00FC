"""Chapitre 08 : désirabilités individuelles et globale.

Fonctions linéaires par morceaux (forme supposée : le guide ne la donne pas ; exposant 1).
  Résistance R (MPa), Maximiser : Pire = 300, Cible = 400.
  Temps de cycle T (s), Minimiser : Pire = 60, Cible = 40.
  Cote D (mm), Cible encadrée : Pire mini 11,85 ; Cible mini 11,90 ; Cible maxi 11,95 ; Pire maxi 12,00.
Trois réglages fictifs comparés selon : produit (guide), moyenne géométrique pondérée
(Derringer et Suich, hors guide), moyenne arithmétique (contre-exemple).
Calcul refait en Python, ce n'est pas une sortie d'Ellistat.
"""
import numpy as np

def d_max(y, pire, cible):
    return float(np.clip((y - pire) / (cible - pire), 0, 1))

def d_min(y, pire, cible):
    return float(np.clip((pire - y) / (pire - cible), 0, 1))

def d_cible(y, pmin, cmin, cmax, pmax):
    if y < cmin:
        return d_max(y, pmin, cmin)
    if y > cmax:
        return d_min(y, pmax, cmax)
    return 1.0

reglages = {"R1": (340, 50, 11.93), "R2": (395, 42, 11.99), "R3": (420, 38, 12.01)}
poids = {"égaux (1,1,1)": (1, 1, 1), "cote x2 (1,1,2)": (1, 1, 2), "résistance x3 (3,1,1)": (3, 1, 1)}
for nom, (R, T, D) in reglages.items():
    d = np.array([d_max(R, 300, 400), d_min(T, 60, 40), d_cible(D, 11.85, 11.90, 11.95, 12.00)])
    prod = d.prod()
    print(f"{nom} : R = {R}, T = {T}, D = {D:.3f} -> d = {np.round(d, 3)}")
    print(f"     produit = {prod:.4f} ; moyenne géométrique = {prod ** (1/3):.4f} ; moyenne arithmétique = {d.mean():.4f}")
    for lib, w in poids.items():
        w = np.array(w, float)
        g = np.prod(d ** w) ** (1 / w.sum())
        print(f"     moyenne géométrique pondérée, poids {lib} = {g:.4f}")
