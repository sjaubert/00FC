# -*- coding: utf-8 -*-
"""Recopie les coordonnées produites par les scripts ch03_*.py dans chapitres/ch03.tex.

Chaque bloc délimité par « % DONNEES ch03:<nom> DEBUT » et « % DONNEES ch03:<nom> FIN »
est remplacé par le contenu de ex/sorties_ch03/<nom>.tex.
Ordre d'exécution : ch03_population.py, ch03_proportions.py, ch03_regression.py,
ch03_roc.py, ch03_multi.py, puis ce script.
"""
import os
import re
from ch03_commun import RACINE, SORTIES

chemin = os.path.join(RACINE, "chapitres", "ch03.tex")
texte = open(chemin, encoding="utf-8").read()
motif = re.compile(r"(% DONNEES ch03:(\S+) DEBUT\n)(.*?)(% DONNEES ch03:\2 FIN)", re.S)
noms = []


def remplace(m):
    nom = m.group(2)
    noms.append(nom)
    bloc = open(os.path.join(SORTIES, nom + ".tex"), encoding="utf-8").read()
    return m.group(1) + bloc + m.group(4)


texte = motif.sub(remplace, texte)
open(chemin, "w", encoding="utf-8").write(texte)
print(f"{len(noms)} blocs injectés :", ", ".join(noms))
