"""Chapitre 05 : équivalence de deux moyennes par TOST (Two One-Sided Tests).

Calcul refait en Python (scipy, statsmodels), ce n'est pas une sortie d'Ellistat.
Hypothèses de calcul (hors guide) : variances supposées égales (t de Student groupé),
alpha = 5 % par test unilatéral, donc intervalle de confiance à 90 % de l'écart.
delta = 0,015 mm, soit 10 % de l'IT des butées (11,85 / 12,00) : choix fait pour l'exemple.

Cinq cas :
  A. opérateurs Alexandre et Guillaume (ANOVA_TP_R.csv) ;
  B. opérateurs Corentin et Alexandre (ANOVA_TP_R.csv) ;
  C. butées, échantillons 1 à 3 contre 4 à 6 (Butees_diametre.csv) ;
  D. deux séries simulées (graine 2026), n = 400 par série, écart réel 0,005 mm, sigma 0,02 mm ;
  E. opérateurs Corentin et Emma : la paire la plus éloignée, testée seule « à la main »
     (illustration des comparaisons multiples, à rapprocher du Tukey de ch05_anova_operateurs.py).
"""
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.weightstats import ttost_ind

DONNEES = Path(__file__).resolve().parent.parent / "donnees"
DELTA = 0.015
ALPHA = 0.05

ope = pd.read_csv(DONNEES / "ANOVA_TP_R.csv", sep=";", decimal=",", encoding="utf-8-sig").dropna()
but = pd.read_csv(DONNEES / "Butees_diametre.csv", sep=";", decimal=",", encoding="utf-8-sig")
but = but.dropna(subset=["P1"])
val = but[["P1", "P2", "P3", "P4", "P5"]].to_numpy()


def op(nom):
    return ope.loc[ope["Operateurs"] == nom, "Mesure"].to_numpy()


rng = np.random.default_rng(2026)
sim1 = rng.normal(11.920, 0.02, 400)
sim2 = rng.normal(11.925, 0.02, 400)

cas = {
    "A Alexandre - Guillaume": (op("Alexandre"), op("Guillaume")),
    "B Corentin - Alexandre": (op("Corentin"), op("Alexandre")),
    "C Butées éch. 4-6 - éch. 1-3": (val[3:].ravel(), val[:3].ravel()),
    "D Simulé (graine 2026)": (sim2, sim1),
    "E Corentin - Emma": (op("Corentin"), op("Emma")),
}

for nom, (x, y) in cas.items():
    n1, n2 = len(x), len(y)
    d = x.mean() - y.mean()
    sp = np.sqrt(((n1 - 1) * x.var(ddof=1) + (n2 - 1) * y.var(ddof=1)) / (n1 + n2 - 2))
    se = sp * np.sqrt(1 / n1 + 1 / n2)
    ddl = n1 + n2 - 2
    t90 = stats.t.ppf(1 - ALPHA, ddl)
    ic90 = (d - t90 * se, d + t90 * se)
    t95 = stats.t.ppf(1 - ALPHA / 2, ddl)
    ic95 = (d - t95 * se, d + t95 * se)
    p_diff = stats.ttest_ind(x, y).pvalue
    p_tost, bas, haut = ttost_ind(x, y, -DELTA, DELTA, usevar="pooled")
    equiv = ic90[0] > -DELTA and ic90[1] < DELTA
    diff = p_diff <= ALPHA
    if diff and equiv:
        verdict = "différence réelle mais négligeable"
    elif diff:
        verdict = "différence démontrée, non équivalent"
    elif equiv:
        verdict = "équivalence démontrée"
    else:
        verdict = "indécis"
    # plus petit delta démontrable avec ces effectifs : borne de l'IC 90 % la plus éloignée de 0
    delta_min = max(abs(ic90[0]), abs(ic90[1]))
    print(f"--- {nom} ---")
    print(f"n = {n1} / {n2}, écart = {d:+.4f}, s groupé = {sp:.4f}, erreur-type = {se:.4f}, ddl = {ddl}")
    print(f"IC 90 % = [{ic90[0]:+.4f} ; {ic90[1]:+.4f}]  IC 95 % = [{ic95[0]:+.4f} ; {ic95[1]:+.4f}]")
    print(f"test t de différence : p = {p_diff:.4g}")
    print(f"TOST : p borne basse = {bas[1]:.4g}, p borne haute = {haut[1]:.4g}, p TOST = {p_tost:.4g}")
    print(f"plus petit delta démontrable (borne IC 90 %) = {delta_min:.4f}")
    print(f"verdict : {verdict}\n")

# Effectif par groupe pour démontrer l'équivalence (écart réel nul, sigma = 0,0206, delta = 0,015)
# Formule normale approchée classique : n = 2 sigma² (z_{1-alpha} + z_{1-beta/2})² / delta²
sig = 0.0206
for puis in (0.80, 0.90):
    za = stats.norm.ppf(1 - ALPHA)
    zb = stats.norm.ppf(1 - (1 - puis) / 2)
    n = 2 * sig ** 2 * (za + zb) ** 2 / DELTA ** 2
    print(f"Équivalence (écart réel nul), sigma = {sig}, delta = {DELTA}, puissance {puis:.0%} : "
          f"n approx = {n:.1f} par groupe")
