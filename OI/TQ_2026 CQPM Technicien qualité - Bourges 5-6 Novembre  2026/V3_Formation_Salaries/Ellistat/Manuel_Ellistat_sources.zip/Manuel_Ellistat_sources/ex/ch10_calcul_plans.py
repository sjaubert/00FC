"""Chapitre 10, calcul de fiabilité : plans d'essai (formules hors guide).

1. Plan sans défaillance (success run) : n = ln(1 - C) / ln R.
2. Extension de Lipson (durée d'essai L fois la mission, Weibull beta connu) :
   n = ln(1 - C) / (L^beta * ln R).
3. Recherche des beta qui redonnent l'exemple du guide (16 produits, 2000 cycles).
4. Plan Chi2 (beta = 1) : T_cumulé = chi2(C ; 2r + 2) / (2 lambda).
5. Exemple « Temps défaillance » : eta tel que R(100) = 0,90 avec beta = 1.
"""
import math

from scipy import stats

from ch10_commun import fmt

R, C = 0.90, 0.95
t_mission = 1000.0

# 1. success run
n_brut = math.log(1 - C) / math.log(R)
print("1. Success run R = 90 %, C = 95 % : n brut =", fmt(n_brut, 2), "-> n =", math.ceil(n_brut))
for (r_, c_) in [(0.90, 0.90), (0.95, 0.95), (0.99, 0.95)]:
    nb = math.log(1 - c_) / math.log(r_)
    print(f"   R = {r_}, C = {c_} : n brut =", fmt(nb, 2), "-> n =", math.ceil(nb))

# 2. Lipson avec L = 2 (2000 cycles pour une mission de 1000)
L = 2.0
print("\n2. Lipson, L = 2 :")
for beta in (0.5, 0.8, 1.0, 1.5, 2.0, 3.0):
    nb = n_brut / L ** beta
    print("   beta =", fmt(beta, 1), ": n brut =", fmt(nb, 2), "-> n =", math.ceil(nb))

# 3. beta compatibles avec n = 16 : 15 < n_brut / 2^beta <= 16
b_min = math.log(n_brut / 16) / math.log(L)
b_max = math.log(n_brut / 15) / math.log(L)
print("\n3. n = 16 si beta dans [", fmt(b_min, 3), ";", fmt(b_max, 3), "[")
# Durée d'essai qui donnerait 16 produits avec beta = 1
L16 = n_brut / 16
print("   avec beta = 1, 16 produits suffisent pour L >=", fmt(L16, 3), "soit", fmt(L16 * t_mission, 0), "cycles")

# 4. Plan Chi2
lam = -math.log(R) / t_mission
print("\n4. Plan Chi2 : lambda =", f"{lam:.4e}".replace(".", ","), "par cycle ; MTTF équivalent =", fmt(1 / lam, 1))
for r in (0, 1, 2, 3):
    chi = stats.chi2.ppf(C, 2 * r + 2)
    T = chi / (2 * lam)
    print(f"   r = {r} : chi2(0,95 ; {2*r+2}) =", fmt(chi, 3), "; T cumulé =", fmt(T, 0),
          "cycles ; avec 10 produits :", fmt(T / 10, 0), "cycles chacun ; avec 29 produits :", fmt(T / 29, 0))

# 5. eta pour R(100) = 0,9 et beta = 1
eta = -100 / math.log(0.9)
print("\n5. eta tel que R(100) = 0,90 (beta = 1) :", fmt(eta, 1))
print("   R(100) avec eta = 968 :", fmt(math.exp(-100 / 968), 4))
print("   F(100) avec eta = 968 :", fmt(100 * (1 - math.exp(-100 / 968)), 2), "%")
print("   écart relatif 968 / 949,1 - 1 =", fmt(100 * (968 / eta - 1), 1), "%")

# 6. Hypothèse pour le mode « Temps défaillance » (non documenté) :
#    espérance du temps de la k-ième défaillance parmi n produits, loi exponentielle
#    E[T_(k)] = eta * somme_{i=0}^{k-1} 1 / (n - i)
print("\n6. Espérance du temps de la k-ième défaillance (beta = 1, eta = 949,1)")
for n in (5, 10, 29):
    vals = [eta * sum(1 / (n - i) for i in range(k)) for k in (1, 2, 3)]
    print(f"   n = {n} :", " ; ".join(f"k = {k} -> {fmt(v, 1)}" for k, v in zip((1, 2, 3), vals)))

# 7. Optimisme du plan Chi2 quand beta > 1 (produit qui s'use)
#    Plan Chi2 r = 0 : T cumulé = 28 433 cycles réparti sur n produits.
#    Produit réel : beta = 3 et R(1000) = 0,80 (il NE tient PAS l'objectif de 90 %).
#    Probabilité de réussir l'essai (0 défaillance) = R(T/n)^n.
T0 = stats.chi2.ppf(C, 2) / (2 * lam)
print("\n7. Plan Chi2 r = 0, T cumulé =", fmt(T0, 0), "cycles ; produit réel beta = 3, R(1000) = 0,80")
for beta_reel in (1.0, 3.0):
    eta_r = 1000 / (-math.log(0.80)) ** (1 / beta_reel)
    for n in (29, 100):
        duree = T0 / n
        p_ok = math.exp(-n * (duree / eta_r) ** beta_reel)
        print(f"   beta réel = {fmt(beta_reel,0)}, n = {n}, durée par produit = {fmt(duree,0)} :"
              f" P(0 défaillance) = {fmt(100 * p_ok, 1)} %")
