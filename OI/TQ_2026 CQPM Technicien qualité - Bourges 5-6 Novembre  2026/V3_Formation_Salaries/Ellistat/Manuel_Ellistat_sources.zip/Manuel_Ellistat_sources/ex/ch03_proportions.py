# -*- coding: utf-8 -*-
"""Chapitre 03 : représentations de proportion (Camembert, Barre, Pareto, Table).

Données réelles : donnees/SPC-1_inspection.csv (120 lots de 150 pièces, nombre de non-conformes).
Le fichier ne donne pas le type de défaut. La répartition des non-conformes en
8 types est SIMULÉE (loi multinomiale, graine 2026) ; les coûts unitaires sont
des hypothèses pédagogiques. Calculs refaits en Python, pas des sorties d'Ellistat.
"""
import math
import numpy as np
from scipy import stats
from ch03_commun import lire, fr, c, ecrire, titre, GRAINE

Z = stats.norm.ppf(0.975)


def wilson(k, n):
    p = k / n
    centre = (p + Z ** 2 / (2 * n)) / (1 + Z ** 2 / n)
    demi = Z * math.sqrt(p * (1 - p) / n + Z ** 2 / (4 * n ** 2)) / (1 + Z ** 2 / n)
    return centre - demi, centre + demi


def clopper(k, n):
    bas = stats.beta.ppf(0.025, k, n - k + 1) if k > 0 else 0.0
    haut = stats.beta.ppf(0.975, k + 1, n - k) if k < n else 1.0
    return bas, haut


def wald(k, n):
    p = k / n
    d = Z * math.sqrt(p * (1 - p) / n)
    return p - d, p + d


# ----------------------------------------------------------------- SPC-1
d = lire("SPC-1_inspection.csv")
nlots = len(d)
N = int(d["Taille_lot"].sum())
K = int(d["Non_conformes"].sum())
titre("SPC-1 : proportion globale de non-conformes")
print(f"{nlots} lots ; {N} pièces contrôlées ; {K} non conformes ; {N - K} conformes")
print(f"p = {fr(K / N * 100, 2)} %")
for nom, f in [("Wald", wald), ("Wilson", wilson), ("Clopper-Pearson", clopper)]:
    b, h = f(K, N)
    print(f"IC 95 % {nom} : [{fr(b * 100, 2)} % ; {fr(h * 100, 2)} %]")
pl = d["Non_conformes"] / d["Taille_lot"]
print(f"Proportion par lot : min = {fr(pl.min() * 100, 2)} % ; max = {fr(pl.max() * 100, 2)} %")
# limites de la carte p (rappel fiche G, hors guide)
pb = K / N
lcs = pb + 3 * math.sqrt(pb * (1 - pb) / 150)
lci = max(0.0, pb - 3 * math.sqrt(pb * (1 - pb) / 150))
print(f"Carte p (n = 150) : LC = {fr(pb * 100, 2)} % ; LCS = {fr(lcs * 100, 2)} % ; LCI = {fr(lci * 100, 2)} %")
print(f"Lots au-dessus de la LCS : {[int(i) for i in d.loc[pl > lcs, 'Lot']]}")

# ----------------------------------------------------------------- types simulés
types = ["Rayure", "Bavure", "Cote hors tolérance", "Manque matière", "Tache",
         "Filetage abîmé", "Déformation", "Marquage absent"]
proba = np.array([0.30, 0.22, 0.14, 0.10, 0.08, 0.07, 0.05, 0.04])
cout = np.array([2, 3, 40, 25, 1, 15, 30, 5], dtype=float)  # euros par pièce (hypothèse)
rng = np.random.default_rng(GRAINE)
eff = rng.multinomial(K, proba)
titre(f"Répartition simulée des {K} non-conformes en 8 types (graine {GRAINE})")
for t, e in zip(types, eff):
    print(f"  {t:22s} {e:4d}")
print("Somme :", int(eff.sum()))

# Table avec IC (proportion parmi les non-conformes)
titre("Table : proportions et IC 95 % (Wilson et Clopper-Pearson)")
ordre = np.argsort(-eff, kind="stable")
lignes_table = []
for i in ordre:
    k = int(eff[i])
    wb, wh = wilson(k, K)
    cb, ch = clopper(k, K)
    print(f"  {types[i]:22s} {k:4d} {fr(k / K * 100, 1):>6s} %  Wilson [{fr(wb * 100, 1)} ; {fr(wh * 100, 1)}]"
          f"  CP [{fr(cb * 100, 1)} ; {fr(ch * 100, 1)}]")
    lignes_table.append(f"{types[i]} & {k} & {fr(k / K * 100, 1)} & [{fr(wb * 100, 1)} ; {fr(wh * 100, 1)}] & "
                        f"[{fr(cb * 100, 1)} ; {fr(ch * 100, 1)}] \\\\")
lignes_table.append(r"\midrule" + f"\nTotal & {K} & 100,0 & & \\\\")
ecrire("table_ic", "\n".join(lignes_table))

# Camembert : angles cumulés (ordre du Pareto)
titre("Camembert : angles")
ang = 0.0
lp = []
palette = ["uimmblue", "uimmred", "orangeTQ", "vertTQ", "grisTQ", "uimmblue!45", "uimmred!45", "orangeTQ!45"]
for rang, i in enumerate(ordre):
    a = 360 * eff[i] / K
    print(f"  {types[i]:22s} {fr(a, 1)} degrés")
    mil = ang + a / 2
    lp.append(rf"\chtroispart{{{c(ang, 2)}}}{{{c(ang + a, 2)}}}{{{palette[rang]}}}{{{c(mil, 2)}}}{{{fr(eff[i] / K * 100, 1)}\,\%}}")
    ang += a
ecrire("camembert", "\n".join(lp))

# Barres (ordre du fichier, non trié) et Pareto (trié + cumul)
def symb(lst):
    return ",".join("{" + s + "}" for s in lst)

courts = ["Rayure", "Bavure", "Cote HT", "Manque mat.", "Tache", "Filetage", "Déform.", "Marquage"]
alpha = sorted(range(8), key=lambda i: courts[i])  # barres dans l'ordre alphabétique
ecrire("barres", rf"\def\chtroisbarrelabels{{{symb([courts[i] for i in alpha])}}}" + "\n" +
       r"\addplot[ybar,bar width=9pt,fill=uimmblue!45,draw=uimmblue] coordinates {"
       + " ".join(f"({{{courts[i]}}},{int(eff[i])})" for i in alpha) + "};")

cum = np.cumsum(eff[ordre]) / K * 100
titre("Pareto par fréquence")
for r, i in enumerate(ordre):
    print(f"  {r + 1}. {types[i]:22s} {eff[i]:4d}  cumul {fr(cum[r], 1)} %")
pl_ = [courts[i] for i in ordre]
ecrire("pareto_freq", rf"\def\chtroisparetolabels{{{symb(pl_)}}}" + "\n" +
       r"\addplot[ybar,bar width=9pt,fill=uimmblue!45,draw=uimmblue] coordinates {"
       + " ".join(f"({{{courts[i]}}},{int(eff[i])})" for i in ordre) + "};")
ecrire("pareto_freq_cumul", r"\addplot[thick,uimmred,mark=*,mark size=1.4pt] coordinates {"
       + " ".join(f"({{{courts[i]}}},{c(cum[r], 2)})" for r, i in enumerate(ordre)) + "};")

titre("Pareto pondéré par le coût (coûts unitaires hypothétiques)")
pond = eff * cout
ordre2 = np.argsort(-pond, kind="stable")
cum2 = np.cumsum(pond[ordre2]) / pond.sum() * 100
for r, i in enumerate(ordre2):
    print(f"  {r + 1}. {types[i]:22s} {eff[i]:4d} x {int(cout[i]):3d} € = {int(pond[i]):6d} €  cumul {fr(cum2[r], 1)} %")
print(f"Coût total = {int(pond.sum())} €")
pl2 = [courts[i] for i in ordre2]
ecrire("pareto_cout", rf"\def\chtroisparetocoutlabels{{{symb(pl2)}}}" + "\n" +
       r"\addplot[ybar,bar width=9pt,fill=uimmred!40,draw=uimmred] coordinates {"
       + " ".join(f"({{{courts[i]}}},{c(pond[i] / 1000, 3)})" for i in ordre2) + "};")
ecrire("pareto_cout_cumul", r"\addplot[thick,uimmblue,mark=*,mark size=1.4pt] coordinates {"
       + " ".join(f"({{{courts[i]}}},{c(cum2[r], 2)})" for r, i in enumerate(ordre2)) + "};")
# rang comparé
for i in range(8):
    print(f"  {types[i]:22s} rang fréquence {list(ordre).index(i) + 1} ; rang coût {list(ordre2).index(i) + 1}")
