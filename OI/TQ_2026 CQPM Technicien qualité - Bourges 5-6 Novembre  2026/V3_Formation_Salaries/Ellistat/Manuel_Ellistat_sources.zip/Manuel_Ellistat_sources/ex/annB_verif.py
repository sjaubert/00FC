# Vérification des nombres cités en annexe B (article Ellistat Cp/Pp/Ppk, IT = [1 ; 10])
IT = 10 - 1
s_ct, s_lt = 1.7321, 2.6904
Cp = IT / (6 * s_ct); Pp = IT / (6 * s_lt)
print(f"Cp = {Cp:.3f}  Pp = {Pp:.3f}")
# Ppk = 0,54 annoncé : distance de la moyenne à la limite la plus proche
d = 0.54 * 3 * s_lt
print(f"distance moyenne-limite pour Ppk 0,54 : {d:.3f} (moyenne vers {1+d:.2f} ou {10-d:.2f})")
# Correspondance GRR % = 100/Cpc aux seuils cités
for c in (3, 3.33, 4, 8, 10):
    print(f"Cpc {c} -> GRR {100/c:.1f} %")
