"""Chapitre 09, chaînes de cotes.

1. Reconstitution (hypothèse) du tableau des six conventions du guide
   (cotes A..D dans Jeu1, E seule cote libre de Jeu2 avec une cote de A..D,
   tolérances exprimées en intervalles IT, budget de chaque jeu 0,400).
2. Notre exemple INVENTÉ : chaîne à 4 maillons
       J = A - B - C - D, A = 60,00 ; B = 12,00 ; C = 18,00 ; D = 29,80
       exigence J dans [0,05 ; 0,35] (cible 0,20, IT_J = 0,30), beta = 1 partout.
3. Monte-Carlo 100 000 tirages (graine 2026) pour chaque convention.
4. Vérification de l'avertissement « moins de 3 cotes ».

Formules des conventions (hors guide, reconstituées) :
  pire des cas      IT_Y = sum |a_i| IT_i
  stat. quadratique IT_Y = sqrt(sum a_i^2 IT_i^2)            (IT_i = 6 sigma_i, normale centrée)
  stat. uniforme    IT_Y = 6 sqrt(sum a_i^2 IT_i^2 / 12) = sqrt(3) * quadratique
  inertiel          I_Y  = sqrt(sum a_i^2 I_i^2), I_Y max = IT_Y / 6
  inertiel corrigé  max sur (delta_i, sigma_i) avec delta_i^2 + sigma_i^2 = I_i^2
                    de |delta_Y| + 3 sigma_Y <= IT_Y / 2  (Cpk_Y >= 1 garanti)
  inertiel pondéré  formule et w non documentés : non calculé.
"""
import numpy as np
from scipy import stats
from scipy.optimize import brentq, minimize

from ch09_commun import GRAINE, fr, frint, ppm_normal, histo_coords, titre


# ------------------------------------------------------------------ fonctions
def pire_max(I, alpha=None):
    """max de |sum a_i delta_i| + 3 sqrt(sum a_i^2 sigma_i^2) sur les cercles d'inertie."""
    I = np.asarray(I, float)
    a = np.ones_like(I) if alpha is None else np.abs(np.asarray(alpha, float))
    best = 0.0
    rng = np.random.default_rng(0)
    for _ in range(30):
        th0 = rng.uniform(0, np.pi / 2, len(I))
        f = lambda th: -(np.sum(a * I * np.sin(th)) + 3 * np.sqrt(np.sum((a * I * np.cos(th)) ** 2)))
        r = minimize(f, th0, bounds=[(0, np.pi / 2)] * len(I))
        best = max(best, -r.fun)
    return best


def repartition_egale(ITY, n):
    """Tolérance par cote (beta égaux, alpha = +-1) pour chaque convention."""
    t_pc = ITY / n
    t_q = ITY / np.sqrt(n)
    t_u = ITY / np.sqrt(3 * n)
    i_in = (ITY / 6) / np.sqrt(n)
    i_co = (ITY / 2) / np.sqrt(n ** 2 + 9 * n)   # solution exacte pour n cotes égales
    return t_pc, t_u, t_q, i_in, i_co


# ------------------------------------------------------------------ 1. guide
titre("1. Reconstitution du tableau du guide (Jeu1 : 4 cotes, Jeu2 : E + 1 cote, IT = 0,400)")
ITj = 0.400
t_pc, t_u, t_q, i_in, i_co = repartition_egale(ITj, 4)
E_pc = ITj - t_pc
E_u = np.sqrt(ITj ** 2 / 3 - t_u ** 2)
E_q = np.sqrt(ITj ** 2 - t_q ** 2)
E_in = np.sqrt((ITj / 6) ** 2 - i_in ** 2)
E_co = brentq(lambda e: pire_max([e, i_co]) - ITj / 2, 1e-4, 0.2)
lignes = [("Pire des cas", t_pc, E_pc, "0,100 / 0,300"),
          ("Statistique uniforme", t_u, E_u, "0,115 / 0,200"),
          ("Statistique quadratique", t_q, E_q, "0,200 / 0,346"),
          ("Inertiel", i_in, E_in, "0,033 / 0,058"),
          ("Inertiel corrigé", i_co, E_co, "0,028 / 0,054")]
for nom, a_, e_, g in lignes:
    print(f"{nom:26s} A..D = {fr(a_,4)}  E = {fr(e_,4)}   guide : {g}")
print(f"Vérif. corrigé n=4 : sqrt(n^2+9n) = {fr(np.sqrt(52),4)} ; pire_max([I]*4) = {fr(pire_max([i_co]*4),4)} (doit valoir 0,2)")
print("Inertiel pondéré : guide 0,018 / 0,032 ; rapports au inertiel :",
      fr(0.018 / i_in, 3), fr(0.032 / E_in, 3), "; rapport E/A =", fr(0.032 / 0.018, 3),
      "(sqrt 3 =", fr(np.sqrt(3), 3), ")")
# avertissement Jeu2 : composition uniforme avec les tolérances pire des cas
u_j2 = np.sqrt(3) * np.hypot(E_pc, t_pc)
print(f"Jeu2 en composition uniforme avec les tolérances pire des cas (0,300 ; 0,100) : {fr(u_j2,3)} (guide : 0,505)")
print(f"Jeu2 avec tolérances uniformes (0,200 ; 0,115) : pire des cas {fr(E_u+t_u,3)}, uniforme {fr(np.sqrt(3)*np.hypot(E_u,t_u),3)}")
# couples qui donneraient 0,505 / 0,400
s2 = (0.505 / np.sqrt(3)) ** 2
d = np.sqrt(2 * s2 - 0.4 ** 2)
print(f"Couple (a ; b) avec a + b = 0,400 et sqrt(3(a^2+b^2)) = 0,505 : ({fr((0.4+d)/2,3)} ; {fr((0.4-d)/2,3)})")

# ------------------------------------------------------------------ 4. avertissement < 3 cotes
titre("4. Avertissement : uniforme contre pire des cas, n cotes égales de IT = 1")
for n in range(1, 7):
    print(f"n = {n} : pire des cas {fr(n,3)} ; uniforme sqrt(3n) = {fr(np.sqrt(3*n),3)} ; "
          f"quadratique sqrt(n) = {fr(np.sqrt(n),3)} ; rapport unif/pc = {fr(np.sqrt(3/n),3)}")
rng = np.random.default_rng(GRAINE)
N = 100_000
for n in (1, 2, 3):
    s = rng.uniform(-0.5, 0.5, (N, n)).sum(axis=1)
    print(f"Simulation n = {n} cotes uniformes IT = 1 : étendue observée {fr(s.max()-s.min(),3)} "
          f"(possible : {n}) ; 6 s = {fr(6*s.std(ddof=1),3)} (convention uniforme : {fr(np.sqrt(3*n),3)})")
print(f"Une seule cote uniforme : 6 sigma = 6/sqrt(12) = {fr(6/np.sqrt(12),3)} fois son IT")

# ------------------------------------------------------------------ 2. notre chaîne
titre("2. Chaîne J = A - B - C - D, exigence [0,05 ; 0,35]")
nom = ["A", "B", "C", "D"]
cible = np.array([60.00, 12.00, 18.00, 29.80])
alpha = np.array([1, -1, -1, -1])
Jmin, Jmax = 0.05, 0.35
ITJ = Jmax - Jmin
cJ = float(alpha @ cible)
print(f"Cible obtenue = sum alpha_i cible_i = {fr(cJ,3)} ; erreur de signe sur D -> {fr(cJ + 2*29.80,3)}")
t_pc, t_u, t_q, i_in, i_co = repartition_egale(ITJ, 4)
print(f"Pire des cas      IT_i = {fr(t_pc,4)} (± {fr(t_pc/2,4)})")
print(f"Uniforme          IT_i = {fr(t_u,4)} (± {fr(t_u/2,4)})")
print(f"Quadratique       IT_i = {fr(t_q,4)} (± {fr(t_q/2,4)})")
print(f"Inertiel          I_i  = {fr(i_in,4)} (I_J max = {fr(ITJ/6,4)})")
print(f"Inertiel corrigé  I_i  = {fr(i_co,4)} (sqrt(52) = {fr(np.sqrt(52),3)})")
print(f"Gain quadratique / pire des cas = {fr(t_q/t_pc,2)} ; uniforme / pire des cas = {fr(t_u/t_pc,3)}")
th = np.arctan(np.sqrt(4) / 3)
print(f"Angle le plus défavorable (n = 4) : tan theta = sqrt(n)/3 -> sin = {fr(np.sin(th),4)}, cos = {fr(np.cos(th),4)}")

titre("Valeurs obtenues pour J (colonnes cible / pire des cas / gaussienne / uniforme)")
for lab, t in [("tolérances pire des cas", t_pc), ("tolérances uniformes", t_u), ("tolérances quadratiques", t_q)]:
    pc = 4 * t
    ga = np.sqrt(4) * t
    un = np.sqrt(3) * ga
    print(f"{lab:26s} cible {fr(cJ,3)} | pire des cas [{fr(cJ-pc/2,3)} ; {fr(cJ+pc/2,3)}] IT {fr(pc,3)}"
          f" | gauss [{fr(cJ-ga/2,3)} ; {fr(cJ+ga/2,3)}] IT {fr(ga,3)} | unif [{fr(cJ-un/2,3)} ; {fr(cJ+un/2,3)}] IT {fr(un,3)}")

# ------------------------------------------------------------------ 3. Monte-Carlo
titre("3. Monte-Carlo, 100 000 assemblages, graine 2026")
rng = np.random.default_rng(GRAINE)


def tirer(mu_dec, sig, loi="gauss"):
    """mu_dec : décentrage de chaque cote ; sig : écart-type (gauss) ou demi-largeur (unif)."""
    X = np.empty((N, 4))
    for i in range(4):
        if loi == "gauss":
            X[:, i] = cible[i] + mu_dec[i] + rng.normal(0, sig[i], N)
        elif loi == "unif":
            X[:, i] = cible[i] + mu_dec[i] + rng.uniform(-sig[i], sig[i], N)
        elif loi == "bimodale":   # pièces aux deux bornes, moitié-moitié
            X[:, i] = cible[i] + mu_dec[i] + sig[i] * rng.choice([-1.0, 1.0], N)
    return X @ alpha


def bilan(J, lab, theorique=None):
    eps = 1e-9   # une pièce exactement sur la limite est conforme
    hors = np.sum((J < Jmin - eps) | (J > Jmax + eps))
    ppm = 1e6 * hors / N
    demi = 1.96 * np.sqrt(hors) / hors * 100 if hors > 0 else float("nan")
    th = "" if theorique is None else f" ; théorique {frint(theorique)} ppm"
    print(f"{lab:62s} moy {fr(J.mean(),4)} s {fr(J.std(ddof=1),4)} hors {hors:6d} -> {frint(ppm)} ppm"
          f" (± {fr(demi,0)} %){th}")
    return J, ppm


z = np.zeros(4)
one = np.ones(4)
# signes défavorables : décentrage qui pousse J vers le haut
sg = alpha.astype(float)
J_pc, _ = bilan(tirer(z, one * t_pc / 2, "unif"), "PC : uniformes dans la tolérance")
J_pcb, _ = bilan(tirer(z, one * t_pc / 2, "bimodale"), "PC : toutes les pièces aux bornes")
J_u, _ = bilan(tirer(z, one * t_u / 2, "unif"), "Uniforme : uniformes dans la tolérance")
J_ub, _ = bilan(tirer(z, one * t_u / 2, "bimodale"), "Uniforme : pièces aux bornes")
s_q = t_q / 6
J_q, _ = bilan(tirer(z, one * s_q, "gauss"), "Quadratique : normales centrées, Cp = 1",
               ppm_normal(cJ, 2 * s_q, Jmin, Jmax))
J_qu, _ = bilan(tirer(z, one * t_q / 2, "unif"), "Quadratique : uniformes dans la tolérance")
# quadratique, cotes décentrées de 1 sigma (Cpk = 0,67) dans le sens défavorable
J_qd, _ = bilan(tirer(sg * s_q, one * s_q, "gauss"), "Quadratique : normales décentrées d'un sigma (Cpk 0,67)",
                ppm_normal(cJ + 4 * s_q, 2 * s_q, Jmin, Jmax))
# inertiel : centré puis angle défavorable
J_i0, _ = bilan(tirer(z, one * i_in, "gauss"), "Inertiel : delta = 0, sigma = I", ppm_normal(cJ, 2 * i_in, Jmin, Jmax))
d_i, s_i = i_in * np.sin(th), i_in * np.cos(th)
J_i1, _ = bilan(tirer(sg * d_i, one * s_i, "gauss"), "Inertiel : angle défavorable",
                ppm_normal(cJ + 4 * d_i, 2 * s_i, Jmin, Jmax))
print(f"   inertiel défavorable : delta_i = {fr(d_i,4)}, sigma_i = {fr(s_i,4)}, delta_J = {fr(4*d_i,4)}, "
      f"sigma_J = {fr(2*s_i,4)}, Cpk_J = {fr((ITJ/2-4*d_i)/(3*2*s_i),3)}")
J_i2, _ = bilan(tirer(sg * i_in, one * 1e-9, "gauss"), "Inertiel : sigma = 0, delta = I (tout décentré)")
d_c, s_c = i_co * np.sin(th), i_co * np.cos(th)
J_c1, _ = bilan(tirer(sg * d_c, one * s_c, "gauss"), "Inertiel corrigé : angle défavorable",
                ppm_normal(cJ + 4 * d_c, 2 * s_c, Jmin, Jmax))
print(f"   corrigé défavorable : delta_i = {fr(d_c,4)}, sigma_i = {fr(s_c,4)}, Cpk_J = {fr((ITJ/2-4*d_c)/(3*2*s_c),3)}")

titre("Incertitude d'un ppm simulé (approximation de Poisson)")
for ppm in (710, 2700):
    k = ppm * 1e-6 * N
    print(f"{ppm} ppm sur 100 000 : {k:.0f} pièces, demi-largeur 95 % = {fr(196/np.sqrt(k),1)} % ; "
          f"N pour ± 5 % = {frint((1.96/0.05)**2/(ppm*1e-6))}")
print(f"0 pièce hors tolérance sur 100 000 : borne haute 95 % = 3/N = {frint(3e6/N)} ppm "
      f"(exacte : {fr(1e6*(1-0.05**(1/N)),2)} ppm)")

titre("Histogrammes pour la figure (quadratique : normal centré / uniforme)")
bornes = np.linspace(-0.13, 0.53, 45)
print("HQ:", histo_coords(J_q, bornes))
print("HU:", histo_coords(J_qu, bornes))
