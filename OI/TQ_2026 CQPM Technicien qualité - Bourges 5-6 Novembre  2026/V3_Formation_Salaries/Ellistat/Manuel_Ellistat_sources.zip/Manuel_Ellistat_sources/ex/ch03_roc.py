# -*- coding: utf-8 -*-
"""Chapitre 03 : courbe ROC.

Données SIMULÉES (numpy default_rng, graine 2026) : niveau de vibration (mm/s)
de 40 roulements qui ont tenu et de 20 roulements qui ont défailli.
Seuil « statistique » : indice de Youden (sensibilité + spécificité - 1 maximal).
Ellistat ne documente pas son critère : c'est une hypothèse.
Calculs refaits en Python, pas des sorties d'Ellistat.
"""
import numpy as np
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score
from ch03_commun import fr, c, coords, ecrire, titre, GRAINE

rng = np.random.default_rng(GRAINE)
sains = np.round(rng.normal(2.0, 0.6, 40), 2)
defa = np.round(rng.normal(2.8, 0.8, 20), 2)
y = np.r_[np.zeros(sains.size), np.ones(defa.size)]
v = np.r_[sains, defa]

titre(f"Courbe ROC (simulée, graine {GRAINE})")
print(f"Sains : n = {sains.size}, moyenne = {fr(sains.mean(), 2)}, s = {fr(sains.std(ddof=1), 2)} mm/s")
print(f"Défaillants : n = {defa.size}, moyenne = {fr(defa.mean(), 2)}, s = {fr(defa.std(ddof=1), 2)} mm/s")
fpr, tpr, seuils = roc_curve(y, v, drop_intermediate=False)
auc = roc_auc_score(y, v)
u = stats.mannwhitneyu(defa, sains, alternative="two-sided")
print(f"AUC = {fr(auc, 3)} ; contrôle U/(n1 n2) = {fr(u.statistic / (sains.size * defa.size), 3)} ; "
      f"p (Mann-Whitney) = {u.pvalue:.1e}")
J = tpr - fpr
k = int(np.argmax(J))
s_opt = seuils[k]
print(f"Seuil de Youden : alarme si vibration >= {fr(s_opt, 2)} mm/s ; sensibilité = {fr(tpr[k] * 100, 1)} % ; "
      f"spécificité = {fr((1 - fpr[k]) * 100, 1)} % ; J = {fr(J[k], 3)}")
print(f"  défaillants manqués = {int(round((1 - tpr[k]) * defa.size))} / {defa.size} ; "
      f"bons rejetés = {int(round(fpr[k] * sains.size))} / {sains.size}")
# seuil « économique » : ne manquer aucun défaillant
k2 = int(np.argmax(tpr >= 1.0))
print(f"Seuil sans défaillant manqué : >= {fr(seuils[k2], 2)} mm/s ; sensibilité = {fr(tpr[k2] * 100, 1)} % ; "
      f"spécificité = {fr((1 - fpr[k2]) * 100, 1)} % ; bons rejetés = {int(round(fpr[k2] * sains.size))} / {sains.size}")

# courbe « quasi parfaite » de comparaison : défaillants décalés de +1,5 mm/s
defa2 = defa + 1.5
y2 = np.r_[np.zeros(sains.size), np.ones(defa2.size)]
f2, t2, _ = roc_curve(y2, np.r_[sains, defa2])
auc2 = roc_auc_score(y2, np.r_[sains, defa2])
print(f"Courbe de comparaison (défaillants + 1,5 mm/s) : AUC = {fr(auc2, 3)}")

ecrire("roc", r"\addplot[thick,uimmblue] coordinates {" + coords(fpr, tpr, 4, 4) + "};\n"
       + r"\addplot[thick,dashed,vertTQ] coordinates {" + coords(f2, t2, 4, 4) + "};\n"
       + rf"\def\chtroisrocx{{{c(fpr[k], 4)}}}\def\chtroisrocy{{{c(tpr[k], 4)}}}"
       + rf"\def\chtroisrocxx{{{c(fpr[k2], 4)}}}\def\chtroisrocyy{{{c(tpr[k2], 4)}}}"
       + rf"\def\chtroisauc{{{fr(auc, 3)}}}\def\chtroisaucb{{{fr(auc2, 3)}}}\def\chtroisseuil{{{fr(s_opt, 2)}}}"
       + rf"\def\chtroisseuilb{{{fr(seuils[k2], 2)}}}")
# bandes de points (distribution des deux groupes)
ecrire("roc_points", r"\addplot[only marks,mark=*,mark size=1.3pt,vertTQ] coordinates {"
       + " ".join(f"({c(a, 2)},1)" for a in sains) + "};\n"
       + r"\addplot[only marks,mark=*,mark size=1.3pt,uimmred] coordinates {"
       + " ".join(f"({c(a, 2)},2)" for a in defa) + "};")
